"""ZYRO fast bot-add guard: kicks an unapproved bot the instant the audit entry appears. Development by ARIAN"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import db_path


class FastBotGuard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def antinuke_on(self, gid):
        try:
            async with aiosqlite.connect(db_path("anti.db")) as db:
                async with db.execute("SELECT status FROM antinuke WHERE guild_id=?", (gid,)) as c:
                    r = await c.fetchone()
            return bool(r and r[0])
        except Exception:
            return False

    async def trusted(self, g, uid):
        if uid == g.owner_id or uid == self.bot.user.id:
            return True
        try:
            async with aiosqlite.connect(db_path("anti.db")) as db:
                async with db.execute("SELECT botadd FROM whitelisted_users WHERE guild_id=? AND user_id=?", (g.id, uid)) as c:
                    r = await c.fetchone()
                if r and r[0]:
                    return True
                async with db.execute("SELECT 1 FROM extraowners WHERE guild_id=? AND owner_id=?", (g.id, uid)) as c:
                    return await c.fetchone() is not None
        except Exception:
            return False

    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        if entry.action != discord.AuditLogAction.bot_add:
            return
        g, uid = entry.guild, entry.user_id
        if not uid or not await self.antinuke_on(g.id) or await self.trusted(g, uid):
            return
        tid = getattr(entry.target, "id", None)
        if tid:
            try:
                await g.kick(discord.Object(tid), reason="ZYRO antinuke: bot added by non-whitelisted user")
            except Exception:
                pass
        try:
            await g.ban(discord.Object(uid), reason="ZYRO antinuke: added a bot without permission", delete_message_days=0)
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(FastBotGuard(bot))
