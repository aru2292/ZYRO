# ZYRO emoji pack — 100% Unicode (no custom/server emojis needed, works in every server)
# Development by ARIAN

# --- Main ---
CHECK = "✅"
VERIFIED_CHECK = "☑️"
CROSS = "❌"
CROSS_MARK = "✖️"
TICK = "✔️"
ZTICK = "✔️"
ERROR_X = "⛔"
LOCK = "🔒"
UNLOCK = "🔓"
GHOST = "👻"
UNGHOST = "🫥"
BOOST = "🚀"
INFO = "⚠️"
CART = "🛒"
SUPPORT = "🛟"
DELETE = "🗑️"
LOADING = "⏳"

# --- Stats ---
STATS = "📊"
UPTIME = "🕰️"
DATABASE = "🗄️"
VERIFIED_DEV = "🛠️"
OS_SYSTEM = "🖥️"
CPU = "⚙️"
RAM = "🧠"
STORAGE = "💾"
CROWN = "👑"
GEARS = "⚙️"
LINK = "🔗"
CREDITS = "💳"

# --- Utility ---
TIMER = "⏱️"
REPLY = "↳"
REPLY_2 = "╰┈➤"
BELL = "🔔"

# --- Role / Status ---
VIP = "💎"
FRIEND = "🤝"
VERIFIED = "🛡️"
ENABLED = "🟢"
DISABLED = "🔴"
DISABLED_OFF = "⚫"

# --- ZYRO extra symbols (rare / stylish) ---
STAR = "✦"
DIAMOND = "❖"
ARROW = "➤"
SPARK = "✧"
FLOWER = "❀"
DOT = "•"
MUSIC = "🎵"
NOTE = "♪"
PLAY = "▶️"
PAUSE = "⏸️"
STOP = "⏹️"
SKIP = "⏭️"
SHUFFLE = "🔀"
LOOP = "🔁"
VOLUME = "🔊"
COIN = "🪙"
GEM = "💠"
FIRE = "🔥"
SHIELD = "🛡️"
SWORD = "⚔️"
BAN = "🔨"
PARTY = "🎉"
HEART = "💜"
SPARKLES = "✨"
ROCKET = "🚀"
BOLT = "⚡"
TARGET = "🎯"
TICKET = "🎫"
GIFT = "🎁"
MAIL = "📩"
PIN = "📌"

# --- Compatibility mappings ---
EMOJIES = {
    "lock": LOCK, "unlock": UNLOCK, "ghost": GHOST, "unghost": UNGHOST,
    "boost": BOOST, "info": INFO, "cross": CROSS, "cart": CART, "check": CHECK,
}

ROLE_EMOJIS = {
    "Developer": VERIFIED_DEV, "Vip": VIP, "Friend": FRIEND,
    "Owner": CROWN, "Verified": VERIFIED,
}
