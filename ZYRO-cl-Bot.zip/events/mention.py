"""ZYRO mention reply. Development by ARIAN"""
import discord
from discord.ext import commands
from emojis import REPLY_2


class MentionReply(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def invite(self):
        return self.bot.invite_link or f"https://discord.com/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot%20applications.commands"

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not self.bot.user:
            return
        if message.content.strip() not in (f"<@{self.bot.user.id}>", f"<@!{self.bot.user.id}>"):
            return
        prefixes = await self.bot.get_prefix(message)
        prefix = prefixes[-1] if isinstance(prefixes, list) else prefixes
        for p in (prefixes if isinstance(prefixes, list) else [prefixes]):
            if not str(p).startswith("<@"):
                prefix = p
                break
        e = discord.Embed(
            title=f"Hey {message.author.display_name}! I'm {self.bot.user.name}",
            description=(f"{REPLY_2} My prefix here is `{prefix}`\n{REPLY_2} Run `{prefix}help` for all commands\n"
                         f"{REPLY_2} Music: `{prefix}play <song>` • Security: `{prefix}antinuke enable`\n"
                         f"{REPLY_2} Premium: `{prefix}premium`"),
            color=0x7B2FFF)
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        e.set_footer(text="ZYRO • Development by ARIAN")
        view = discord.ui.View()
        view.add_item(discord.ui.Button(label="Invite Me", style=discord.ButtonStyle.link, url=self.invite()))
        if self.bot.support_link:
            view.add_item(discord.ui.Button(label="Support", style=discord.ButtonStyle.link, url=self.bot.support_link))
        try:
            await message.reply(embed=e, view=view, mention_author=False)
        except discord.Forbidden:
            try:
                await message.channel.send(f"Hey! My prefix is `{prefix}` — use `{prefix}help`")
            except Exception:
                pass
        except Exception:
            try:
                await message.reply(embed=e, mention_author=False)
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(MentionReply(bot))
