"""ZYRO premium helpers. Development by ARIAN"""
import re
import time
import aiosqlite
from config import PREMIUM_DB

_cache: dict = {}
_ready = False
UNITS = {"d": 1, "day": 1, "days": 1, "w": 7, "week": 7, "weeks": 7, "m": 30, "mo": 30, "month": 30, "months": 30,
         "y": 365, "yr": 365, "year": 365, "years": 365}


async def ensure():
    global _ready
    if _ready:
        return
    async with aiosqlite.connect(PREMIUM_DB) as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS grants (user_id INTEGER PRIMARY KEY, plan TEXT, days INTEGER, slots INTEGER,
            expires INTEGER, granted_by INTEGER, granted_at INTEGER, reminded INTEGER DEFAULT 0)""")
        await db.execute("CREATE TABLE IF NOT EXISTS guild_premium (guild_id INTEGER PRIMARY KEY, user_id INTEGER, activated_at INTEGER)")
        await db.commit()
    _ready = True


def parse_duration(text: str):
    """'3month' / '7 d' / '1y' / 'lifetime' -> days (0 = lifetime) or None."""
    t = (text or "").lower().replace(" ", "")
    if t in ("lifetime", "life", "perm", "permanent", "forever"):
        return 0
    m = re.fullmatch(r"(\d+)([a-z]+)", t)
    if m and m.group(2) in UNITS and int(m.group(1)) > 0:
        return int(m.group(1)) * UNITS[m.group(2)]
    return None


def plan_info(days: int):
    """days -> (plan name, server slots)"""
    if days == 0:
        return "Lifetime 👑", 5
    if days <= 1:
        return "Trial", 1
    if days <= 7:
        return "Weekly", 1
    if days <= 31:
        return "Monthly", 1
    if days <= 95:
        return "3 Months", 2
    if days <= 190:
        return "6 Months", 2
    if days <= 370:
        return "Yearly", 3
    return "Elite", 3


async def user_grant(uid: int):
    await ensure()
    async with aiosqlite.connect(PREMIUM_DB) as db:
        async with db.execute("SELECT plan, days, slots, expires FROM grants WHERE user_id=?", (uid,)) as c:
            r = await c.fetchone()
    if not r or (r[3] != 0 and r[3] <= time.time()):
        return None
    return dict(plan=r[0], days=r[1], slots=r[2], expires=r[3])


async def guild_premium(gid: int) -> bool:
    c = _cache.get(gid)
    if c and time.time() - c[0] < 30:
        return c[1]
    await ensure()
    async with aiosqlite.connect(PREMIUM_DB) as db:
        async with db.execute("SELECT g.expires FROM guild_premium p JOIN grants g ON g.user_id=p.user_id WHERE p.guild_id=?", (gid,)) as cur:
            row = await cur.fetchone()
    ok_ = bool(row and (row[0] == 0 or row[0] > time.time()))
    _cache[gid] = (time.time(), ok_)
    return ok_


def clear_cache():
    _cache.clear()
