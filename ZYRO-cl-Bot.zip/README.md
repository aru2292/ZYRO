# ✦ ZYRO — All-in-one Discord Bot
**Development by ARIAN**

## Deploy (Railway)
1. Repo root: `Dockerfile` + `ZYRO-Bot.zip` (delete the old zip when you upload a new one).
2. Variables: `TOKEN`, `OWNER_IDS` (your Discord ID), `DATA_DIR=/data` + a Volume mounted at `/data`.
3. Developer Portal → Bot → enable **Server Members Intent** + **Message Content Intent**.
4. Invite with Administrator, then drag **ZYRO's role to the very TOP** of the server roles and run `+zyrocheck`.

## Security
- Layer 1: `+antinuke enable` → role `ZYRO ./unbypassble` (refuses to enable if risky roles are above ZYRO).
- Layer 2 (premium): `+pantinuke enable` → role `ZYRO+++ ./unbypassble`, `+pwl @user` daily limits, `+pautomod enable`.

## Premium (bot owner)
`+premium grant @user 3month` (7d, 1month, 6month, 1year, lifetime …) → user is DM'd + gets No-Prefix.
User runs `+premium activate` in their server. Owner/extra-owner there can use `+botavatar`, `+botbanner`, `+botbio`.

## New in this version
`+panic` / `+unpanic` (nuke emergency) • `+admins` (who can nuke you) • modmail • confessions • roleall/removeall • sticky roles • voice-time stats (`+vctime`, `+vctop`) • AI (`+ask`, `+aichannel`; set `ANTHROPIC_API_KEY` or `AI_API_KEY`) • slash commands auto-trimmed to Discord's 100 limit (prefix commands always work).
