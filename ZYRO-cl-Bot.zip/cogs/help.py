"""ZYRO Help — premium look: dropdown, pagination, search, per-command details. Development by ARIAN"""
import difflib
import discord
from discord.ext import commands

import zpremium as zp
from config import SUPPORT_LINK, INVITE_LINK

COLORS = {"success": 0x2ECC71, "danger": 0xE74C3C, "blurple": 0x5865F2, "primary": 0x7B2FFF}
EMOJI = {
    "AutoMod": "🤖", "Info": "ℹ️", "Moderation": "🔨", "AntiNuke": "🛡️", "Utility": "🧰", "Premium": "💎",
    "Security+": "🔐", "Music": "🎵", "Voice": "🎙️", "ModPlus": "⚔️", "Fun": "🎮", "Economy": "🪙",
    "Leveling": "📈", "Tickets": "🎫", "ServerTools": "🏗️", "Tools": "🛠️", "Roles": "🏷️", "Social": "💬",
    "Embed": "🧾", "Tracker": "📊", "Pfp": "🖼️", "Welcome": "👋", "VoiceMaster": "🔊",
    "Autoresponder": "💭", "Autoreact": "😀",
}
GROUPS = {
    "🛡️ Protection": ["AntiNuke", "Security+", "AutoMod", "Premium"],
    "⚙️ Management": ["Moderation", "ModPlus", "Roles", "Tickets", "ServerTools", "Welcome"],
    "🎧 Fun & Media": ["Music", "Voice", "VoiceMaster", "Fun", "Economy", "Leveling", "Social", "Pfp"],
    "🧰 Utility": ["Info", "Utility", "Tools", "Tracker", "Embed", "Autoresponder", "Autoreact"],
}
PER_PAGE = 8

CATEGORY_COMMANDS = {'AutoMod': {'color': 'blurple',
             'commands': [('automod enable', 'Enable automod features'),
                          ('automod disable', 'Disable automod features'),
                          ('automod config', 'Configure automod settings'),
                          ('automod punishment', 'Set punishment methods')],
             'description': 'Automatic moderation to keep your server safe from spam, invites, and disruptions.'},
 'Info': {'color': 'success',
          'commands': [('help', 'Show this help menu'),
                       ('ping', 'Check bot latency'),
                       ('stats', 'View bot statistics'),
                       ('botinfo', 'Get bot information'),
                       ('uptime', 'Check bot uptime'),
                       ('invite', 'Get bot invite link'),
                       ('support', 'Join support server'),
                       ('vote', 'Vote for the bot')],
          'description': 'Information commands to get details about the bot and server.'},
 'Moderation': {'color': 'danger',
                'commands': [('ban', 'Ban a member from the server'),
                             ('kick', 'Kick a member from the server'),
                             ('mute', 'Mute a member'),
                             ('unmute', 'Unmute a member'),
                             ('lock', 'Lock a channel'),
                             ('unlock', 'Unlock a channel'),
                             ('hide', 'Hide a channel'),
                             ('unhide', 'Unhide a channel'),
                             ('unban', 'Unban a member'),
                             ('purge', 'Delete multiple messages'),
                             ('snipe', 'View deleted messages'),
                             ('warn', 'Warn a member')],
                'description': 'Powerful moderation tools to manage your server and keep members in check.'},
 'AntiNuke': {'color': 'danger',
              'commands': [('antinuke', 'View antinuke status'),
                           ('antinuke enable', 'Enable antinuke protection'),
                           ('antinuke disable', 'Disable antinuke protection'),
                           ('antinuke whitelist', 'Whitelist a member'),
                           ('antinuke unwwhitelist', 'Remove whitelist'),
                           ('extraowner set', 'Set extra owner'),
                           ('extraowner reset', 'Reset extra owner'),
                           ('extraowner view', 'View extra owners')],
              'description': 'Advanced protection against server nuking and unauthorized actions.'},
 'Utility': {'color': 'primary',
             'commands': [('avatar', "Get member's avatar"),
                          ('serverinfo', 'Get server information'),
                          ('userinfo', 'Get user information'),
                          ('steal', 'Steal an emoji'),
                          ('giveaway', 'Create a giveaway'),
                          ('afk', 'Set AFK status'),
                          ('reminder', 'Set reminders'),
                          ('timer', 'Create timers'),
                          ('banner', 'Get server banner'),
                          ('users', 'Count members'),
                          ('setprefix', 'Change command prefix'),
                          ('resetprefix', 'Reset to default prefix')],
             'description': 'Useful utility commands for everyday server management and fun features.'},
 'Premium': {'color': 'primary',
             'commands': [('premium', 'Your status + buttons'),
                          ('premium activate', 'Activate in this server'),
                          ('premium deactivate', 'Free the slot'),
                          ('premium servers', 'Your premium servers'),
                          ('premium plans', 'Plans & features'),
                          ('botavatar / botbanner / botbio', 'Custom bot profile in this server (owner/extra owner)'),
                          ('botprofilereset', 'Reset bot profile'),
                          ('premium grant @user 3month', '(Bot owner) give premium + DM + No-Prefix'),
                          ('premium revoke / list / check', '(Bot owner) manage')],
             'description': 'ZYRO+++ : 2nd antinuke layer, strict automod, custom bot profile, No-Prefix.'},
 'Security+': {'color': 'danger',
               'commands': [('whitelist @user', 'Pick exact antinuke actions to allow (owner/extra owner)'),
                            ('whitelisted', 'List whitelist'),
                            ('unwhitelist @user', 'Remove from whitelist'),
                            ('whitelistreset', 'Clear whitelist (owner)'),
                            ('zyrocheck', 'Check if antinuke can really protect you'),
                            ('panic / unpanic', 'EMERGENCY: strip dangerous perms, kick bots, lock server'),
                            ('admins', 'Who has dangerous permissions (nuke risk)'),
                            ('antinuke enable', 'Layer 1 — role ZYRO ./unbypassble'),
                            ('pantinuke enable', 'Layer 2 PREMIUM — role ZYRO+++ ./unbypassble'),
                            ('pwl @user', 'PREMIUM per-day limits (ban/kick/prune/@everyone...)'),
                            ('pautomod enable', 'PREMIUM strict automod + per-day allowances'),
                            ('antiraid on/off/set/action/minage', 'Raid shield + account-age gate'),
                            ('verifysetup <role>', 'Captcha verification panel'),
                            ('backup create/list/restore', 'Backup & restore roles/channels (auto every 6h)')],
               'description': 'Whitelist, raid shield, captcha verify and nuke recovery.'},
 'Music': {'color': 'primary',
           'commands': [('play <song/link>', 'Play a song or playlist'),
                        ('pause / resume', 'Pause or resume'),
                        ('skip / skipto <n>', 'Skip songs'),
                        ('stop', 'Stop and clear queue'),
                        ('queue', 'Show queue'),
                        ('nowplaying', 'Current song'),
                        ('volume <1-150>', 'Set volume'),
                        ('loop <off/track/queue>', 'Loop mode'),
                        ('shuffle', 'Shuffle queue'),
                        ('remove <n>', 'Remove from queue'),
                        ('filter <name>', 'bass/nightcore/slowed/8d/vaporwave'),
                        ('247', 'Stay in VC 24/7'),
                        ('musicsetup', 'Create a music request channel'),
                        ('join / leave', 'Join or leave VC')],
           'description': 'High quality music with filters, 24/7 mode and a request channel.'},
 'Voice': {'color': 'primary',
           'commands': [('vcmute / vcunmute', 'Mute a member in VC'),
                        ('vcdeafen / vcundeafen', 'Deafen a member'),
                        ('vckick', 'Kick from VC'),
                        ('vcmove <user> <vc>', 'Move a member'),
                        ('vcpull <user>', 'Pull to your VC'),
                        ('vcmoveall <vc>', 'Move everyone'),
                        ('vcmuteall / vcunmuteall', 'Mute/unmute all'),
                        ('vclimit <n>', 'Set VC limit'),
                        ('vctime / vctop', 'Voice time tracking'),
                        ('vcinfo', 'VC info'),
                        ('setvc', 'Create a voice hub')],
           'description': 'Voice channel moderation tools (VoiceMaster join-to-create is in its own category).'},
 'ModPlus': {'color': 'danger',
             'commands': [('warn / warnings / delwarn / clearwarns', 'Warning system with auto-punish'),
                          ('timeout <user> <10m>', 'Timeout a member'),
                          ('untimeout', 'Remove timeout'),
                          ('tempban <user> <1d>', 'Temporary ban'),
                          ('softban', 'Ban+unban to purge messages'),
                          ('slowmode <s>', 'Set slowmode'),
                          ('nick', 'Change nickname'),
                          ('nuke', 'Wipe channel'),
                          ('lockdown / unlockdown', 'Lock all channels (raid mode)'),
                          ('unbanall', 'Unban everyone (owner)')],
             'description': 'Extra moderation: warnings, temp-bans, lockdown and more.'},
 'Fun': {'color': 'success',
         'commands': [('8ball', 'Ask the 8ball'),
                      ('coinflip / dice / rps', 'Mini games'),
                      ('ship / rate / iq', 'Fun ratings'),
                      ('meme / joke / topic', 'Memes & jokes'),
                      ('truth / dare / wyr', 'Party games'),
                      ('action <hug/kiss/pat..>', 'Anime GIF actions'),
                      ('reverse / mock / emojify', 'Text fun'),
                      ('roast', 'Friendly roast')],
         'description': 'Games and fun commands for your community.'},
 'Economy': {'color': 'primary',
             'commands': [('balance', 'Check coins'),
                          ('daily / work / crime', 'Earn coins'),
                          ('rob <user>', 'Rob someone'),
                          ('deposit / withdraw', 'Bank'),
                          ('pay <user> <n>', 'Give coins'),
                          ('bet / slots', 'Gamble'),
                          ('richest', 'Leaderboard')],
             'description': 'A full economy system per server.'},
 'Leveling': {'color': 'primary',
              'commands': [('rank', 'Your level'),
                           ('leaderboard', 'XP top 10'),
                           ('levelrole <lvl> <role>', 'Role rewards'),
                           ('levelchannel <#ch>', 'Announce channel'),
                           ('leveling on/off', 'Toggle system')],
              'description': 'XP and levels with role rewards.'},
 'Tickets': {'color': 'primary',
             'commands': [('ticketsetup <#panel> <@role> [#logs]', 'Create ticket panel'),
                          ('ticketadd / ticketremove', 'Manage ticket members')],
             'description': 'Support tickets with transcripts.'},
 'ServerTools': {'color': 'primary',
                 'commands': [('autorole <human/bot> <role>', 'Auto role on join'),
                              ('starboard <#ch> [n]', 'Starboard'),
                              ('setsuggest / suggest', 'Suggestions'),
                              ('sticky / unsticky', 'Sticky message'),
                              ('setcounting <#ch>', 'Counting game'),
                              ('modmailsetup <@staff>', 'Modmail via DMs'),
                              ('confessionsetup / confess', 'Anonymous confessions'),
                              ('roleall / removeall', 'Bulk roles'),
                              ('stickyroles on/off', 'Restore roles on rejoin'),
                              ('buttonroles <roles>', 'Button role panel'),
                              ('statschannel <kind>', 'Live counters'),
                              ('birthday set DD-MM', 'Birthdays'),
                              ('setlogs <#ch>', 'Server logs'),
                              ('removelogs', 'Disable logs')],
                 'description': 'Autorole, starboard, suggestions, sticky messages and counting.'},
 'Tools': {'color': 'success',
           'commands': [('poll', 'Create polls'),
                        ('ask <question>', 'ZYRO AI (needs API key)'),
                        ('aichannel <#ch>', 'AI auto-reply channel'),
                        ('calc', 'Calculator'),
                        ('weather <city>', 'Weather'),
                        ('qr <text>', 'QR code'),
                        ('roleinfo / channelinfo', 'Info'),
                        ('membercount', 'Members'),
                        ('servericon / userbanner', 'Images'),
                        ('zyro', 'About ZYRO')],
           'description': 'Handy utilities.'},
 'Roles': {'color': 'primary',
           'commands': [('roles selection', 'Create a self-role menu with a list of roles')],
           'Usage': '+roles selection @Valorant @Minecraft @CSGO'},
 'Social': {'color': 'success',
            'commands': [('remind', 'Set reminders'),
                         ('remind list', 'List your active reminders'),
                         ('translate', 'Translate text to English (default) or any language')],
            'description': 'Soical Commands to interact with members and provide fun features like reminders and translation.'},
 'Embed': {'color': 'success',
           'commands': [('embed create', 'Create and manage personalized embeds.')],
           'description': 'Create custom embeds with a user-friendly interface for announcements, promotions, and more.'},
 'Tracker': {'color': 'primary',
             'commands': [('invites', 'Check your invites'),
                          ('inviter', 'See who invited you'),
                          ('invited', 'See who you invited'),
                          ('inviteinfo', 'Get invite information'),
                          ('addinvites', 'Add invite count'),
                          ('removeinvites', 'Remove invite count'),
                          ('messages', 'Check message count'),
                          ('addmessages', 'Add message count'),
                          ('removemessages', 'Remove message count'),
                          ('clearmessages', 'Clear message counts'),
                          ('resetmymessages', 'Reset your message count')],
             'description': 'Track invites, messages, and member activity to reward active users.'},
 'Pfp': {'color': 'success',
         'commands': [('boys', 'Random boy profile pictures'),
                      ('girls', 'Random girl profile pictures'),
                      ('couples', 'Random couple pictures'),
                      ('anime', 'Random anime profile pictures'),
                      ('pic', 'Random pictures')],
         'description': 'Get random profile pictures from various categories.'},
 'Welcome': {'color': 'success',
             'commands': [('greet setup', 'Setup welcome message'),
                          ('greet reset', 'Reset welcome settings'),
                          ('greet channel', 'Set welcome channel'),
                          ('greet edit', 'Edit welcome message'),
                          ('greet test', 'Test welcome message'),
                          ('greet config', 'View welcome config'),
                          ('greet autodelete', 'Set auto-delete timer')],
             'description': 'Setup automatic welcome messages for new members.'},
 'VoiceMaster': {'color': 'primary',
                 'commands': [('voicemaster setup', 'Setup voice channels'), ('voicemaster remove', 'Remove voice channels')],
                 'description': 'Manage and create temporary voice channels.'},
 'Autoresponder': {'color': 'success',
                   'commands': [('ar add', 'Add auto-response'),
                                ('ar remove', 'Remove auto-response'),
                                ('ar list', 'List all auto-responses')],
                   'description': 'Setup automatic responses to specific keywords.'},
 'Autoreact': {'color': 'primary',
               'commands': [('react add', 'Add auto-reaction'),
                            ('react remove', 'Remove auto-reaction'),
                            ('react list', 'List all auto-reactions')],
               'description': 'Setup automatic reactions to specific words.'}}


for _n, _d in CATEGORY_COMMANDS.items():          # normalise entries (some had 'Usage' instead of 'description')
    _d.setdefault("description", ("Example: " + _d["Usage"]) if _d.get("Usage") else f"{_n} commands")
    _d.setdefault("color", "primary")


def cat_color(name):
    return COLORS.get(CATEGORY_COMMANDS[name].get("color", "primary"), 0x7B2FFF)


def pages_of(name):
    cmds = CATEGORY_COMMANDS[name]["commands"]
    return [cmds[i:i + PER_PAGE] for i in range(0, len(cmds), PER_PAGE)] or [[]]


def search(query: str):
    q = query.lower().strip()
    hits = []
    for cat, d in CATEGORY_COMMANDS.items():
        for cmd, desc in d["commands"]:
            if q in cmd.lower() or q in desc.lower():
                hits.append((cat, cmd, desc))
    return hits


class SearchModal(discord.ui.Modal, title="Search commands"):
    q = discord.ui.TextInput(label="What do you need?", placeholder="e.g. ban, music, ticket, premium", max_length=40)

    def __init__(self, view):
        super().__init__()
        self.hv = view

    async def on_submit(self, i: discord.Interaction):
        self.hv.mode, self.hv.query = "search", str(self.q)
        self.hv.build()
        await i.response.edit_message(embed=self.hv.embed(), view=self.hv)


class HelpView(discord.ui.View):
    def __init__(self, ctx, prefix):
        super().__init__(timeout=180)
        self.ctx, self.prefix = ctx, prefix
        self.bot = ctx.bot
        self.mode, self.cat, self.page, self.query = "home", None, 0, ""
        self.names = list(CATEGORY_COMMANDS)
        self.message = None
        self.premium_here = False
        self.build()

    # ---------- components ----------
    def build(self):
        self.clear_items()
        sel = discord.ui.Select(
            placeholder="📂 Choose a category…", row=0,
            options=[discord.SelectOption(label=n, value=n, emoji=EMOJI.get(n), default=(n == self.cat),
                                          description=CATEGORY_COMMANDS[n]["description"][:90]) for n in self.names])
        sel.callback = self.on_select
        self.add_item(sel)
        for label, emoji, style, cb in (("Prev", "◀️", discord.ButtonStyle.secondary, self.prev_cat),
                                        ("Home", "🏠", discord.ButtonStyle.primary, self.go_home),
                                        ("Next", "▶️", discord.ButtonStyle.secondary, self.next_cat),
                                        ("Search", "🔎", discord.ButtonStyle.success, self.open_search),
                                        ("Close", "🗑️", discord.ButtonStyle.danger, self.close)):
            b = discord.ui.Button(label=label, emoji=emoji, style=style, row=1)
            b.callback = cb
            self.add_item(b)
        if self.mode == "cat" and len(pages_of(self.cat)) > 1:
            n = len(pages_of(self.cat))
            for label, d in (("◀ Page", -1), ("Page ▶", 1)):
                b = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary, row=2, disabled=not (0 <= self.page + d < n))
                b.callback = self._pager(d)
                self.add_item(b)
        inv = INVITE_LINK or f"https://discord.com/oauth2/authorize?client_id={self.bot.user.id}&permissions=8&scope=bot%20applications.commands"
        self.add_item(discord.ui.Button(label="Invite", emoji="➕", style=discord.ButtonStyle.link, url=inv, row=3))
        if SUPPORT_LINK:
            self.add_item(discord.ui.Button(label="Support", emoji="🛟", style=discord.ButtonStyle.link, url=SUPPORT_LINK, row=3))

    async def interaction_check(self, i: discord.Interaction) -> bool:
        if i.user.id != self.ctx.author.id:
            await i.response.send_message(f"Run `{self.prefix}help` yourself to use this menu.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        if self.message:
            try:
                await self.message.edit(view=None)
            except Exception:
                pass

    async def refresh(self, i):
        self.build()
        await i.response.edit_message(embed=self.embed(), view=self)

    # ---------- callbacks ----------
    async def on_select(self, i):
        self.mode, self.cat, self.page = "cat", i.data["values"][0], 0
        await self.refresh(i)

    async def go_home(self, i):
        self.mode, self.cat, self.page = "home", None, 0
        await self.refresh(i)

    async def _step(self, i, d):
        idx = self.names.index(self.cat) if self.cat else (0 if d > 0 else 0)
        idx = (idx + d) % len(self.names) if self.cat else (0 if d > 0 else len(self.names) - 1)
        self.mode, self.cat, self.page = "cat", self.names[idx], 0
        await self.refresh(i)

    async def prev_cat(self, i):
        await self._step(i, -1)

    async def next_cat(self, i):
        await self._step(i, 1)

    def _pager(self, d):
        async def cb(i):
            self.page += d
            await self.refresh(i)
        return cb

    async def open_search(self, i):
        await i.response.send_modal(SearchModal(self))

    async def close(self, i):
        await i.response.edit_message(view=None)
        self.stop()
        try:
            await i.message.delete()
        except Exception:
            pass

    # ---------- embeds ----------
    def home_embed(self):
        b, u = self.bot, self.ctx.author
        total = sum(len(d["commands"]) for d in CATEGORY_COMMANDS.values())
        e = discord.Embed(color=0x7B2FFF, title="✦ ᴢʏʀᴏ  ━  ᴀʟʟ-ɪɴ-ᴏɴᴇ  ✦")
        e.description = (
            f"**Hey {u.display_name}!** I'm **ZYRO** — security, music, moderation, economy and much more.\n\n"
            f"```ansi\n\u001b[1;35m➤ Prefix\u001b[0m   {self.prefix}\n\u001b[1;35m➤ Slash \u001b[0m   /  (most commands)\n"
            f"\u001b[1;35m➤ Servers\u001b[0m  {len(b.guilds)}\n\u001b[1;35m➤ Users  \u001b[0m  {sum(g.member_count or 0 for g in b.guilds):,}\n"
            f"\u001b[1;35m➤ Commands\u001b[0m {total}+\n\u001b[1;35m➤ Ping   \u001b[0m  {round(b.latency * 1000)}ms\n```"
            f"{'💎 **ZYRO+++ is ACTIVE in this server**' if self.premium_here else '💎 *ZYRO+++ premium not active here — see* `' + self.prefix + 'premium`'}"
        )
        for title, names in GROUPS.items():
            e.add_field(name=title, value="  ".join(f"{EMOJI.get(n, '•')} `{n}`" for n in names if n in CATEGORY_COMMANDS), inline=False)
        e.add_field(name="💡 Tips", value=f"`{self.prefix}help <command>` details • 🔎 Search button • `{self.prefix}zyrocheck` security check", inline=False)
        e.set_thumbnail(url=b.user.display_avatar.url)
        e.set_footer(text="Development by ARIAN • pick a category below")
        return e

    def cat_embed(self):
        d = CATEGORY_COMMANDS[self.cat]
        pages = pages_of(self.cat)
        self.page = max(0, min(self.page, len(pages) - 1))
        lines = []
        for cmd, desc in pages[self.page]:
            badge = " 💎" if "PREMIUM" in desc.upper() or self.cat == "Premium" else ""
            lines.append(f"➤ **`{self.prefix}{cmd}`**{badge}\n　{desc}")
        e = discord.Embed(color=cat_color(self.cat), title=f"{EMOJI.get(self.cat, '•')}  {self.cat}", description=f"*{d['description']}*\n\n" + "\n".join(lines))
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        e.set_footer(text=f"Page {self.page + 1}/{len(pages)} • {len(d['commands'])} commands • Development by ARIAN")
        return e

    def search_embed(self):
        hits = search(self.query)
        e = discord.Embed(color=0x2ECC71, title=f"🔎 Results for “{self.query}”")
        if not hits:
            e.description = "Nothing found. Try a shorter word, e.g. `ban`, `music`, `role`."
        else:
            e.description = "\n".join(f"{EMOJI.get(c, '•')} **`{self.prefix}{cmd}`** — {desc}" for c, cmd, desc in hits[:12])
            if len(hits) > 12:
                e.set_footer(text=f"+{len(hits) - 12} more • narrow your search")
        return e

    def embed(self):
        return {"home": self.home_embed, "cat": self.cat_embed, "search": self.search_embed}[self.mode]()


class HelpCog(commands.Cog, name="Help"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", aliases=["h", "menu", "commands"])
    async def help(self, ctx, *, query: str = None):
        prefix = ctx.clean_prefix if not ctx.prefix.startswith("<@") else "+"
        if query:
            cmd = self.bot.get_command(query.lower().lstrip(prefix))
            if cmd and not cmd.hidden:
                return await ctx.send(embed=self.cmd_embed(cmd, prefix))
            # suggestions
            hits = search(query)
            names = [c.qualified_name for c in self.bot.walk_commands()]
            close = difflib.get_close_matches(query.lower(), names, n=5, cutoff=0.5)
            e = discord.Embed(color=0xF1C40F, title=f"🔎 No exact command “{query}”")
            if close:
                e.add_field(name="Did you mean?", value=" • ".join(f"`{prefix}{c}`" for c in close), inline=False)
            if hits:
                e.add_field(name="Related", value="\n".join(f"**`{prefix}{cmd}`** — {desc}" for _, cmd, desc in hits[:6]), inline=False)
            if not close and not hits:
                e.description = f"Nothing found. Use `{prefix}help` to browse all categories."
            return await ctx.send(embed=e)
        v = HelpView(ctx, prefix)
        try:
            v.premium_here = bool(ctx.guild and await zp.guild_premium(ctx.guild.id))
        except Exception:
            pass
        v.build()
        v.message = await ctx.send(embed=v.embed(), view=v)

    def cmd_embed(self, cmd, prefix):
        e = discord.Embed(color=0x7B2FFF, title=f"📖 {prefix}{cmd.qualified_name}")
        desc = cmd.help or cmd.description or (cmd.callback.__doc__ or "").strip() or "No description."
        e.description = desc.strip().split("\n")[0][:300]
        e.add_field(name="Usage", value=f"`{prefix}{cmd.qualified_name} {cmd.signature}`".replace("  ", " "), inline=False)
        if cmd.aliases:
            e.add_field(name="Aliases", value=" ".join(f"`{a}`" for a in cmd.aliases))
        if isinstance(cmd, commands.Group):
            e.add_field(name="Subcommands", value=" ".join(f"`{c.name}`" for c in cmd.commands)[:500], inline=False)
        if cmd.cog_name:
            e.add_field(name="Module", value=cmd.cog_name)
        cd = getattr(cmd, "_buckets", None)
        if cd and getattr(cd, "_cooldown", None):
            e.add_field(name="Cooldown", value=f"{cd._cooldown.per:.0f}s")
        e.set_footer(text="Development by ARIAN • <> required  [] optional")
        return e


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
