"""ZYRO Music — yt-dlp + FFmpeg. Development by ARIAN"""
import os
import re
import random
import asyncio
import logging
from collections import deque
from dataclasses import dataclass, field

import aiosqlite
import discord
from discord.ext import commands
from yt_dlp import YoutubeDL

from zutil import embed, ok, err, fmt_dur, progress_bar, db_path
from emojis import MUSIC, PLAY, PAUSE, STOP, SKIP, SHUFFLE, LOOP, VOLUME

log = logging.getLogger("zyro.music")
DB = db_path("music.db")

# Optional: paste cookies.txt content into Railway variable YT_COOKIES to avoid YouTube bot-checks
COOKIE_FILE = None
if os.getenv("YT_COOKIES"):
    COOKIE_FILE = "/tmp/yt_cookies.txt"
    with open(COOKIE_FILE, "w", encoding="utf-8") as _f:
        _f.write(os.getenv("YT_COOKIES"))

BASE_OPTS = {
    "format": "bestaudio/best",
    "quiet": True,
    "no_warnings": True,
    "noplaylist": True,
    "default_search": "ytsearch",
    "source_address": "0.0.0.0",
    "socket_timeout": 15,
    "retries": 3,
}
if COOKIE_FILE:
    BASE_OPTS["cookiefile"] = COOKIE_FILE

FILTERS = {
    "off": "",
    "bass": "bass=g=12,dynaudnorm=f=200",
    "nightcore": "asetrate=48000*1.25,aresample=48000,atempo=1.0",
    "slowed": "asetrate=48000*0.85,aresample=48000",
    "8d": "apulsator=hz=0.125",
    "vaporwave": "asetrate=48000*0.8,aresample=48000,aecho=0.8:0.9:40:0.3",
    "treble": "treble=g=8",
}
URL_RE = re.compile(r"https?://")


@dataclass
class Track:
    title: str
    url: str
    duration: int = 0
    thumb: str = None
    requester: int = 0
    stream: str = None


@dataclass
class GuildPlayer:
    queue: deque = field(default_factory=deque)
    current: Track = None
    loop: str = "off"          # off | track | queue
    volume: float = 0.6
    filter: str = "off"
    text: discord.abc.Messageable = None
    idle_task: asyncio.Task = None
    started_at: float = 0.0
    twentyfour7: bool = False


def _extract(query: str, flat_playlist: bool = False):
    opts = dict(BASE_OPTS)
    if flat_playlist:
        opts.update({"noplaylist": False, "extract_flat": "in_playlist"})
    with YoutubeDL(opts) as y:
        return y.extract_info(query, download=False)


def _info_to_track(info: dict, requester: int) -> Track:
    return Track(
        title=info.get("title", "Unknown"),
        url=info.get("webpage_url") or info.get("url"),
        duration=info.get("duration") or 0,
        thumb=info.get("thumbnail"),
        requester=requester,
        stream=info.get("url") if info.get("webpage_url") else None,
    )


class Music(commands.Cog, name="Music"):
    """High quality music, filters, 24/7 and request-channel setup."""

    def __init__(self, bot):
        self.bot = bot
        self.players: dict[int, GuildPlayer] = {}
        self.setup_channels: dict[int, int] = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS music_setup (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS vc247 (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()
            async with db.execute("SELECT guild_id, channel_id FROM music_setup") as cur:
                for g, c in await cur.fetchall():
                    self.setup_channels[g] = c

    def player(self, guild_id: int) -> GuildPlayer:
        return self.players.setdefault(guild_id, GuildPlayer())

    # ---------- core ----------
    async def ensure_voice(self, ctx) -> discord.VoiceClient | None:
        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send(embed=err("Join a voice channel first."))
            return None
        vc = ctx.voice_client
        ch = ctx.author.voice.channel
        try:
            if vc is None:
                vc = await ch.connect(self_deaf=True)
            elif vc.channel.id != ch.id:
                await vc.move_to(ch)
        except Exception as e:
            await ctx.send(embed=err(f"Can't join that channel: `{e}`"))
            return None
        return vc

    async def resolve(self, query: str, requester: int) -> list[Track]:
        loop = asyncio.get_running_loop()
        is_url = bool(URL_RE.match(query))
        is_playlist = is_url and ("list=" in query or "/sets/" in query or "playlist" in query)
        try:
            if is_playlist:
                info = await loop.run_in_executor(None, lambda: _extract(query, True))
                tracks = []
                for e in (info.get("entries") or [])[:100]:
                    if not e:
                        continue
                    tracks.append(Track(e.get("title", "Unknown"), e.get("url") or e.get("webpage_url"),
                                        e.get("duration") or 0, None, requester))
                return tracks
            q = query if is_url else f"ytsearch1:{query}"
            info = await loop.run_in_executor(None, lambda: _extract(q))
            if "entries" in info:
                info = (info["entries"] or [None])[0]
            if info:
                return [_info_to_track(info, requester)]
        except Exception as e:
            log.warning("primary extract failed (%s) -> trying SoundCloud", str(e)[:120])
        if not is_url:
            try:
                info = await loop.run_in_executor(None, lambda: _extract(f"scsearch1:{query}"))
                if "entries" in info:
                    info = (info["entries"] or [None])[0]
                if info:
                    return [_info_to_track(info, requester)]
            except Exception as e:
                log.warning("soundcloud fallback failed: %s", str(e)[:120])
        return []

    def _ffmpeg(self, p: GuildPlayer, url: str):
        before = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"
        af = FILTERS.get(p.filter, "")
        opts = "-vn" + (f' -af "{af}"' if af else "")
        src = discord.FFmpegPCMAudio(url, before_options=before, options=opts)
        return discord.PCMVolumeTransformer(src, volume=p.volume)

    async def play_next(self, guild: discord.Guild):
        p = self.player(guild.id)
        vc = guild.voice_client
        if not vc or not vc.is_connected():
            return
        if p.idle_task:
            p.idle_task.cancel()
            p.idle_task = None

        if p.loop == "track" and p.current:
            track = p.current
        else:
            if p.loop == "queue" and p.current:
                p.queue.append(p.current)
            if not p.queue:
                p.current = None
                if not p.twentyfour7:
                    p.idle_task = asyncio.create_task(self._idle_leave(guild))
                return
            track = p.queue.popleft()

        loop = asyncio.get_running_loop()
        try:
            info = await loop.run_in_executor(None, lambda: _extract(track.url))
            if "entries" in info:
                info = info["entries"][0]
            stream = info.get("url")
            track.title = info.get("title", track.title)
            track.duration = info.get("duration") or track.duration
            track.thumb = info.get("thumbnail") or track.thumb
            source = self._ffmpeg(p, stream)
        except Exception as e:
            log.warning("play failed: %s", str(e)[:200])
            if p.text:
                await p.text.send(embed=err(f"Couldn't play **{track.title}**, skipping."), delete_after=15)
            p.current = None
            return await self.play_next(guild)

        p.current = track
        p.started_at = loop.time()

        def after(error):
            if error:
                log.warning("player error: %s", error)
            fut = asyncio.run_coroutine_threadsafe(self.play_next(guild), self.bot.loop)
            try:
                fut.result()
            except Exception:
                pass

        vc.play(source, after=after)
        if p.text and p.loop != "track":
            await p.text.send(embed=self.np_embed(guild, track))

    async def _idle_leave(self, guild: discord.Guild):
        try:
            await asyncio.sleep(180)
            vc = guild.voice_client
            if vc and not vc.is_playing():
                await vc.disconnect()
        except asyncio.CancelledError:
            pass

    def np_embed(self, guild, track: Track) -> discord.Embed:
        p = self.player(guild.id)
        e = embed(f"{MUSIC} Now Playing", f"**[{track.title}]({track.url})**")
        e.add_field(name="Duration", value=fmt_dur(track.duration))
        e.add_field(name="Requested by", value=f"<@{track.requester}>")
        e.add_field(name="Loop", value=p.loop.title())
        e.add_field(name="Filter", value=p.filter.title())
        e.add_field(name="Volume", value=f"{int(p.volume * 100)}%")
        if track.thumb:
            e.set_thumbnail(url=track.thumb)
        return e

    async def _play(self, ctx, query: str):
        vc = await self.ensure_voice(ctx)
        if not vc:
            return
        p = self.player(ctx.guild.id)
        p.text = ctx.channel
        async with ctx.typing():
            tracks = await self.resolve(query, ctx.author.id)
        if not tracks:
            return await ctx.send(embed=err("No results (YouTube may be blocking this server — see README: YT_COOKIES)."))
        for t in tracks:
            p.queue.append(t)
        if len(tracks) > 1:
            await ctx.send(embed=ok(f"Queued **{len(tracks)}** tracks from playlist."))
        elif vc.is_playing() or vc.is_paused():
            await ctx.send(embed=embed(f"{MUSIC} Added to queue", f"**[{tracks[0].title}]({tracks[0].url})**\nPosition: `{len(p.queue)}`"))
        if not vc.is_playing() and not vc.is_paused():
            await self.play_next(ctx.guild)

    # ---------- commands ----------
    @commands.hybrid_command(name="play", aliases=["p"], description="Play a song or add it to the queue")
    @commands.guild_only()
    async def play(self, ctx, *, query: str):
        await self._play(ctx, query)

    @commands.hybrid_command(name="join", aliases=["connect", "summon"], description="Make ZYRO join your voice channel")
    @commands.guild_only()
    async def join(self, ctx):
        vc = await self.ensure_voice(ctx)
        if vc:
            await ctx.send(embed=ok(f"Joined **{vc.channel.name}**"))

    @commands.hybrid_command(name="leave", aliases=["dc", "disconnect", "fuckoff"], description="Disconnect and clear queue")
    @commands.guild_only()
    async def leave(self, ctx):
        if not ctx.voice_client:
            return await ctx.send(embed=err("I'm not in a voice channel."))
        self.players.pop(ctx.guild.id, None)
        await ctx.voice_client.disconnect()
        await ctx.send(embed=ok("Disconnected."))

    @commands.hybrid_command(name="pause", description="Pause the music")
    @commands.guild_only()
    async def pause(self, ctx):
        vc = ctx.voice_client
        if vc and vc.is_playing():
            vc.pause()
            return await ctx.send(embed=ok(f"{PAUSE} Paused."))
        await ctx.send(embed=err("Nothing is playing."))

    @commands.hybrid_command(name="resume", aliases=["unpause"], description="Resume the music")
    @commands.guild_only()
    async def resume(self, ctx):
        vc = ctx.voice_client
        if vc and vc.is_paused():
            vc.resume()
            return await ctx.send(embed=ok(f"{PLAY} Resumed."))
        await ctx.send(embed=err("Nothing is paused."))

    @commands.hybrid_command(name="skip", aliases=["s", "next"], description="Skip the current song")
    @commands.guild_only()
    async def skip(self, ctx):
        vc = ctx.voice_client
        if vc and (vc.is_playing() or vc.is_paused()):
            p = self.player(ctx.guild.id)
            if p.loop == "track":
                p.loop = "off"
            vc.stop()
            return await ctx.send(embed=ok(f"{SKIP} Skipped."))
        await ctx.send(embed=err("Nothing is playing."))

    @commands.hybrid_command(name="stop", description="Stop music and clear the queue")
    @commands.guild_only()
    async def stop(self, ctx):
        vc = ctx.voice_client
        if not vc:
            return await ctx.send(embed=err("I'm not in a voice channel."))
        p = self.player(ctx.guild.id)
        p.queue.clear()
        p.loop = "off"
        p.current = None
        if vc.is_playing() or vc.is_paused():
            vc.stop()
        await ctx.send(embed=ok(f"{STOP} Stopped and cleared the queue."))

    @commands.hybrid_command(name="queue", aliases=["q"], description="Show the queue")
    @commands.guild_only()
    async def queue(self, ctx, page: int = 1):
        p = self.player(ctx.guild.id)
        if not p.current and not p.queue:
            return await ctx.send(embed=err("Queue is empty."))
        items = list(p.queue)
        per = 10
        pages = max(1, (len(items) + per - 1) // per)
        page = max(1, min(page, pages))
        lines = [f"`{i}.` [{t.title[:55]}]({t.url}) • `{fmt_dur(t.duration)}`"
                 for i, t in enumerate(items[(page - 1) * per: page * per], start=(page - 1) * per + 1)]
        desc = (f"**Now:** [{p.current.title}]({p.current.url})\n\n" if p.current else "") + ("\n".join(lines) or "*Nothing up next*")
        e = embed(f"{MUSIC} Queue — {len(items)} track(s)", desc)
        e.set_footer(text=f"Page {page}/{pages} • Loop: {p.loop} • Filter: {p.filter}")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="nowplaying", aliases=["np"], description="Show the current song")
    @commands.guild_only()
    async def nowplaying(self, ctx):
        p = self.player(ctx.guild.id)
        if not p.current:
            return await ctx.send(embed=err("Nothing is playing."))
        e = self.np_embed(ctx.guild, p.current)
        pos = int(asyncio.get_running_loop().time() - p.started_at)
        e.add_field(name="Progress", value=f"`{fmt_dur(pos)}` {progress_bar(pos, p.current.duration)} `{fmt_dur(p.current.duration)}`", inline=False)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="volume", aliases=["vol"], description="Set volume (1-150)")
    @commands.guild_only()
    async def volume(self, ctx, level: int):
        if not 1 <= level <= 150:
            return await ctx.send(embed=err("Volume must be between 1 and 150."))
        p = self.player(ctx.guild.id)
        p.volume = level / 100
        vc = ctx.voice_client
        if vc and vc.source and isinstance(vc.source, discord.PCMVolumeTransformer):
            vc.source.volume = p.volume
        await ctx.send(embed=ok(f"{VOLUME} Volume set to **{level}%**"))

    @commands.hybrid_command(name="loop", aliases=["repeat"], description="Loop: off / track / queue")
    @commands.guild_only()
    async def loop(self, ctx, mode: str = None):
        p = self.player(ctx.guild.id)
        order = ["off", "track", "queue"]
        mode = (mode or order[(order.index(p.loop) + 1) % 3]).lower()
        if mode not in order:
            return await ctx.send(embed=err("Use `off`, `track` or `queue`."))
        p.loop = mode
        await ctx.send(embed=ok(f"{LOOP} Loop mode: **{mode}**"))

    @commands.hybrid_command(name="shuffle", description="Shuffle the queue")
    @commands.guild_only()
    async def shuffle(self, ctx):
        p = self.player(ctx.guild.id)
        if len(p.queue) < 2:
            return await ctx.send(embed=err("Not enough songs to shuffle."))
        items = list(p.queue)
        random.shuffle(items)
        p.queue = deque(items)
        await ctx.send(embed=ok(f"{SHUFFLE} Queue shuffled."))

    @commands.hybrid_command(name="remove", description="Remove a song from the queue by position")
    @commands.guild_only()
    async def remove(self, ctx, position: int):
        p = self.player(ctx.guild.id)
        if not 1 <= position <= len(p.queue):
            return await ctx.send(embed=err("Invalid position."))
        items = list(p.queue)
        t = items.pop(position - 1)
        p.queue = deque(items)
        await ctx.send(embed=ok(f"Removed **{t.title}**"))

    @commands.hybrid_command(name="clearqueue", aliases=["cq"], description="Clear the queue")
    @commands.guild_only()
    async def clearqueue(self, ctx):
        self.player(ctx.guild.id).queue.clear()
        await ctx.send(embed=ok("Queue cleared."))

    @commands.hybrid_command(name="skipto", description="Skip to a position in the queue")
    @commands.guild_only()
    async def skipto(self, ctx, position: int):
        p = self.player(ctx.guild.id)
        if not 1 <= position <= len(p.queue):
            return await ctx.send(embed=err("Invalid position."))
        for _ in range(position - 1):
            p.queue.popleft()
        if ctx.voice_client:
            ctx.voice_client.stop()
        await ctx.send(embed=ok(f"Skipped to position **{position}**."))

    @commands.hybrid_command(name="filter", aliases=["fx"], description="Audio filter: off/bass/nightcore/slowed/8d/vaporwave/treble")
    @commands.guild_only()
    async def filter(self, ctx, name: str = "off"):
        name = name.lower()
        if name not in FILTERS:
            return await ctx.send(embed=err("Filters: " + ", ".join(f"`{k}`" for k in FILTERS)))
        p = self.player(ctx.guild.id)
        p.filter = name
        await ctx.send(embed=ok(f"Filter **{name}** will apply from the next song (use `skip`)."))

    @commands.hybrid_command(name="247", aliases=["stay"], description="Toggle 24/7 mode (bot stays in VC)")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def twentyfour(self, ctx):
        vc = await self.ensure_voice(ctx)
        if not vc:
            return
        p = self.player(ctx.guild.id)
        p.twentyfour7 = not p.twentyfour7
        async with aiosqlite.connect(DB) as db:
            if p.twentyfour7:
                await db.execute("INSERT OR REPLACE INTO vc247 VALUES (?, ?)", (ctx.guild.id, vc.channel.id))
            else:
                await db.execute("DELETE FROM vc247 WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok(f"24/7 mode **{'enabled' if p.twentyfour7 else 'disabled'}**"))

    @commands.hybrid_command(name="musicsetup", aliases=["setupmusic"], description="Create a music request channel")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def musicsetup(self, ctx):
        ch = await ctx.guild.create_text_channel(
            "🎵・zyro-music",
            topic="Type a song name or link here — ZYRO will play it. Join a voice channel first!",
            reason="ZYRO music setup",
        )
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO music_setup VALUES (?, ?)", (ctx.guild.id, ch.id))
            await db.commit()
        self.setup_channels[ctx.guild.id] = ch.id
        await ch.send(embed=embed(f"{MUSIC} ZYRO Music", "Just type a **song name** or **link** in this channel.\nJoin a voice channel first.\n\nOther controls: `+skip` `+pause` `+resume` `+queue` `+stop` `+loop`"))
        await ctx.send(embed=ok(f"Music channel created: {ch.mention}"))

    @commands.hybrid_command(name="musicsetupremove", description="Remove the music request channel setting")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def musicsetupremove(self, ctx):
        self.setup_channels.pop(ctx.guild.id, None)
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM music_setup WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok("Music channel setting removed (channel itself was not deleted)."))

    # ---------- listeners ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        if self.setup_channels.get(message.guild.id) != message.channel.id:
            return
        ctx = await self.bot.get_context(message)
        if ctx.valid:   # real command, let it run
            return
        content = message.content.strip()
        if not content:
            return
        try:
            await message.delete()
        except Exception:
            pass
        await self._play(ctx, content)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        guild = member.guild
        vc = guild.voice_client
        if not vc or member.bot:
            return
        p = self.player(guild.id)
        if p.twentyfour7:
            return
        humans = [m for m in vc.channel.members if not m.bot]
        if not humans:
            await asyncio.sleep(60)
            vc = guild.voice_client
            if vc and not [m for m in vc.channel.members if not m.bot]:
                self.players.pop(guild.id, None)
                await vc.disconnect()

    @commands.Cog.listener()
    async def on_ready(self):
        # restore 24/7 connections after restart
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT guild_id, channel_id FROM vc247") as cur:
                rows = await cur.fetchall()
        for gid, cid in rows:
            g = self.bot.get_guild(gid)
            ch = g.get_channel(cid) if g else None
            if ch and not g.voice_client:
                try:
                    await ch.connect(self_deaf=True)
                    self.player(gid).twentyfour7 = True
                except Exception:
                    pass


async def setup(bot):
    await bot.add_cog(Music(bot))
