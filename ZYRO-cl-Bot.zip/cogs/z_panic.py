"""ZYRO Panic button + admin audit. Development by ARIAN"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, warn, db_path
from cogs.anti_wl import is_trusted

DB = db_path("panic.db")
DANGER = ("administrator", "manage_guild", "manage_roles", "manage_channels", "ban_members", "kick_members",
          "manage_webhooks", "mention_everyone", "manage_messages", "moderate_members")


class Confirm(discord.ui.View):
    def __init__(self, author_id):
        super().__init__(timeout=30)
        self.author_id, self.value = author_id, None

    async def interaction_check(self, i):
        if i.user.id != self.author_id:
            await i.response.send_message("Not for you.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="ACTIVATE PANIC", style=discord.ButtonStyle.danger, emoji="🚨")
    async def yes(self, i, b):
        self.value = True
        await i.response.edit_message(view=None)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def no(self, i, b):
        self.value = False
        await i.response.edit_message(content="Cancelled.", embed=None, view=None)
        self.stop()


class Panic(commands.Cog, name="Panic"):
    """Emergency button for nukes and an admin audit."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS panic_roles (guild_id INTEGER, role_id INTEGER, perms INTEGER, PRIMARY KEY (guild_id, role_id))")
            await db.commit()

    @commands.command(name="panic", aliases=["emergency"])
    @commands.guild_only()
    @commands.bot_has_permissions(administrator=True)
    async def panic(self, ctx):
        """Owner emergency: strips dangerous perms from all lower roles, kicks risky bots, deletes invites, locks channels."""
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can use panic."))
        v = Confirm(ctx.author.id)
        await ctx.send(embed=embed("🚨 PANIC MODE", "This will:\n• remove dangerous permissions from every role below mine (saved, `unpanic` restores)\n• kick other bots that have dangerous permissions\n• delete all invites\n• lock all text channels\n\nPress the button to continue.", 0xE74C3C), view=v)
        await v.wait()
        if not v.value:
            return
        g, me = ctx.guild, ctx.guild.me
        stripped = kicked = inv = locked = 0
        async with aiosqlite.connect(DB) as db:
            for r in g.roles:
                if r.is_default() or r.managed or r >= me.top_role:
                    continue
                if any(getattr(r.permissions, d) for d in DANGER):
                    await db.execute("INSERT OR REPLACE INTO panic_roles VALUES (?, ?, ?)", (g.id, r.id, r.permissions.value))
                    p = discord.Permissions(r.permissions.value)
                    for d in DANGER:
                        setattr(p, d, False)
                    try:
                        await r.edit(permissions=p, reason="ZYRO panic")
                        stripped += 1
                    except Exception:
                        pass
            await db.commit()
        for m in g.members:
            if m.bot and m.id != me.id and any(getattr(m.guild_permissions, d) for d in DANGER) and m.top_role < me.top_role:
                try:
                    await m.kick(reason="ZYRO panic")
                    kicked += 1
                except Exception:
                    pass
        try:
            for i in await g.invites():
                try:
                    await i.delete(reason="ZYRO panic")
                    inv += 1
                except Exception:
                    pass
        except Exception:
            pass
        for ch in g.text_channels:
            try:
                await ch.set_permissions(g.default_role, send_messages=False, reason="ZYRO panic")
                locked += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"**PANIC done** — roles stripped: **{stripped}**, bots kicked: **{kicked}**, invites deleted: **{inv}**, channels locked: **{locked}**.\nUse `{ctx.prefix}unpanic` when safe."))

    @commands.command(name="unpanic")
    @commands.guild_only()
    @commands.bot_has_permissions(administrator=True)
    async def unpanic(self, ctx):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can do this."))
        g = ctx.guild
        n = c = 0
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT role_id, perms FROM panic_roles WHERE guild_id=?", (g.id,)) as cur:
                rows = await cur.fetchall()
            for rid, perms in rows:
                r = g.get_role(rid)
                if r and r < g.me.top_role:
                    try:
                        await r.edit(permissions=discord.Permissions(perms), reason="ZYRO unpanic")
                        n += 1
                    except Exception:
                        pass
            await db.execute("DELETE FROM panic_roles WHERE guild_id=?", (g.id,))
            await db.commit()
        for ch in g.text_channels:
            try:
                await ch.set_permissions(g.default_role, send_messages=None, reason="ZYRO unpanic")
                c += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"Restored **{n}** roles, unlocked **{c}** channels."))

    @commands.command(name="admins", aliases=["whohasadmin", "dangerousmembers"])
    @commands.guild_only()
    async def admins(self, ctx):
        """Lists everyone who has dangerous permissions (find who could nuke you)."""
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can use this."))
        rows = []
        for m in ctx.guild.members:
            if m.id == ctx.guild.owner_id:
                continue
            p = m.guild_permissions
            perms = [d.replace("_", " ") for d in DANGER[:7] if getattr(p, d)]
            if perms:
                rows.append((not m.bot, m, perms))
        rows.sort(key=lambda x: (x[0], str(x[1])))
        if not rows:
            return await ctx.send(embed=ok("Nobody (except the owner) has dangerous permissions."))
        lines = [f"{'👤' if h else '🤖'} {m.mention} — {', '.join(p[:3])}{'…' if len(p) > 3 else ''}" for h, m, p in rows[:35]]
        await ctx.send(embed=embed(f"⚠️ Members with dangerous permissions ({len(rows)})", "\n".join(lines) + "\n\n*Only give these to people you fully trust. Bots (🤖) with admin are the #1 nuke risk.*"))


async def setup(bot):
    await bot.add_cog(Panic(bot))
