import discord
from discord.ext import commands, tasks
import aiosqlite
import os
import asyncio
import sys
from pathlib import Path

# Add parent directory to path to import main config
sys.path.insert(0, str(Path(__file__).parent.parent))
from emojis import CHECK, CROSS, LOCK, UNLOCK, GHOST, UNGHOST, CROWN

DB_PATH = __import__("os").path.join(__import__("os").getenv("DATA_DIR", "db"), "voicemaster.db")

# Make sure db folder exists
os.makedirs("db", exist_ok=True)

async def init_db():
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS voicemaster (
                    guild_id INTEGER PRIMARY KEY,
                    category_id INTEGER,
                    interface_id INTEGER,
                    joinvc_id INTEGER,
                    panel_msg_id INTEGER
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS vc_owners (
                    channel_id INTEGER PRIMARY KEY,
                    owner_id INTEGER
                )
            """)
            await db.commit()
    except Exception:
        raise  # Re-raise the exception to ensure the bot doesn't start with a broken database

from discord import ui

# =========================
# MODALS
# =========================

class RenameModal(ui.Modal, title="Rename Your Voice Channel"):
    name_input = ui.TextInput(label="Channel Name", placeholder="Enter new name...", min_length=1, max_length=100)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        try:
            await self.vc.edit(name=self.name_input.value)
            await interaction.response.send_message(f"{CHECK} Channel renamed to **{self.name_input.value}**.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed to rename: {e}", ephemeral=True)


class LimitModal(ui.Modal, title="Set User Limit"):
    limit_input = ui.TextInput(label="Limit (0-99)", placeholder="0 = No limit", min_length=1, max_length=2)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        try:
            val = int(self.limit_input.value)
            if 0 <= val <= 99:
                await self.vc.edit(user_limit=val)
                await interaction.response.send_message(f"{CHECK} User limit set to **{val}**.", ephemeral=True)
            else:
                await interaction.response.send_message(f"{CROSS} Please enter a number between 0 and 99.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid number.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)


class BanModal(ui.Modal, title="Ban User from VC"):
    user_input = ui.TextInput(label="User ID or @mention", placeholder="Paste user ID or mention...", min_length=1, max_length=100)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        raw = self.user_input.value.strip().replace("<@", "").replace("!", "").replace(">", "")
        try:
            uid = int(raw)
            member = interaction.guild.get_member(uid)
            if not member:
                return await interaction.response.send_message(f"{CROSS} User not found in this server.", ephemeral=True)
            await self.vc.set_permissions(member, connect=False, speak=False)
            if member in self.vc.members:
                try:
                    await member.move_to(None)
                except Exception:
                    pass
            await interaction.response.send_message(f"{CHECK} **{member.display_name}** has been banned from this VC.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid user ID.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)


class PermitModal(ui.Modal, title="Permit User to VC"):
    user_input = ui.TextInput(label="User ID or @mention", placeholder="Paste user ID or mention...", min_length=1, max_length=100)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        raw = self.user_input.value.strip().replace("<@", "").replace("!", "").replace(">", "")
        try:
            uid = int(raw)
            member = interaction.guild.get_member(uid)
            if not member:
                return await interaction.response.send_message(f"{CROSS} User not found in this server.", ephemeral=True)
            await self.vc.set_permissions(member, connect=True, speak=True)
            await interaction.response.send_message(f"{CHECK} **{member.display_name}** has been permitted to this VC.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid user ID.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)


class KickModal(ui.Modal, title="Kick User from VC"):
    user_input = ui.TextInput(label="User ID or @mention", placeholder="Paste user ID or mention...", min_length=1, max_length=100)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        raw = self.user_input.value.strip().replace("<@", "").replace("!", "").replace(">", "")
        try:
            uid = int(raw)
            member = interaction.guild.get_member(uid)
            if not member:
                return await interaction.response.send_message(f"{CROSS} User not found in this server.", ephemeral=True)
            if member not in self.vc.members:
                return await interaction.response.send_message(f"{CROSS} That user is not in this voice channel.", ephemeral=True)
            await member.move_to(None)
            await interaction.response.send_message(f"{CHECK} **{member.display_name}** has been kicked from the VC.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid user ID.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)


class BitrateModal(ui.Modal, title="Set Bitrate"):
    bitrate_input = ui.TextInput(label="Bitrate (kbps)", placeholder="8 - 96 (or higher if boosted)", min_length=1, max_length=3)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        try:
            val = int(self.bitrate_input.value)
            # Discord max depends on boost level; try and let API reject if too high
            if val < 8:
                return await interaction.response.send_message(f"{CROSS} Minimum bitrate is 8 kbps.", ephemeral=True)
            await self.vc.edit(bitrate=val * 1000)
            await interaction.response.send_message(f"{CHECK} Bitrate set to **{val} kbps**.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid number.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed (maybe too high for server boost level): {e}", ephemeral=True)


class RegionModal(ui.Modal, title="Set Voice Region"):
    region_input = ui.TextInput(
        label="Region",
        placeholder="auto, us-west, us-east, europe, singapore, india, japan, ...",
        min_length=2,
        max_length=20
    )

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        region = self.region_input.value.strip().lower()
        try:
            # discord.py uses rtc_region
            await self.vc.edit(rtc_region=region if region != "auto" else None)
            await interaction.response.send_message(f"{CHECK} Region set to **{region}**.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed to set region: {e}", ephemeral=True)


class TransferModal(ui.Modal, title="Transfer Ownership"):
    user_input = ui.TextInput(label="New Owner User ID or @mention", placeholder="Paste user ID or mention...", min_length=1, max_length=100)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, interaction: discord.Interaction):
        raw = self.user_input.value.strip().replace("<@", "").replace("!", "").replace(">", "")
        try:
            uid = int(raw)
            member = interaction.guild.get_member(uid)
            if not member:
                return await interaction.response.send_message(f"{CROSS} User not found in this server.", ephemeral=True)
            if member not in self.vc.members:
                return await interaction.response.send_message(f"{CROSS} New owner must be in the voice channel.", ephemeral=True)
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("UPDATE vc_owners SET owner_id=? WHERE channel_id=?", (member.id, self.vc.id))
                await db.commit()
            await interaction.response.send_message(f"{CROWN} Ownership transferred to **{member.display_name}**!", ephemeral=True)
        except ValueError:
            await interaction.response.send_message(f"{CROSS} Invalid user ID.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)


# =========================
# PREMIUM INTERFACE VIEW
# =========================

class VoiceMasterView(ui.LayoutView):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

        container = ui.Container(accent_color=0xE01E5A)  # premium red accent

        avatar_url = (
            self.bot.user.avatar.url if self.bot.user and self.bot.user.avatar
            else "https://cdn.discordapp.com/embed/avatars/0.png"
        )

        section = ui.Section(
            ui.TextDisplay("## ZYRO Voice Channel Interface"),
            ui.TextDisplay("Use this interface to manage your voice channel!"),
            accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=avatar_url))
        )
        container.add_item(section)
        container.add_item(ui.Separator())

        # Helpful legend
        container.add_item(ui.TextDisplay(
            f"**{LOCK} Lock / {UNLOCK} Unlock** — Control who can join\n"
            f"**👁 Hide / Unhide** — Make channel invisible\n"
            f"**🔥 Limit** — Set max users  •  **🚫 Ban / ✅ Permit**\n"
            f"**👢 Kick** — Disconnect a user  •  **🎧 Bitrate / 🌐 Region**\n"
            f"**{CROWN} Claim / Transfer** — Ownership controls"
        ))
        container.add_item(ui.Separator())

        # ===== Row 1: Privacy =====
        row1 = ui.ActionRow()
        lock_btn = ui.Button(label="Lock", emoji=LOCK, style=discord.ButtonStyle.secondary, custom_id="vm_lock")
        unlock_btn = ui.Button(label="Unlock", emoji=UNLOCK, style=discord.ButtonStyle.secondary, custom_id="vm_unlock")
        hide_btn = ui.Button(label="Hide", emoji="👁‍🗨", style=discord.ButtonStyle.secondary, custom_id="vm_hide")
        unhide_btn = ui.Button(label="Unhide", emoji="👁", style=discord.ButtonStyle.secondary, custom_id="vm_unhide")

        lock_btn.callback = self.lock_callback
        unlock_btn.callback = self.unlock_callback
        hide_btn.callback = self.hide_callback
        unhide_btn.callback = self.unhide_callback

        row1.add_item(lock_btn)
        row1.add_item(unlock_btn)
        row1.add_item(hide_btn)
        row1.add_item(unhide_btn)
        container.add_item(row1)

        # ===== Row 2: Management =====
        row2 = ui.ActionRow()
        limit_btn = ui.Button(label="Limit", emoji="🔥", style=discord.ButtonStyle.secondary, custom_id="vm_limit")
        ban_btn = ui.Button(label="Ban", emoji="🚫", style=discord.ButtonStyle.danger, custom_id="vm_ban")
        permit_btn = ui.Button(label="Permit", emoji="✅", style=discord.ButtonStyle.success, custom_id="vm_permit")
        kick_btn = ui.Button(label="Kick", emoji="👢", style=discord.ButtonStyle.danger, custom_id="vm_kick")

        limit_btn.callback = self.limit_callback
        ban_btn.callback = self.ban_callback
        permit_btn.callback = self.permit_callback
        kick_btn.callback = self.kick_callback

        row2.add_item(limit_btn)
        row2.add_item(ban_btn)
        row2.add_item(permit_btn)
        row2.add_item(kick_btn)
        container.add_item(row2)

        # ===== Row 3: Advanced + Ownership =====
        row3 = ui.ActionRow()
        bitrate_btn = ui.Button(label="Bitrate", emoji="🎧", style=discord.ButtonStyle.secondary, custom_id="vm_bitrate")
        region_btn = ui.Button(label="Region", emoji="🌐", style=discord.ButtonStyle.secondary, custom_id="vm_region")
        claim_btn = ui.Button(label="Claim", emoji=CROWN, style=discord.ButtonStyle.primary, custom_id="vm_claim")
        transfer_btn = ui.Button(label="Transfer", emoji="🔄", style=discord.ButtonStyle.primary, custom_id="vm_transfer")

        bitrate_btn.callback = self.bitrate_callback
        region_btn.callback = self.region_callback
        claim_btn.callback = self.claim_callback
        transfer_btn.callback = self.transfer_callback

        row3.add_item(bitrate_btn)
        row3.add_item(region_btn)
        row3.add_item(claim_btn)
        row3.add_item(transfer_btn)
        container.add_item(row3)

        self.add_item(container)

    async def interaction_checks(self, interaction: discord.Interaction):
        member = interaction.user
        if not member.voice or not member.voice.channel:
            await interaction.response.send_message(f"{CROSS} You must be in a voice channel.", ephemeral=True)
            return None

        vc = member.voice.channel
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id FROM vc_owners WHERE channel_id=?", (vc.id,)) as cursor:
                row = await cursor.fetchone()

        if not row:
            await interaction.response.send_message(f"{CROSS} This is not a managed VoiceMaster channel.", ephemeral=True)
            return None

        return vc

    async def is_owner(self, interaction: discord.Interaction, vc):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id FROM vc_owners WHERE channel_id=?", (vc.id,)) as cursor:
                row = await cursor.fetchone()
                if row and row[0] == interaction.user.id:
                    return True
        return False

    # --- Callbacks ---
    async def lock_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await vc.set_permissions(interaction.guild.default_role, connect=False)
        await interaction.response.send_message(f"{LOCK} Channel locked.", ephemeral=True)

    async def unlock_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await vc.set_permissions(interaction.guild.default_role, connect=True)
        await interaction.response.send_message(f"{UNLOCK} Channel unlocked.", ephemeral=True)

    async def hide_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await vc.set_permissions(interaction.guild.default_role, view_channel=False)
        await interaction.response.send_message(f"👁‍🗨 Channel hidden.", ephemeral=True)

    async def unhide_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await vc.set_permissions(interaction.guild.default_role, view_channel=True)
        await interaction.response.send_message(f"👁 Channel visible.", ephemeral=True)

    async def limit_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(LimitModal(vc))

    async def ban_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(BanModal(vc))

    async def permit_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(PermitModal(vc))

    async def kick_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(KickModal(vc))

    async def bitrate_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(BitrateModal(vc))

    async def region_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(RegionModal(vc))

    async def claim_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id FROM vc_owners WHERE channel_id=?", (vc.id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    owner_id = row[0]
                    owner = interaction.guild.get_member(owner_id)
                    if owner and owner in vc.members:
                        return await interaction.response.send_message(f"{CROSS} The owner is still in the channel.", ephemeral=True)
                    await db.execute("UPDATE vc_owners SET owner_id=? WHERE channel_id=?", (interaction.user.id, vc.id))
                    await db.commit()
                    await interaction.response.send_message(f"{CROWN} You are now the owner of this voice channel!", ephemeral=True)
                else:
                    await interaction.response.send_message(f"{CROSS} Could not claim this channel.", ephemeral=True)

    async def transfer_callback(self, interaction: discord.Interaction):
        vc = await self.interaction_checks(interaction)
        if not vc:
            return
        if not await self.is_owner(interaction, vc):
            return await interaction.response.send_message(f"{CROSS} You don't own this channel.", ephemeral=True)
        await interaction.response.send_modal(TransferModal(vc))


# =========================
# COG
# =========================

class VoiceMaster(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(VoiceMasterView(bot))
        self.cleanup_task.start()

    @commands.group(name="voicemaster", aliases=["vm"], invoke_without_command=True)
    async def voicemaster(self, ctx):
        await ctx.send("Use `vm setup` or `vm remove`.")

    @voicemaster.command(name="setup")
    @commands.has_permissions(administrator=True)
    async def setup(self, ctx):
        guild = ctx.guild
        bot_member = guild.me
        required_perms = discord.Permissions(manage_channels=True, move_members=True, manage_permissions=True)
        if not bot_member.guild_permissions >= required_perms:
            return await ctx.send(f"{CROSS} Bot lacks required permissions: Manage Channels, Move Members, Manage Permissions.")

        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT category_id FROM voicemaster WHERE guild_id=?", (guild.id,)) as cursor:
                if await cursor.fetchone():
                    return await ctx.send(f"{CROSS} VoiceMaster already setup.")

        try:
            category = await guild.create_category("ZYRO | VoiceMaster")
            joinvc = await category.create_voice_channel("➕ Join to Create")
            interface = await category.create_text_channel(
                "interface",
                overwrites={guild.default_role: discord.PermissionOverwrite(send_messages=False)}
            )

            view = VoiceMasterView(self.bot)
            msg = await interface.send(view=view)

            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute(
                    "INSERT OR REPLACE INTO voicemaster VALUES (?,?,?,?,?)",
                    (guild.id, category.id, interface.id, joinvc.id, msg.id)
                )
                await db.commit()
            await ctx.send(f"{CHECK} VoiceMaster setup complete. Premium interface is ready!")
        except discord.errors.Forbidden:
            await ctx.send(f"{CROSS} Bot lacks permission to create channels or send messages.")
        except Exception as e:
            await ctx.send(f"{CROSS} An error occurred during setup: {e}")

    @voicemaster.command(name="remove")
    @commands.has_permissions(administrator=True)
    async def remove(self, ctx):
        guild = ctx.guild
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                "SELECT category_id, interface_id, joinvc_id FROM voicemaster WHERE guild_id=?",
                (guild.id,)
            ) as cursor:
                row = await cursor.fetchone()
            if not row:
                return await ctx.send(f"{CROSS} VoiceMaster not setup.")
            category_id, interface_id, joinvc_id = row

        try:
            for cid in [category_id, interface_id, joinvc_id]:
                ch = guild.get_channel(cid)
                if ch:
                    await ch.delete()
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("DELETE FROM voicemaster WHERE guild_id=?", (guild.id,))
                await db.commit()
            await ctx.send(f"{CHECK} VoiceMaster removed.")
        except discord.errors.Forbidden:
            await ctx.send(f"{CROSS} Bot lacks permission to delete channels.")
        except Exception:
            await ctx.send(f"{CROSS} An error occurred during removal.")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel:
            return

        # Create personal VC when joining the join-to-create channel
        if after.channel:
            async with aiosqlite.connect(DB_PATH) as db:
                async with db.execute(
                    "SELECT joinvc_id, category_id FROM voicemaster WHERE guild_id=?",
                    (member.guild.id,)
                ) as cursor:
                    row = await cursor.fetchone()

            if row and after.channel.id == row[0]:
                joinvc_id, category_id = row
                category = member.guild.get_channel(category_id)
                if not category:
                    return

                try:
                    # Use display name (main name) instead of username
                    display = member.display_name or member.global_name or member.name
                    # Make it look premium: "ZAYAN'S Channel"
                    channel_name = f"{display}'s Channel"
                    if len(channel_name) > 100:
                        channel_name = channel_name[:97] + "..."

                    new_vc = await category.create_voice_channel(channel_name)
                    await member.move_to(new_vc)
                    async with aiosqlite.connect(DB_PATH) as db:
                        await db.execute(
                            "INSERT OR REPLACE INTO vc_owners VALUES (?,?)",
                            (new_vc.id, member.id)
                        )
                        await db.commit()
                except discord.errors.Forbidden:
                    return
                except Exception:
                    return

        # Delete empty personal VCs
        if before.channel:
            async with aiosqlite.connect(DB_PATH) as db:
                async with db.execute(
                    "SELECT owner_id FROM vc_owners WHERE channel_id=?",
                    (before.channel.id,)
                ) as cursor:
                    row = await cursor.fetchone()
                if row and len(before.channel.members) == 0:
                    try:
                        await before.channel.delete()
                        await db.execute("DELETE FROM vc_owners WHERE channel_id=?", (before.channel.id,))
                        await db.commit()
                    except discord.errors.Forbidden:
                        pass
                    except Exception:
                        pass

    @tasks.loop(hours=1.0)
    async def cleanup_task(self):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT channel_id FROM vc_owners") as cursor:
                rows = await cursor.fetchall()
            for row in rows:
                channel_id = row[0]
                channel = self.bot.get_channel(channel_id)
                if not channel or len(channel.members) == 0:
                    try:
                        if channel:
                            await channel.delete()
                        async with aiosqlite.connect(DB_PATH) as db:
                            await db.execute("DELETE FROM vc_owners WHERE channel_id=?", (channel_id,))
                            await db.commit()
                    except Exception:
                        pass

    def cog_unload(self):
        self.cleanup_task.stop()


async def setup(bot):
    try:
        await init_db()  # Initialize the database before adding the cog
        await bot.add_cog(VoiceMaster(bot))
    except Exception:
        raise
