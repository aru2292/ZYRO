"""ZYRO Server Backup & Restore (nuke recovery). Development by ARIAN"""
import json
import time
import asyncio
import aiosqlite
import discord
from discord.ext import commands, tasks
from zutil import embed, ok, err, warn, db_path
from cogs.anti_wl import is_trusted

DB = db_path("backup.db")


def snapshot(g: discord.Guild) -> dict:
    roles = [dict(name=r.name, color=r.color.value, perms=r.permissions.value, hoist=r.hoist,
                  mentionable=r.mentionable, position=r.position)
             for r in g.roles if not r.is_default() and not r.managed]
    chans = []
    for c in g.channels:
        ow = {}
        for target, o in c.overwrites.items():
            if isinstance(target, discord.Role):
                a, d = o.pair()
                ow[target.name] = [a.value, d.value]
        d = dict(name=c.name, type=c.type.value, position=c.position, overwrites=ow,
                 category=c.category.name if getattr(c, "category", None) else None)
        if isinstance(c, discord.TextChannel):
            d.update(topic=c.topic, nsfw=c.nsfw, slowmode=c.slowmode_delay)
        elif isinstance(c, discord.VoiceChannel):
            d.update(bitrate=min(c.bitrate, 96000), limit=c.user_limit)
        chans.append(d)
    return dict(name=g.name, roles=roles, channels=chans, ts=time.time())


class Backup(commands.Cog, name="Backup"):
    """Save your server structure and restore it after a nuke."""

    def __init__(self, bot):
        self.bot = bot
        self.auto.start()

    def cog_unload(self):
        self.auto.cancel()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS backups (guild_id INTEGER, label TEXT, data TEXT, ts REAL, PRIMARY KEY (guild_id, label))")
            await db.commit()

    async def store(self, g, label):
        data = json.dumps(snapshot(g))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO backups VALUES (?, ?, ?, ?)", (g.id, label, data, time.time()))
            await db.commit()

    @tasks.loop(hours=6)
    async def auto(self):
        # auto-backup every guild that has antinuke on
        try:
            async with aiosqlite.connect(db_path("anti.db")) as db:
                async with db.execute("SELECT guild_id FROM antinuke WHERE status=1") as c:
                    ids = [r[0] for r in await c.fetchall()]
        except Exception:
            return
        for gid in ids:
            g = self.bot.get_guild(gid)
            if g and len(g.channels) >= 3:      # never overwrite a good backup with an already-nuked empty server
                await self.store(g, "auto")

    @auto.before_loop
    async def _w(self):
        await self.bot.wait_until_ready()

    @commands.group(name="backup", invoke_without_command=True)
    @commands.guild_only()
    async def backup(self, ctx):
        p = ctx.prefix
        await ctx.send(embed=embed("💾 Backup", f"`{p}backup create [name]` — save roles & channels\n`{p}backup list`\n`{p}backup restore [name]` — rebuild missing roles/channels (**auto** = automatic 6h backup)\n`{p}backup delete <name>`\n\n*Restore never deletes anything, it only re-creates what is missing.*"))

    @backup.command(name="create")
    async def b_create(self, ctx, name: str = "manual"):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the Server Owner or an Extra Owner can do this."))
        await self.store(ctx.guild, name[:30])
        await ctx.send(embed=ok(f"Backup **{name}** saved ({len(ctx.guild.roles) - 1} roles, {len(ctx.guild.channels)} channels)."))

    @backup.command(name="list")
    async def b_list(self, ctx):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the Server Owner or an Extra Owner can do this."))
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT label, ts FROM backups WHERE guild_id=?", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No backups yet."))
        await ctx.send(embed=embed("💾 Backups", "\n".join(f"`{l}` — <t:{int(t)}:R>" for l, t in rows)))

    @backup.command(name="delete")
    async def b_delete(self, ctx, name: str):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the Server Owner or an Extra Owner can do this."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM backups WHERE guild_id=? AND label=?", (ctx.guild.id, name))
            await db.commit()
        await ctx.send(embed=ok("Deleted."))

    @backup.command(name="restore")
    @commands.bot_has_permissions(administrator=True)
    async def b_restore(self, ctx, name: str = "auto"):
        if ctx.author.id != ctx.guild.owner_id and not await self.bot.is_owner(ctx.author):
            return await ctx.send(embed=err("Only the **Server Owner** can restore."))
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT data FROM backups WHERE guild_id=? AND label=?", (ctx.guild.id, name)) as c:
                row = await c.fetchone()
        if not row:
            return await ctx.send(embed=err(f"Backup `{name}` not found. Use `{ctx.prefix}backup list`."))
        data = json.loads(row[0])
        g = ctx.guild
        msg = await ctx.send(embed=warn("Restoring... this can take a few minutes (Discord rate limits)."))
        made_r = made_c = 0
        # roles
        have = {r.name for r in g.roles}
        rolemap = {r.name: r for r in g.roles}
        for r in sorted(data["roles"], key=lambda x: x["position"]):
            if r["name"] in have:
                continue
            try:
                nr = await g.create_role(name=r["name"], colour=discord.Colour(r["color"]), permissions=discord.Permissions(r["perms"]),
                                         hoist=r["hoist"], mentionable=r["mentionable"], reason="ZYRO restore")
                rolemap[nr.name] = nr
                made_r += 1
                await asyncio.sleep(0.6)
            except Exception:
                pass

        def ow_of(d):
            out = {}
            for rn, (a, dn) in d.get("overwrites", {}).items():
                role = g.default_role if rn == "@everyone" else rolemap.get(rn)
                if role:
                    out[role] = discord.PermissionOverwrite.from_pair(discord.Permissions(a), discord.Permissions(dn))
            return out

        # categories first
        cats = {c.name: c for c in g.categories}
        for d in data["channels"]:
            if d["type"] == discord.ChannelType.category.value and d["name"] not in cats:
                try:
                    cats[d["name"]] = await g.create_category(d["name"], overwrites=ow_of(d), reason="ZYRO restore")
                    made_c += 1
                    await asyncio.sleep(0.6)
                except Exception:
                    pass
        existing = {(c.name, c.category.name if c.category else None) for c in g.channels if not isinstance(c, discord.CategoryChannel)}
        for d in data["channels"]:
            if d["type"] == discord.ChannelType.category.value or (d["name"], d["category"]) in existing:
                continue
            cat = cats.get(d["category"]) if d["category"] else None
            try:
                if d["type"] == discord.ChannelType.text.value:
                    await g.create_text_channel(d["name"], category=cat, topic=d.get("topic"), nsfw=d.get("nsfw", False),
                                                slowmode_delay=d.get("slowmode", 0), overwrites=ow_of(d), reason="ZYRO restore")
                elif d["type"] == discord.ChannelType.voice.value:
                    await g.create_voice_channel(d["name"], category=cat, bitrate=d.get("bitrate", 64000),
                                                 user_limit=d.get("limit", 0), overwrites=ow_of(d), reason="ZYRO restore")
                else:
                    continue
                made_c += 1
                await asyncio.sleep(0.6)
            except Exception:
                pass
        try:
            await msg.edit(embed=ok(f"Restore finished: **{made_r}** roles and **{made_c}** channels re-created."))
        except Exception:
            try:
                await ctx.author.send(f"ZYRO restore finished: {made_r} roles, {made_c} channels re-created.")
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(Backup(bot))
