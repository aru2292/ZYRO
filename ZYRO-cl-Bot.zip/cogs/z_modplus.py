"""ZYRO Moderation+ (warns, tempban, lockdown, nuke...). Development by ARIAN"""
import re
import time
import asyncio
import datetime
import aiosqlite
import discord
from discord.ext import commands, tasks
from zutil import embed, ok, err, db_path, can_act

DB = db_path("modplus.db")
DUR = re.compile(r"^(\d+)([smhdw])$")
MULT = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_dur(s: str):
    m = DUR.match(s.lower())
    return int(m.group(1)) * MULT[m.group(2)] if m else None


class ModPlus(commands.Cog, name="ModPlus"):
    """Warnings, temp-bans, lockdown, slowmode and more."""

    def __init__(self, bot):
        self.bot = bot
        self.unban_loop.start()

    def cog_unload(self):
        self.unban_loop.cancel()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS warns (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER, mod_id INTEGER, reason TEXT, ts REAL)")
            await db.execute("CREATE TABLE IF NOT EXISTS tempbans (guild_id INTEGER, user_id INTEGER, unban_at REAL, PRIMARY KEY (guild_id, user_id))")
            await db.commit()

    @tasks.loop(seconds=30)
    async def unban_loop(self):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT guild_id, user_id FROM tempbans WHERE unban_at <= ?", (time.time(),)) as c:
                rows = await c.fetchall()
            for gid, uid in rows:
                g = self.bot.get_guild(gid)
                if g:
                    try:
                        await g.unban(discord.Object(uid), reason="Tempban expired")
                    except Exception:
                        pass
                await db.execute("DELETE FROM tempbans WHERE guild_id=? AND user_id=?", (gid, uid))
            await db.commit()

    @unban_loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    # ---- warns ----
    @commands.hybrid_command(name="warn", description="Warn a member (3 warns = 1h timeout, 5 = kick)")
    @commands.has_permissions(moderate_members=True)
    @commands.guild_only()
    async def warn(self, ctx, member: discord.Member, *, reason: str = "No reason"):
        if msg := can_act(ctx, member):
            return await ctx.send(embed=err(msg))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT INTO warns (guild_id, user_id, mod_id, reason, ts) VALUES (?, ?, ?, ?, ?)", (ctx.guild.id, member.id, ctx.author.id, reason, time.time()))
            await db.commit()
            async with db.execute("SELECT COUNT(*) FROM warns WHERE guild_id=? AND user_id=?", (ctx.guild.id, member.id)) as c:
                n = (await c.fetchone())[0]
        extra = ""
        try:
            if n == 3:
                await member.timeout(datetime.timedelta(hours=1), reason="3 warnings")
                extra = "\n⏳ Auto-timeout 1h (3 warns)."
            elif n >= 5:
                await member.kick(reason="5 warnings")
                extra = "\n👢 Auto-kicked (5 warns)."
        except Exception:
            pass
        try:
            await member.send(embed=embed("⚠️ You were warned", f"**Server:** {ctx.guild.name}\n**Reason:** {reason}"))
        except Exception:
            pass
        await ctx.send(embed=ok(f"Warned {member.mention} — **{n}** warning(s).\nReason: {reason}{extra}"))

    @commands.hybrid_command(name="warnings", aliases=["warns"], description="List warnings of a member")
    @commands.has_permissions(moderate_members=True)
    @commands.guild_only()
    async def warnings(self, ctx, member: discord.Member):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT id, reason, mod_id, ts FROM warns WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 15", (ctx.guild.id, member.id)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=ok(f"{member.mention} has no warnings."))
        desc = "\n".join(f"`#{i}` <t:{int(ts)}:d> by <@{m}> — {r[:80]}" for i, r, m, ts in rows)
        await ctx.send(embed=embed(f"⚠️ Warnings — {member.display_name}", desc))

    @commands.hybrid_command(name="delwarn", description="Delete a warning by ID")
    @commands.has_permissions(moderate_members=True)
    @commands.guild_only()
    async def delwarn(self, ctx, warn_id: int):
        async with aiosqlite.connect(DB) as db:
            cur = await db.execute("DELETE FROM warns WHERE id=? AND guild_id=?", (warn_id, ctx.guild.id))
            await db.commit()
        await ctx.send(embed=ok("Warning deleted.") if cur.rowcount else err("Warning not found."))

    @commands.hybrid_command(name="clearwarns", description="Clear all warnings of a member")
    @commands.has_permissions(moderate_members=True)
    @commands.guild_only()
    async def clearwarns(self, ctx, member: discord.Member):
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM warns WHERE guild_id=? AND user_id=?", (ctx.guild.id, member.id))
            await db.commit()
        await ctx.send(embed=ok(f"Cleared warnings for {member.mention}."))

    # ---- punishments ----
    @commands.hybrid_command(name="timeout", aliases=["to", "tmute"], description="Timeout a member: timeout @user 10m reason")
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    @commands.guild_only()
    async def timeout(self, ctx, member: discord.Member, duration: str, *, reason: str = "No reason"):
        if msg := can_act(ctx, member):
            return await ctx.send(embed=err(msg))
        s = parse_dur(duration)
        if not s or s > 28 * 86400:
            return await ctx.send(embed=err("Use a duration like `30s`, `10m`, `2h`, `1d` (max 28d)."))
        await member.timeout(datetime.timedelta(seconds=s), reason=f"{ctx.author}: {reason}")
        await ctx.send(embed=ok(f"{member.mention} timed out for **{duration}**."))

    @commands.hybrid_command(name="untimeout", description="Remove a timeout")
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    @commands.guild_only()
    async def untimeout(self, ctx, member: discord.Member):
        await member.timeout(None)
        await ctx.send(embed=ok(f"Timeout removed from {member.mention}."))

    @commands.hybrid_command(name="tempban", description="Temporarily ban: tempban @user 1d reason")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    @commands.guild_only()
    async def tempban(self, ctx, member: discord.Member, duration: str, *, reason: str = "No reason"):
        if msg := can_act(ctx, member):
            return await ctx.send(embed=err(msg))
        s = parse_dur(duration)
        if not s:
            return await ctx.send(embed=err("Use a duration like `1h`, `1d`, `1w`."))
        await member.ban(reason=f"Tempban by {ctx.author}: {reason}")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO tempbans VALUES (?, ?, ?)", (ctx.guild.id, member.id, time.time() + s))
            await db.commit()
        await ctx.send(embed=ok(f"Banned **{member}** for **{duration}**."))

    @commands.hybrid_command(name="softban", description="Ban + unban to delete recent messages")
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_permissions(ban_members=True)
    @commands.guild_only()
    async def softban(self, ctx, member: discord.Member, *, reason: str = "Softban"):
        if msg := can_act(ctx, member):
            return await ctx.send(embed=err(msg))
        await member.ban(reason=reason, delete_message_days=1)
        await ctx.guild.unban(member, reason="Softban")
        await ctx.send(embed=ok(f"Softbanned **{member}**."))

    @commands.hybrid_command(name="unbanall", description="Unban everyone (owner only)")
    @commands.guild_only()
    async def unbanall(self, ctx):
        if ctx.author.id != ctx.guild.owner_id:
            return await ctx.send(embed=err("Only the server owner can do this."))
        n = 0
        async for entry in ctx.guild.bans(limit=None):
            try:
                await ctx.guild.unban(entry.user)
                n += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"Unbanned **{n}** users."))

    # ---- channel tools ----
    @commands.hybrid_command(name="slowmode", aliases=["sm"], description="Set slowmode in seconds (0 = off)")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def slowmode(self, ctx, seconds: int = 0):
        seconds = max(0, min(seconds, 21600))
        await ctx.channel.edit(slowmode_delay=seconds)
        await ctx.send(embed=ok(f"Slowmode set to **{seconds}s**."))

    @commands.hybrid_command(name="nick", aliases=["setnick"], description="Change a member's nickname")
    @commands.has_permissions(manage_nicknames=True)
    @commands.bot_has_permissions(manage_nicknames=True)
    @commands.guild_only()
    async def nick(self, ctx, member: discord.Member, *, nickname: str = None):
        await member.edit(nick=nickname)
        await ctx.send(embed=ok(f"Nickname updated for {member.mention}."))

    @commands.hybrid_command(name="nuke", description="Clone & delete this channel (wipes all messages)")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def nuke(self, ctx):
        ch = ctx.channel
        new = await ch.clone(reason=f"Nuked by {ctx.author}")
        await new.edit(position=ch.position)
        await ch.delete()
        await new.send(embed=ok("Channel nuked 💥"))

    @commands.hybrid_command(name="lockdown", description="Lock every text channel (raid emergency)")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def lockdown(self, ctx):
        n = 0
        for ch in ctx.guild.text_channels:
            try:
                await ch.set_permissions(ctx.guild.default_role, send_messages=False, reason="ZYRO lockdown")
                n += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"🔒 Lockdown active on **{n}** channels. Use `unlockdown` to end."))

    @commands.hybrid_command(name="unlockdown", description="End the lockdown")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def unlockdown(self, ctx):
        n = 0
        for ch in ctx.guild.text_channels:
            try:
                await ch.set_permissions(ctx.guild.default_role, send_messages=None, reason="ZYRO unlockdown")
                n += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"🔓 Lockdown ended on **{n}** channels."))


async def setup(bot):
    await bot.add_cog(ModPlus(bot))
