"""ZYRO Fun. Development by ARIAN"""
import random
import hashlib
import aiohttp
import discord
from discord.ext import commands
from zutil import embed, err

EIGHTBALL = ["It is certain.", "Without a doubt.", "Yes, definitely.", "Most likely.", "Signs point to yes.",
             "Reply hazy, try again.", "Ask again later.", "Cannot predict now.", "Don't count on it.",
             "My reply is no.", "Very doubtful.", "Outlook not so good."]
JOKES = ["Why do programmers prefer dark mode? Because light attracts bugs.",
         "There are 10 types of people: those who understand binary and those who don't.",
         "I would tell you a UDP joke, but you might not get it.",
         "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'",
         "Why did the bot cross the road? To get to the other prefix."]
TRUTHS = ["What's your most embarrassing moment?", "What's a secret you never told anyone?", "Who was your first crush?",
          "What's the last lie you told?", "What's your biggest fear?", "What's the weirdest dream you've had?"]
DARES = ["Send the last photo in your gallery.", "Change your nickname to 'ZYRO fan' for 1 hour.",
         "Speak only in emojis for 5 minutes.", "Type with your eyes closed for the next message.", "Sing a line of your favorite song in VC."]
WYR = ["Would you rather be invisible or fly?", "Would you rather never sleep or never eat?",
       "Would you rather lose all your money or all your memories?", "Would you rather fight 1 horse-size duck or 100 duck-size horses?"]
TOPICS = ["What's the best thing that happened to you this week?", "What's your dream job?",
          "If you could live anywhere, where?", "What game are you addicted to right now?"]
ROASTS = ["You're like a cloud — when you disappear, it's a beautiful day. (just kidding 💜)",
          "I'd agree with you but then we'd both be wrong.", "You bring everyone so much joy... when you leave the room."]
ACTIONS = {"hug": "hugs", "kiss": "kisses", "pat": "pats", "slap": "slaps", "cuddle": "cuddles", "poke": "pokes",
           "bite": "bites", "highfive": "high-fives", "wave": "waves at", "cry": "cries with"}
NEKOS = {"highfive": "highfive", "wave": "wave", "cry": "cry"}


class Fun(commands.Cog, name="Fun"):
    """Games and fun commands."""

    def __init__(self, bot):
        self.bot = bot

    async def _gif(self, action: str):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"https://nekos.best/api/v2/{action}", timeout=aiohttp.ClientTimeout(total=8)) as r:
                    data = await r.json()
                    return data["results"][0]["url"]
        except Exception:
            return None

    @commands.hybrid_command(name="8ball", description="Ask the magic 8ball")
    async def eightball(self, ctx, *, question: str):
        await ctx.send(embed=embed("🎱 8Ball", f"**Q:** {question}\n**A:** {random.choice(EIGHTBALL)}"))

    @commands.hybrid_command(name="coinflip", aliases=["flip", "cf"], description="Flip a coin")
    async def coinflip(self, ctx):
        await ctx.send(embed=embed("🪙 Coin Flip", f"It's **{random.choice(['Heads', 'Tails'])}**!"))

    @commands.hybrid_command(name="dice", aliases=["roll"], description="Roll a dice (e.g. 20)")
    async def dice(self, ctx, sides: int = 6):
        sides = max(2, min(sides, 1000))
        await ctx.send(embed=embed("🎲 Dice", f"You rolled **{random.randint(1, sides)}** (d{sides})"))

    @commands.hybrid_command(name="rps", description="Rock paper scissors")
    async def rps(self, ctx, choice: str):
        opts = {"rock": "🪨", "paper": "📄", "scissors": "✂️"}
        choice = choice.lower()
        if choice not in opts:
            return await ctx.send(embed=err("Choose rock, paper or scissors."))
        bot_c = random.choice(list(opts))
        wins = {("rock", "scissors"), ("paper", "rock"), ("scissors", "paper")}
        res = "It's a tie!" if choice == bot_c else ("You win! 🎉" if (choice, bot_c) in wins else "I win! 😎")
        await ctx.send(embed=embed("Rock Paper Scissors", f"You: {opts[choice]}  vs  Me: {opts[bot_c]}\n**{res}**"))

    @commands.hybrid_command(name="choose", description="Choose between options (separate with |)")
    async def choose(self, ctx, *, options: str):
        parts = [o.strip() for o in options.split("|") if o.strip()]
        if len(parts) < 2:
            return await ctx.send(embed=err("Give at least 2 options separated by `|`."))
        await ctx.send(embed=embed("🤔 I choose", f"**{random.choice(parts)}**"))

    @commands.hybrid_command(name="ship", description="Ship two members")
    async def ship(self, ctx, a: discord.Member, b: discord.Member = None):
        b = b or ctx.author
        h = int(hashlib.md5(f"{min(a.id, b.id)}{max(a.id, b.id)}".encode()).hexdigest(), 16) % 101
        bar = "█" * (h // 10) + "░" * (10 - h // 10)
        await ctx.send(embed=embed("💞 Ship", f"{a.mention} × {b.mention}\n`{bar}` **{h}%**"))

    @commands.hybrid_command(name="rate", description="Rate anything")
    async def rate(self, ctx, *, thing: str):
        r = int(hashlib.md5(thing.lower().encode()).hexdigest(), 16) % 11
        await ctx.send(embed=embed("⭐ Rating", f"I rate **{thing}** a **{r}/10**"))

    @commands.hybrid_command(name="iq", description="Check someone's IQ (for fun)")
    async def iq(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        v = 60 + int(hashlib.md5(str(member.id).encode()).hexdigest(), 16) % 100
        await ctx.send(embed=embed("🧠 IQ", f"{member.mention}'s IQ is **{v}**"))

    @commands.hybrid_command(name="reverse", description="Reverse text")
    async def reverse(self, ctx, *, text: str):
        await ctx.send(text[::-1][:1900], allowed_mentions=discord.AllowedMentions.none())

    @commands.hybrid_command(name="mock", description="sPoNgEbOb mOcK tExT")
    async def mock(self, ctx, *, text: str):
        await ctx.send("".join(c.upper() if i % 2 else c.lower() for i, c in enumerate(text))[:1900],
                       allowed_mentions=discord.AllowedMentions.none())

    @commands.hybrid_command(name="say", description="Make ZYRO say something")
    @commands.has_permissions(manage_messages=True)
    async def say(self, ctx, *, text: str):
        if ctx.interaction is None:
            try:
                await ctx.message.delete()
            except Exception:
                pass
        await ctx.send(text[:1900], allowed_mentions=discord.AllowedMentions.none())

    @commands.hybrid_command(name="emojify", description="Turn text into emoji letters")
    async def emojify(self, ctx, *, text: str):
        out = []
        for c in text.lower()[:60]:
            out.append(f":regional_indicator_{c}:" if c.isalpha() and c.isascii() else (" " if c == " " else c))
        await ctx.send(" ".join(out))

    @commands.hybrid_command(name="joke", description="Random joke")
    async def joke(self, ctx):
        await ctx.send(embed=embed("😂 Joke", random.choice(JOKES)))

    @commands.hybrid_command(name="truth", description="Truth question")
    async def truth(self, ctx):
        await ctx.send(embed=embed("🧐 Truth", random.choice(TRUTHS)))

    @commands.hybrid_command(name="dare", description="Dare")
    async def dare(self, ctx):
        await ctx.send(embed=embed("😈 Dare", random.choice(DARES)))

    @commands.hybrid_command(name="wyr", description="Would you rather")
    async def wyr(self, ctx):
        m = await ctx.send(embed=embed("🤷 Would You Rather", random.choice(WYR)))
        for r in ("🅰️", "🅱️"):
            await m.add_reaction(r)

    @commands.hybrid_command(name="topic", description="Conversation starter")
    async def topic(self, ctx):
        await ctx.send(embed=embed("💬 Topic", random.choice(TOPICS)))

    @commands.hybrid_command(name="roast", description="Friendly roast")
    async def roast(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        await ctx.send(f"{member.mention} {random.choice(ROASTS)}", allowed_mentions=discord.AllowedMentions(users=True))

    @commands.hybrid_command(name="meme", description="Random meme")
    async def meme(self, ctx):
        await ctx.defer()
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get("https://meme-api.com/gimme", timeout=aiohttp.ClientTimeout(total=8)) as r:
                    d = await r.json()
            if d.get("nsfw"):
                return await ctx.send(embed=err("Got an unsafe meme, try again."))
            e = embed(d.get("title", "Meme")[:250])
            e.set_image(url=d["url"])
            await ctx.send(embed=e)
        except Exception:
            await ctx.send(embed=err("Meme API is down, try later."))

    @commands.hybrid_command(name="action", aliases=["act"], description="Anime action gif: hug kiss pat slap cuddle poke bite highfive wave cry")
    async def action(self, ctx, action: str, member: discord.Member = None):
        action = action.lower()
        if action not in ACTIONS:
            return await ctx.send(embed=err("Actions: " + ", ".join(f"`{a}`" for a in ACTIONS)))
        url = await self._gif(NEKOS.get(action, action))
        who = member.mention if member else "themselves"
        e = embed(None, f"**{ctx.author.display_name}** {ACTIONS[action]} {who}")
        if url:
            e.set_image(url=url)
        await ctx.send(embed=e)

    # direct shortcuts: +hug @user etc.
    @commands.command(name="hug")
    async def hug(self, ctx, member: discord.Member = None):
        await self.action(ctx, "hug", member)

    @commands.command(name="kiss")
    async def kiss(self, ctx, member: discord.Member = None):
        await self.action(ctx, "kiss", member)

    @commands.command(name="pat")
    async def pat(self, ctx, member: discord.Member = None):
        await self.action(ctx, "pat", member)

    @commands.command(name="slap")
    async def slap(self, ctx, member: discord.Member = None):
        await self.action(ctx, "slap", member)


async def setup(bot):
    await bot.add_cog(Fun(bot))
