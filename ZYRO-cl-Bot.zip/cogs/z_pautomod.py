"""ZYRO+++ AutoMod — premium 2nd layer with per-day allowances. Development by ARIAN"""
import re
import json
import time
import datetime
from collections import defaultdict, deque

import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path
from cogs.anti_wl import is_trusted
import zpremium as zp

DB = db_path("pautomod.db")
INVITE = re.compile(r"(discord\.gg|discord(?:app)?\.com/invite|dsc\.gg)/[A-Za-z0-9-]+", re.I)
URL = re.compile(r"https?://\S+|www\.\S+", re.I)
EMOJI = re.compile(r"<a?:\w+:\d+>|[\U0001F300-\U0001FAFF\u2600-\u27BF]")
DEFAULT = {
    "spam": {"on": True, "limit": 5}, "dupes": {"on": True, "limit": 3}, "invites": {"on": True, "limit": 0},
    "links": {"on": True, "limit": 0}, "mentions": {"on": True, "limit": 5}, "caps": {"on": True, "limit": 70},
    "emojis": {"on": True, "limit": 10}, "words": {"on": True, "limit": 0},
}
HELP = {"spam": "msgs in 5s", "dupes": "same msg repeats in 20s", "invites": "discord invites", "links": "any link",
        "mentions": "mentions per message", "caps": "% caps (min 12 letters)", "emojis": "emojis per message", "words": "banned words"}
ALLOWANCE_RULES = ("invites", "links", "mentions", "emojis", "caps", "words")


class PAutomod(commands.Cog, name="ZYRO+++ AutoMod"):
    """Strict automod with per-day allowances (premium)."""

    def __init__(self, bot):
        self.bot = bot
        self.cache: dict = {}
        self.hist = defaultdict(lambda: deque(maxlen=12))
        self.strikes = defaultdict(deque)

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS pam (guild_id INTEGER PRIMARY KEY, data TEXT)")
            await db.execute("CREATE TABLE IF NOT EXISTS pam_allow (guild_id INTEGER, user_id INTEGER, rule TEXT, per_day INTEGER, PRIMARY KEY (guild_id, user_id, rule))")
            await db.execute("CREATE TABLE IF NOT EXISTS pam_used (guild_id INTEGER, user_id INTEGER, rule TEXT, day TEXT, cnt INTEGER, PRIMARY KEY (guild_id, user_id, rule, day))")
            await db.commit()

    async def conf(self, gid) -> dict:
        if gid in self.cache:
            return self.cache[gid]
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT data FROM pam WHERE guild_id=?", (gid,)) as c:
                r = await c.fetchone()
        d = json.loads(r[0]) if r else {}
        base = {"enabled": False, "punish": "timeout", "words": [], "ignore": [], "rules": json.loads(json.dumps(DEFAULT))}
        base.update({k: v for k, v in d.items() if k != "rules"})
        for k, v in d.get("rules", {}).items():
            if k in base["rules"]:
                base["rules"][k].update(v)
        self.cache[gid] = base
        return base

    async def save(self, gid):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO pam VALUES (?, ?)", (gid, json.dumps(self.cache[gid])))
            await db.commit()

    async def extra_owner(self, gid, uid):
        try:
            async with aiosqlite.connect(db_path("anti.db")) as db:
                async with db.execute("SELECT 1 FROM extraowners WHERE guild_id=? AND owner_id=?", (gid, uid)) as c:
                    return await c.fetchone() is not None
        except Exception:
            return False

    async def allowance_ok(self, gid, uid, rule) -> bool:
        """True if the user still has a daily allowance for this rule (and uses one)."""
        day = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT per_day FROM pam_allow WHERE guild_id=? AND user_id=? AND rule=?", (gid, uid, rule)) as c:
                r = await c.fetchone()
            if not r:
                return False
            if r[0] < 0:
                return True
            await db.execute("INSERT OR IGNORE INTO pam_used VALUES (?, ?, ?, ?, 0)", (gid, uid, rule, day))
            await db.execute("UPDATE pam_used SET cnt=cnt+1 WHERE guild_id=? AND user_id=? AND rule=? AND day=?", (gid, uid, rule, day))
            async with db.execute("SELECT cnt FROM pam_used WHERE guild_id=? AND user_id=? AND rule=? AND day=?", (gid, uid, rule, day)) as c:
                n = (await c.fetchone())[0]
            await db.commit()
        return n <= r[0]

    def violated(self, m: discord.Message, cfg) -> str | None:
        R, txt = cfg["rules"], m.content or ""
        low = txt.lower()
        now = time.time()
        key = (m.guild.id, m.author.id)
        h = self.hist[key]
        h.append((now, low))
        if R["spam"]["on"] and sum(1 for t, _ in h if now - t <= 5) >= R["spam"]["limit"]:
            return "spam"
        if R["dupes"]["on"] and low and sum(1 for t, x in h if now - t <= 20 and x == low) >= R["dupes"]["limit"]:
            return "dupes"
        if R["invites"]["on"] and INVITE.search(txt):
            return "invites"
        if R["links"]["on"] and URL.search(txt) and not INVITE.search(txt):
            return "links"
        if R["mentions"]["on"] and (len(m.mentions) + len(m.role_mentions)) > R["mentions"]["limit"]:
            return "mentions"
        letters = [c for c in txt if c.isalpha()]
        if R["caps"]["on"] and len(letters) >= 12 and 100 * sum(c.isupper() for c in letters) / len(letters) >= R["caps"]["limit"]:
            return "caps"
        if R["emojis"]["on"] and len(EMOJI.findall(txt)) > R["emojis"]["limit"]:
            return "emojis"
        if R["words"]["on"] and any(w in low for w in cfg["words"]):
            return "words"
        return None

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if not m.guild or m.author.bot or not m.content:
            return
        cfg = await self.conf(m.guild.id)
        if not cfg["enabled"] or m.channel.id in cfg["ignore"] or not await zp.guild_premium(m.guild.id):
            return
        if m.author.id == m.guild.owner_id or await self.extra_owner(m.guild.id, m.author.id):
            return
        rule = self.violated(m, cfg)
        if not rule:
            return
        if rule in ALLOWANCE_RULES and await self.allowance_ok(m.guild.id, m.author.id, rule):
            return
        try:
            await m.delete()
        except Exception:
            pass
        try:
            await m.channel.send(f"{m.author.mention} ⚠️ **ZYRO+++ AutoMod:** `{rule}` is not allowed here.", delete_after=6)
        except Exception:
            pass
        # strikes: 3 in 10 minutes -> punishment
        now = time.time()
        q = self.strikes[(m.guild.id, m.author.id)]
        q.append(now)
        while q and now - q[0] > 600:
            q.popleft()
        if len(q) >= 3:
            q.clear()
            try:
                if cfg["punish"] == "ban":
                    await m.guild.ban(m.author, reason="ZYRO+++ AutoMod", delete_message_days=0)
                elif cfg["punish"] == "kick":
                    await m.author.kick(reason="ZYRO+++ AutoMod")
                else:
                    await m.author.timeout(datetime.timedelta(hours=1), reason="ZYRO+++ AutoMod")
            except Exception:
                pass

    # ---------- commands ----------
    async def gate(self, ctx):
        if not await zp.guild_premium(ctx.guild.id):
            await ctx.send(embed=err("**ZYRO+++ AutoMod** needs premium. Use `+premium activate` (bot owner gives premium)."))
            return False
        if not await is_trusted(ctx):
            await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can use this."))
            return False
        return True

    @commands.group(name="pautomod", aliases=["pam", "automod+"], invoke_without_command=True)
    @commands.guild_only()
    async def pautomod(self, ctx):
        c = await self.conf(ctx.guild.id)
        lines = [f"{'🟢' if v['on'] else '🔴'} **{k}** — {HELP[k]} (`{v['limit']}`)" for k, v in c["rules"].items()]
        p = ctx.prefix
        await ctx.send(embed=embed("🤖 ZYRO+++ AutoMod", f"**Status:** {'🟢 ON' if c['enabled'] else '🔴 OFF'}   **Punish (3 strikes/10min):** `{c['punish']}`\n\n" + "\n".join(lines) +
                                   f"\n\n`{p}pam enable|disable`\n`{p}pam rule <name> on|off [limit]`\n`{p}pam punish timeout|kick|ban`\n`{p}pam allow @user <rule> <per_day>` (-1 = unlimited)\n`{p}pam word add|remove <word>`\n`{p}pam ignore #channel`"))

    @pautomod.command(name="enable", aliases=["on"])
    async def pam_on(self, ctx):
        if not await self.gate(ctx):
            return
        (await self.conf(ctx.guild.id))["enabled"] = True
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok("ZYRO+++ AutoMod **enabled** (owner & extra owners are exempt; admins are NOT)."))

    @pautomod.command(name="disable", aliases=["off"])
    async def pam_off(self, ctx):
        if not await self.gate(ctx):
            return
        (await self.conf(ctx.guild.id))["enabled"] = False
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok("ZYRO+++ AutoMod disabled."))

    @pautomod.command(name="rule")
    async def pam_rule(self, ctx, name: str, state: str, limit: int = None):
        if not await self.gate(ctx):
            return
        c = await self.conf(ctx.guild.id)
        if name not in c["rules"] or state.lower() not in ("on", "off"):
            return await ctx.send(embed=err("Rules: " + ", ".join(f"`{r}`" for r in c["rules"]) + " • state: on/off"))
        c["rules"][name]["on"] = state.lower() == "on"
        if limit is not None:
            c["rules"][name]["limit"] = max(0, min(limit, 1000))
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Rule **{name}** → {state.lower()}" + (f" (limit {limit})" if limit is not None else "")))

    @pautomod.command(name="punish")
    async def pam_punish(self, ctx, mode: str):
        if not await self.gate(ctx):
            return
        if mode.lower() not in ("timeout", "kick", "ban"):
            return await ctx.send(embed=err("Use timeout, kick or ban."))
        (await self.conf(ctx.guild.id))["punish"] = mode.lower()
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Punishment: **{mode.lower()}**"))

    @pautomod.command(name="allow")
    async def pam_allow(self, ctx, member: discord.Member, rule: str, per_day: int):
        if not await self.gate(ctx):
            return
        if rule not in ALLOWANCE_RULES:
            return await ctx.send(embed=err("Allowance rules: " + ", ".join(f"`{r}`" for r in ALLOWANCE_RULES)))
        async with aiosqlite.connect(DB) as db:
            if per_day == 0:
                await db.execute("DELETE FROM pam_allow WHERE guild_id=? AND user_id=? AND rule=?", (ctx.guild.id, member.id, rule))
            else:
                await db.execute("INSERT OR REPLACE INTO pam_allow VALUES (?, ?, ?, ?)", (ctx.guild.id, member.id, rule, per_day))
            await db.commit()
        await ctx.send(embed=ok(f"{member.mention} may break **{rule}** `{'∞' if per_day < 0 else per_day}` time(s) per day." if per_day else "Allowance removed."))

    @pautomod.command(name="word")
    async def pam_word(self, ctx, action: str, *, word: str):
        if not await self.gate(ctx):
            return
        c = await self.conf(ctx.guild.id)
        w = word.lower().strip()
        if action.lower() == "add" and w not in c["words"]:
            c["words"].append(w)
        elif action.lower() == "remove" and w in c["words"]:
            c["words"].remove(w)
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Banned words: {len(c['words'])}"))

    @pautomod.command(name="ignore")
    async def pam_ignore(self, ctx, channel: discord.TextChannel):
        if not await self.gate(ctx):
            return
        c = await self.conf(ctx.guild.id)
        if channel.id in c["ignore"]:
            c["ignore"].remove(channel.id)
            txt = "no longer ignored"
        else:
            c["ignore"].append(channel.id)
            txt = "now ignored"
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"{channel.mention} is {txt}."))


async def setup(bot):
    await bot.add_cog(PAutomod(bot))
