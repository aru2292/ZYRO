"""ZYRO Server Logs. Development by ARIAN"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path

DB = db_path("zlogs.db")


class ServerLogs(commands.Cog, name="Logs"):
    """Message, member, voice and moderation logs."""

    def __init__(self, bot):
        self.bot = bot
        self.chan: dict[int, int] = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS zlogs (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()
            async with db.execute("SELECT guild_id, channel_id FROM zlogs") as c:
                for g, ch in await c.fetchall():
                    self.chan[g] = ch

    async def send(self, guild, e: discord.Embed):
        cid = self.chan.get(guild.id)
        ch = guild.get_channel(cid) if cid else None
        if ch:
            try:
                await ch.send(embed=e)
            except Exception:
                pass

    @commands.hybrid_command(name="setlogs", aliases=["logchannel"], description="Set the server log channel")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def setlogs(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO zlogs VALUES (?, ?)", (ctx.guild.id, channel.id))
            await db.commit()
        self.chan[ctx.guild.id] = channel.id
        await ctx.send(embed=ok(f"Logs will be sent to {channel.mention}"))

    @commands.hybrid_command(name="removelogs", description="Disable server logs")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def removelogs(self, ctx):
        self.chan.pop(ctx.guild.id, None)
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM zlogs WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok("Logs disabled."))

    @commands.Cog.listener()
    async def on_message_delete(self, m: discord.Message):
        if not m.guild or m.author.bot:
            return
        e = embed("🗑️ Message Deleted", f"**Author:** {m.author.mention}\n**Channel:** {m.channel.mention}\n\n{(m.content or '*no text*')[:1500]}", 0xE74C3C)
        await self.send(m.guild, e)

    @commands.Cog.listener()
    async def on_message_edit(self, b: discord.Message, a: discord.Message):
        if not b.guild or b.author.bot or b.content == a.content:
            return
        e = embed("✏️ Message Edited", f"**Author:** {b.author.mention}\n**Channel:** {b.channel.mention} • [Jump]({a.jump_url})", 0xF1C40F)
        e.add_field(name="Before", value=(b.content or "-")[:1000], inline=False)
        e.add_field(name="After", value=(a.content or "-")[:1000], inline=False)
        await self.send(b.guild, e)

    @commands.Cog.listener()
    async def on_member_join(self, m: discord.Member):
        e = embed("📥 Member Joined", f"{m.mention} (`{m}`)\nAccount created <t:{int(m.created_at.timestamp())}:R>", 0x2ECC71)
        e.set_thumbnail(url=m.display_avatar.url)
        await self.send(m.guild, e)

    @commands.Cog.listener()
    async def on_member_remove(self, m: discord.Member):
        await self.send(m.guild, embed("📤 Member Left", f"{m.mention} (`{m}`)", 0xE67E22))

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        await self.send(guild, embed("🔨 Member Banned", f"{user.mention} (`{user}`)", 0xE74C3C))

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        await self.send(guild, embed("♻️ Member Unbanned", f"{user.mention} (`{user}`)", 0x2ECC71))

    @commands.Cog.listener()
    async def on_member_update(self, b: discord.Member, a: discord.Member):
        if b.roles != a.roles:
            added = [r.mention for r in a.roles if r not in b.roles]
            removed = [r.mention for r in b.roles if r not in a.roles]
            d = f"{a.mention}\n" + (f"**Added:** {', '.join(added)}\n" if added else "") + (f"**Removed:** {', '.join(removed)}" if removed else "")
            await self.send(a.guild, embed("🏷️ Roles Updated", d, 0x3498DB))
        elif b.nick != a.nick:
            await self.send(a.guild, embed("📝 Nickname Changed", f"{a.mention}\n`{b.nick}` → `{a.nick}`", 0x3498DB))

    @commands.Cog.listener()
    async def on_voice_state_update(self, m, b, a):
        if b.channel == a.channel:
            return
        if not b.channel:
            t = f"{m.mention} joined **{a.channel.name}**"
        elif not a.channel:
            t = f"{m.mention} left **{b.channel.name}**"
        else:
            t = f"{m.mention} moved **{b.channel.name}** → **{a.channel.name}**"
        await self.send(m.guild, embed("🔊 Voice", t, 0x9B59B6))

    @commands.Cog.listener()
    async def on_guild_channel_create(self, ch):
        await self.send(ch.guild, embed("📁 Channel Created", f"{ch.mention} (`{ch.name}`)", 0x2ECC71))

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, ch):
        await self.send(ch.guild, embed("📁 Channel Deleted", f"`{ch.name}`", 0xE74C3C))

    @commands.Cog.listener()
    async def on_guild_role_create(self, r):
        await self.send(r.guild, embed("🏷️ Role Created", f"{r.mention} (`{r.name}`)", 0x2ECC71))

    @commands.Cog.listener()
    async def on_guild_role_delete(self, r):
        await self.send(r.guild, embed("🏷️ Role Deleted", f"`{r.name}`", 0xE74C3C))


async def setup(bot):
    await bot.add_cog(ServerLogs(bot))
