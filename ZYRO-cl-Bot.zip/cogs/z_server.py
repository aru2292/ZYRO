"""ZYRO Server tools: autorole, starboard, suggestions, sticky, counting. Development by ARIAN"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path

DB = db_path("server.db")


class ServerTools(commands.Cog, name="Server"):
    """Autorole, starboard, suggestions, sticky messages and counting game."""

    def __init__(self, bot):
        self.bot = bot
        self.sticky_lock: set = set()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS autorole (guild_id INTEGER, role_id INTEGER, kind TEXT, PRIMARY KEY (guild_id, kind))")
            await db.execute("CREATE TABLE IF NOT EXISTS starboard (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, stars INTEGER DEFAULT 3)")
            await db.execute("CREATE TABLE IF NOT EXISTS starred (message_id INTEGER PRIMARY KEY)")
            await db.execute("CREATE TABLE IF NOT EXISTS suggest (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS sticky (channel_id INTEGER PRIMARY KEY, content TEXT, last_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS counting (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, current INTEGER DEFAULT 0, last_user INTEGER DEFAULT 0)")
            await db.commit()

    # ---------- autorole ----------
    @commands.hybrid_command(name="autorole", description="Set autorole: autorole <human|bot> <role>")
    @commands.has_permissions(manage_roles=True)
    @commands.guild_only()
    async def autorole(self, ctx, kind: str, role: discord.Role):
        kind = kind.lower()
        if kind not in ("human", "bot"):
            return await ctx.send(embed=err("Kind must be `human` or `bot`."))
        if role >= ctx.guild.me.top_role or role.managed:
            return await ctx.send(embed=err("I can't assign that role (above mine or managed)."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO autorole VALUES (?, ?, ?)", (ctx.guild.id, role.id, kind))
            await db.commit()
        await ctx.send(embed=ok(f"New **{kind}s** will get {role.mention}."))

    @commands.hybrid_command(name="autoroleremove", description="Remove autorole: autoroleremove <human|bot>")
    @commands.has_permissions(manage_roles=True)
    @commands.guild_only()
    async def autoroleremove(self, ctx, kind: str):
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM autorole WHERE guild_id=? AND kind=?", (ctx.guild.id, kind.lower()))
            await db.commit()
        await ctx.send(embed=ok("Autorole removed."))

    @commands.Cog.listener()
    async def on_member_join(self, m: discord.Member):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT role_id FROM autorole WHERE guild_id=? AND kind=?", (m.guild.id, "bot" if m.bot else "human")) as c:
                r = await c.fetchone()
        if r and (role := m.guild.get_role(r[0])):
            try:
                await m.add_roles(role, reason="ZYRO autorole")
            except Exception:
                pass

    # ---------- starboard ----------
    @commands.hybrid_command(name="starboard", description="Set starboard channel (and required stars)")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def starboard(self, ctx, channel: discord.TextChannel, stars: int = 3):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO starboard VALUES (?, ?, ?)", (ctx.guild.id, channel.id, max(1, stars)))
            await db.commit()
        await ctx.send(embed=ok(f"Starboard → {channel.mention} (needs ⭐ x{stars})"))

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, p: discord.RawReactionActionEvent):
        if not p.guild_id or str(p.emoji) != "⭐":
            return
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT channel_id, stars FROM starboard WHERE guild_id=?", (p.guild_id,)) as c:
                cfg = await c.fetchone()
            if not cfg:
                return
            async with db.execute("SELECT 1 FROM starred WHERE message_id=?", (p.message_id,)) as c:
                if await c.fetchone():
                    return
            g = self.bot.get_guild(p.guild_id)
            ch = g.get_channel(p.channel_id)
            target = g.get_channel(cfg[0])
            if not ch or not target or ch.id == target.id:
                return
            try:
                msg = await ch.fetch_message(p.message_id)
            except Exception:
                return
            r = discord.utils.get(msg.reactions, emoji="⭐")
            if not r or r.count < cfg[1]:
                return
            e = embed(None, msg.content[:2000] or "*attachment*", 0xF1C40F)
            e.set_author(name=str(msg.author), icon_url=msg.author.display_avatar.url)
            e.add_field(name="Source", value=f"[Jump to message]({msg.jump_url})")
            if msg.attachments:
                e.set_image(url=msg.attachments[0].url)
            await target.send(content=f"⭐ **{r.count}** | {ch.mention}", embed=e)
            await db.execute("INSERT INTO starred VALUES (?)", (p.message_id,))
            await db.commit()

    # ---------- suggestions ----------
    @commands.hybrid_command(name="setsuggest", description="Set the suggestions channel")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def setsuggest(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO suggest VALUES (?, ?)", (ctx.guild.id, channel.id))
            await db.commit()
        await ctx.send(embed=ok(f"Suggestions → {channel.mention}"))

    @commands.hybrid_command(name="suggest", description="Submit a suggestion")
    @commands.guild_only()
    async def suggest(self, ctx, *, idea: str):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT channel_id FROM suggest WHERE guild_id=?", (ctx.guild.id,)) as c:
                r = await c.fetchone()
        ch = ctx.guild.get_channel(r[0]) if r else None
        if not ch:
            return await ctx.send(embed=err("Suggestion channel not set. Admin: `setsuggest #channel`"))
        e = embed("💡 New Suggestion", idea[:3000])
        e.set_author(name=str(ctx.author), icon_url=ctx.author.display_avatar.url)
        m = await ch.send(embed=e)
        await m.add_reaction("👍")
        await m.add_reaction("👎")
        await ctx.send(embed=ok("Suggestion sent!"), ephemeral=True) if ctx.interaction else await ctx.message.add_reaction("✅")

    # ---------- sticky ----------
    @commands.hybrid_command(name="sticky", description="Set a sticky message in this channel")
    @commands.has_permissions(manage_messages=True)
    @commands.guild_only()
    async def sticky(self, ctx, *, text: str):
        m = await ctx.channel.send(f"📌 **Sticky**\n{text}")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO sticky VALUES (?, ?, ?)", (ctx.channel.id, text, m.id))
            await db.commit()
        if ctx.interaction:
            await ctx.send(embed=ok("Sticky set."), ephemeral=True)

    @commands.hybrid_command(name="unsticky", description="Remove the sticky message")
    @commands.has_permissions(manage_messages=True)
    @commands.guild_only()
    async def unsticky(self, ctx):
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM sticky WHERE channel_id=?", (ctx.channel.id,))
            await db.commit()
        await ctx.send(embed=ok("Sticky removed."))

    # ---------- counting ----------
    @commands.hybrid_command(name="setcounting", description="Set the counting game channel")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def setcounting(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO counting VALUES (?, ?, 0, 0)", (ctx.guild.id, channel.id))
            await db.commit()
        await channel.send(embed=embed("🔢 Counting", "Start counting from **1**. You can't count twice in a row!"))
        await ctx.send(embed=ok(f"Counting channel → {channel.mention}"))

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if not m.guild or m.author.bot:
            return
        async with aiosqlite.connect(DB) as db:
            # counting
            async with db.execute("SELECT channel_id, current, last_user FROM counting WHERE guild_id=?", (m.guild.id,)) as c:
                cnt = await c.fetchone()
            if cnt and cnt[0] == m.channel.id:
                if m.content.strip().isdigit() and int(m.content.strip()) == cnt[1] + 1 and m.author.id != cnt[2]:
                    await db.execute("UPDATE counting SET current=?, last_user=? WHERE guild_id=?", (cnt[1] + 1, m.author.id, m.guild.id))
                    await db.commit()
                    try:
                        await m.add_reaction("✅")
                    except Exception:
                        pass
                elif m.content.strip().isdigit():
                    await db.execute("UPDATE counting SET current=0, last_user=0 WHERE guild_id=?", (m.guild.id,))
                    await db.commit()
                    await m.add_reaction("❌")
                    await m.channel.send(f"{m.author.mention} ruined it at **{cnt[1]}**! Start again from **1**.")
            # sticky
            if m.channel.id in self.sticky_lock:
                return
            async with db.execute("SELECT content, last_id FROM sticky WHERE channel_id=?", (m.channel.id,)) as c:
                st = await c.fetchone()
            if st:
                self.sticky_lock.add(m.channel.id)
                try:
                    try:
                        old = await m.channel.fetch_message(st[1])
                        await old.delete()
                    except Exception:
                        pass
                    new = await m.channel.send(f"📌 **Sticky**\n{st[0]}")
                    await db.execute("UPDATE sticky SET last_id=? WHERE channel_id=?", (new.id, m.channel.id))
                    await db.commit()
                finally:
                    self.sticky_lock.discard(m.channel.id)


async def setup(bot):
    await bot.add_cog(ServerTools(bot))
