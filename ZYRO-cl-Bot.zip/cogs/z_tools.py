"""ZYRO Tools. Development by ARIAN"""
import re
import ast
import operator
import aiohttp
import discord
from discord.ext import commands
from zutil import embed, ok, err

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
       ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg, ast.FloorDiv: operator.floordiv}


def safe_eval(node):
    if isinstance(node, ast.Expression):
        return safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        l, r = safe_eval(node.left), safe_eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(r) > 100:
            raise ValueError("exponent too large")
        return OPS[type(node.op)](l, r)
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPS:
        return OPS[type(node.op)](safe_eval(node.operand))
    raise ValueError("unsupported")


class Tools(commands.Cog, name="Tools"):
    """Handy utilities."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="poll", description='Poll: poll "Question" option1 | option2 | ...')
    @commands.guild_only()
    async def poll(self, ctx, question: str, *, options: str = ""):
        opts = [o.strip() for o in options.split("|") if o.strip()][:10]
        nums = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        if len(opts) < 2:
            m = await ctx.send(embed=embed("📊 Poll", question))
            await m.add_reaction("👍")
            await m.add_reaction("👎")
            return
        m = await ctx.send(embed=embed(f"📊 {question}", "\n".join(f"{nums[i]} {o}" for i, o in enumerate(opts))))
        for i in range(len(opts)):
            await m.add_reaction(nums[i])

    @commands.hybrid_command(name="calc", aliases=["math"], description="Calculator")
    async def calc(self, ctx, *, expression: str):
        try:
            res = safe_eval(ast.parse(expression.replace("^", "**").replace("x", "*"), mode="eval"))
        except Exception:
            return await ctx.send(embed=err("Invalid expression."))
        await ctx.send(embed=embed("🧮 Calculator", f"`{expression}` = **{res:,}**"))

    @commands.hybrid_command(name="roleinfo", description="Info about a role")
    @commands.guild_only()
    async def roleinfo(self, ctx, role: discord.Role):
        e = embed(f"🏷️ {role.name}", color=role.color.value or 0x7B2FFF)
        e.add_field(name="ID", value=role.id)
        e.add_field(name="Members", value=len(role.members))
        e.add_field(name="Color", value=str(role.color))
        e.add_field(name="Position", value=role.position)
        e.add_field(name="Mentionable", value=role.mentionable)
        e.add_field(name="Created", value=f"<t:{int(role.created_at.timestamp())}:R>")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="channelinfo", description="Info about a channel")
    @commands.guild_only()
    async def channelinfo(self, ctx, channel: discord.abc.GuildChannel = None):
        ch = channel or ctx.channel
        e = embed(f"#{ch.name}")
        e.add_field(name="ID", value=ch.id)
        e.add_field(name="Type", value=str(ch.type).title())
        e.add_field(name="Category", value=ch.category.name if ch.category else "None")
        e.add_field(name="Created", value=f"<t:{int(ch.created_at.timestamp())}:R>")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="membercount", aliases=["mc"], description="Member count")
    @commands.guild_only()
    async def membercount(self, ctx):
        g = ctx.guild
        bots = sum(1 for m in g.members if m.bot)
        await ctx.send(embed=embed("👥 Members", f"**Total:** {g.member_count}\n**Humans:** {g.member_count - bots}\n**Bots:** {bots}"))

    @commands.hybrid_command(name="servericon", aliases=["sicon"], description="Server icon")
    @commands.guild_only()
    async def servericon(self, ctx):
        if not ctx.guild.icon:
            return await ctx.send(embed=err("This server has no icon."))
        e = embed(ctx.guild.name)
        e.set_image(url=ctx.guild.icon.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="userbanner", description="Show a user's banner")
    async def userbanner(self, ctx, member: discord.User = None):
        u = await self.bot.fetch_user((member or ctx.author).id)
        if not u.banner:
            return await ctx.send(embed=err("No banner."))
        e = embed(f"{u.name}'s banner")
        e.set_image(url=u.banner.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="emojilist", aliases=["emojis"], description="List server emojis")
    @commands.guild_only()
    async def emojilist(self, ctx):
        if not ctx.guild.emojis:
            return await ctx.send(embed=err("No custom emojis."))
        await ctx.send(embed=embed(f"😀 Emojis ({len(ctx.guild.emojis)})", " ".join(str(e) for e in ctx.guild.emojis)[:3900]))

    @commands.hybrid_command(name="timestamp", description="Discord timestamp for a unix time")
    async def timestamp(self, ctx, unix: int):
        await ctx.send(embed=embed("🕒 Timestamp", f"<t:{unix}:F>\n<t:{unix}:R>\n`<t:{unix}:F>`"))

    @commands.hybrid_command(name="weather", description="Weather of a city")
    async def weather(self, ctx, *, city: str):
        await ctx.defer()
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"https://wttr.in/{city}?format=j1", timeout=aiohttp.ClientTimeout(total=8)) as r:
                    d = await r.json(content_type=None)
            c = d["current_condition"][0]
            e = embed(f"🌤️ Weather — {city.title()}")
            e.add_field(name="Temp", value=f"{c['temp_C']}°C (feels {c['FeelsLikeC']}°C)")
            e.add_field(name="Condition", value=c["weatherDesc"][0]["value"])
            e.add_field(name="Humidity", value=f"{c['humidity']}%")
            e.add_field(name="Wind", value=f"{c['windspeedKmph']} km/h")
            await ctx.send(embed=e)
        except Exception:
            await ctx.send(embed=err("City not found or weather service busy."))

    @commands.hybrid_command(name="qr", description="Make a QR code")
    async def qr(self, ctx, *, text: str):
        e = embed("🔳 QR Code")
        e.set_image(url=f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={discord.utils.escape_markdown(text).replace(' ', '%20')}")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="botstats", aliases=["zyro"], description="About ZYRO")
    async def zyro(self, ctx):
        b = self.bot
        e = embed("✦ ZYRO ✦", "All-in-one bot: Antinuke • Music • VoiceMaster • Moderation • Economy • Leveling • Tickets • Logs")
        e.add_field(name="Servers", value=len(b.guilds))
        e.add_field(name="Users", value=sum(g.member_count or 0 for g in b.guilds))
        e.add_field(name="Commands", value=len(b.commands))
        e.add_field(name="Latency", value=f"{round(b.latency * 1000)}ms")
        e.add_field(name="Developer", value="ARIAN")
        e.set_thumbnail(url=b.user.display_avatar.url)
        await ctx.send(embed=e)


async def setup(bot):
    await bot.add_cog(Tools(bot))
