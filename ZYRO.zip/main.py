import asyncio, logging, discord, aiosqlite
from discord.ext import commands
from config import TOKEN, PREFIX, OWNER_IDS, STATUS, DB_PATH
from zyro.db import init_db
from zyro.utils import embed

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
if not TOKEN:
    raise RuntimeError("Missing DISCORD_TOKEN. Copy .env.example to .env and add your bot token.")

intents=discord.Intents.default()
intents.guilds=True
intents.members=True
intents.message_content=True
intents.voice_states=True
intents.moderation=True

async def get_prefix(bot,message):
    if message.guild:
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT prefix FROM guild_config WHERE guild_id=?",(message.guild.id,))
            row=await cur.fetchone()
            if row and row[0]: return commands.when_mentioned_or(row[0])(bot,message)
    return commands.when_mentioned_or(PREFIX)(bot,message)

class ZYRO(commands.Bot):
    async def setup_hook(self):
        await init_db()
        for ext in ("zyro.core","zyro.moderation","zyro.security","zyro.automod","zyro.voice","zyro.music","zyro.community"):
            try:
                await self.load_extension(ext)
                logging.info("Loaded %s",ext)
            except Exception:
                logging.exception("Failed to load %s",ext)
        try:
            synced=await self.tree.sync()
            logging.info("Synced %s application commands",len(synced))
        except Exception:
            logging.exception("Slash command sync failed")
    async def on_command_error(self,ctx,error):
        if isinstance(error,commands.CommandNotFound): return
        if isinstance(error,commands.MissingPermissions):
            return await ctx.reply("You don't have the required server permissions.")
        if isinstance(error,commands.BotMissingPermissions):
            return await ctx.reply("ZYRO is missing permissions needed for this action.")
        if isinstance(error,commands.MissingRequiredArgument):
            return await ctx.reply(f"Missing argument: `{error.param.name}`. Use `.help`.")
        if isinstance(error,commands.BadArgument):
            return await ctx.reply("Invalid argument. Check the command format with `.help`.")
        if isinstance(error,commands.CommandOnCooldown):
            return await ctx.reply(f"Slow down — try again in {error.retry_after:.1f}s.")
        logging.exception("Command error",exc_info=error)
        try: await ctx.reply("Something went wrong. Check the Codespaces terminal logs.")
        except discord.HTTPException: pass

bot=ZYRO(command_prefix=get_prefix, intents=intents, help_command=None, case_insensitive=True, owner_ids=OWNER_IDS)
bot.remove_command("help")

@bot.tree.command(name="ping",description="Check ZYRO response latency")
async def slash_ping(interaction:discord.Interaction):
    await interaction.response.send_message(embed=embed("Pong",f"{bot.latency*1000:.0f} ms"),ephemeral=True)

@bot.tree.command(name="zyro",description="Show ZYRO bot information")
async def slash_zyro(interaction:discord.Interaction):
    await interaction.response.send_message(embed=embed("ZYRO","Premium all-in-one Discord assistant\n**Development by ARIAN**"),ephemeral=True)

async def main():
    async with bot:
        await bot.start(TOKEN)
if __name__=="__main__":
    asyncio.run(main())
