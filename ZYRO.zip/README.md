# ZYRO — All-in-One Discord Bot
**Development by ARIAN**

Premium dark / midnight-blue / neon-cyan identity. Built with Python, discord.py 2.6, SQLite and optional voice playback.

## Included modules
- **Security:** audit-log based anti-nuke response for channel/role deletion, bans, kicks and unauthorized bot additions; trusted-user whitelist; security and moderation log channels.
- **Moderation:** ban, kick, timeout, untimeout, unban, warn, warning history, clear warnings, purge, slowmode, lock/unlock, nickname.
- **Automod:** configurable spam, invite-link and mass-mention guards.
- **VoiceMaster:** join-to-create temporary rooms, auto-cleanup, lock/unlock, hide/show, user limit, rename and claim.
- **Music:** play/search, queue, pause, resume, skip, stop, volume and now-playing using yt-dlp + FFmpeg + Discord voice.
- **Community:** welcome messages, autorole, sticky messages, polls, announcements, AFK, role/user/server info and utility commands.
- **Slash commands:** `/ping`, `/zyro`; prefix commands use `.` by default.
- **Storage:** SQLite; no external database account required.

This is a tested foundation, not a claim that 500+ independent features have been implemented. Discord permissions, platform API limits and third-party audio extraction can affect runtime behavior. Anti-nuke is best-effort: Discord audit-log delay, missing permissions, role hierarchy and API rate limits can prevent a response. Test in a private server before enabling it in a production community.

## 1. Create your Discord application
1. Open https://discord.com/developers/applications and create an application named **ZYRO**.
2. In **Bot**, create/reset the token. Never share it or upload it to GitHub.
3. Enable **SERVER MEMBERS INTENT** and **MESSAGE CONTENT INTENT**. (Presence intent is not required.)
4. In **OAuth2 → URL Generator**, select `bot` and `applications.commands`. Grant only the permissions you need; for the full feature set: Manage Channels, Manage Roles, View Audit Log, Manage Messages, Moderate Members, Kick Members, Ban Members, Connect, Speak, Send Messages, Embed Links, Read Message History, View Channels.
5. Invite it to a private test server first.

## 2. GitHub + Codespaces (phone friendly)
1. Create a **public or private** GitHub repository named `ZYRO`.
2. Upload this ZIP to the repo's root (or upload/extract the files).
3. Open the repository → **Code → Codespaces → Create codespace**.
4. In the Codespaces terminal run:

```bash
unzip -o ZYRO.zip -d .
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

If you uploaded/extracted files directly and there is no `ZYRO.zip`, skip the unzip command.

5. Edit `.env` in the Codespaces file explorer. Put your token after `DISCORD_TOKEN=`. Put your numeric Discord user ID after `OWNER_IDS=`. Save it. **Never commit `.env`.**
6. Install FFmpeg for music playback:

```bash
sudo apt-get update && sudo apt-get install -y ffmpeg
```

7. Start:

```bash
python main.py
```

You should see `ZYRO online as ...` in the terminal. Keep the Codespace running while testing.

## 3. First server setup
- `.help` — command index
- `.setlog #security-logs` is not required; use `.setlog` inside the channel you want for security logs.
- `.modlog` inside your moderation log channel.
- `.antinuke enable` then `.whitelist @trusted-admin` (owner is inherently trusted).
- `.automod antispam on`
- `.automod antiinvite on`
- `.automod mentionguard on`
- `.vcsetup` — create the join-to-create voice channel.
- `.welcome #welcome Welcome {mention} to {server}!`
- `.autorole @Member`

## Music notes
Music playback requires FFmpeg and a working voice connection. YouTube and other providers may change extraction behavior; yt-dlp updates may be needed. Do not use copyrighted audio in ways that violate provider terms or local law. There is no guaranteed free, permanent, always-on host.

## Free hosting reality
GitHub Pages cannot run Python bots. GitHub Actions/Codespaces are development tools, not a dependable 24/7 free host. Free tiers on cloud hosts change and may sleep, require a card, or have usage limits. First prove the bot works in Codespaces; then choose a host based on its current free-tier rules. Do not give a hosting provider your Discord token in public logs.

## Old project files
The supplied Meekly project is preserved under `legacy/` for reference, excluding its `.env`. It is **not auto-loaded** because it contains custom-emoji dependencies, Components V2 code and legacy extension assumptions that need individual migration/testing. ZYRO's runtime uses the new modules in `zyro/`.

## Troubleshooting
- `PrivilegedIntentsRequired`: enable Server Members + Message Content intents in Developer Portal.
- `ffmpeg was not found`: run the apt install command above, then restart.
- `Improper token has been passed`: reset the bot token and update `.env`.
- `Missing Permissions`: move ZYRO's role above roles it must manage and grant the specific permissions.
- `No module named ...`: rerun `pip install -r requirements.txt`.

## Credits
**Development by ARIAN**  
Project name: **ZYRO**
