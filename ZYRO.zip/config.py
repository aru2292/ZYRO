import os
from dotenv import load_dotenv
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN") or os.getenv("TOKEN")
PREFIX = os.getenv("BOT_PREFIX", ".")
OWNER_IDS = {int(x.strip()) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip().isdigit()}
STATUS = os.getenv("STATUS", "ZYRO | .help")
DB_PATH = "db/zyro.sqlite3"
