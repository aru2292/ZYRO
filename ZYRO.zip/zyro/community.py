import discord, aiosqlite
from discord.ext import commands
from zyro.db import DB_PATH, get_config
from zyro.utils import embed, send_log

class Community(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def welcome(self,ctx,channel:discord.TextChannel,*,message="Welcome {mention} to {server}!"):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,welcome_channel,welcome_message) VALUES(?,?,?) ON CONFLICT(guild_id) DO UPDATE SET welcome_channel=excluded.welcome_channel,welcome_message=excluded.welcome_message",(ctx.guild.id,channel.id,message)); await db.commit()
        await ctx.reply(f"Welcome messages configured in {channel.mention}.")
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def autorole(self,ctx,role:discord.Role):
        if role>=ctx.guild.me.top_role: return await ctx.reply("Move ZYRO's role above the autorole.")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,autorole_id) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET autorole_id=excluded.autorole_id",(ctx.guild.id,role.id)); await db.commit()
        await ctx.reply(f"Autorole set to {role.mention}.")
    @commands.Cog.listener()
    async def on_member_join(self,member):
        cfg=await get_config(member.guild.id)
        if cfg.get("autorole_id"):
            role=member.guild.get_role(cfg["autorole_id"])
            if role:
                try: await member.add_roles(role,reason="ZYRO autorole")
                except discord.HTTPException: pass
        ch=member.guild.get_channel(cfg.get("welcome_channel")) if cfg.get("welcome_channel") else None
        if ch:
            msg=cfg.get("welcome_message") or "Welcome {mention}!"
            await ch.send(msg.replace("{mention}",member.mention).replace("{server}",member.guild.name).replace("{user}",member.display_name))
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def sticky(self,ctx,*,message):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO sticky VALUES(?,?,?) ON CONFLICT(guild_id,channel_id) DO UPDATE SET message=excluded.message",(ctx.guild.id,ctx.channel.id,message)); await db.commit()
        await ctx.reply("Sticky message saved. It will be posted on new messages.")
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def unsticky(self,ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM sticky WHERE guild_id=? AND channel_id=?",(ctx.guild.id,ctx.channel.id)); await db.commit()
        await ctx.reply("Sticky message disabled.")
    @commands.Cog.listener()
    async def on_message(self,msg):
        if msg.author.bot or not msg.guild: return
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT message FROM sticky WHERE guild_id=? AND channel_id=?",(msg.guild.id,msg.channel.id)); row=await cur.fetchone()
            prev=await db.execute("SELECT message_id FROM sticky_posts WHERE channel_id=?",(msg.channel.id,)); prevrow=await prev.fetchone()
        if row:
            try:
                if prevrow:
                    try:
                        old=await msg.channel.fetch_message(prevrow[0]); await old.delete()
                    except discord.HTTPException: pass
                posted=await msg.channel.send(embed=embed("Pinned Message",row[0]))
                async with aiosqlite.connect(DB_PATH) as db:
                    await db.execute("INSERT OR REPLACE INTO sticky_posts VALUES(?,?)",(msg.channel.id,posted.id)); await db.commit()
            except discord.HTTPException: pass
async def setup(bot): await bot.add_cog(Community(bot))
