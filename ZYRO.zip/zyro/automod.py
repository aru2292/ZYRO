import discord, re, time, aiosqlite
from collections import defaultdict, deque
from discord.ext import commands
from zyro.db import DB_PATH, get_config
from zyro.utils import send_log

class AutoMod(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.recent=defaultdict(lambda:deque(maxlen=8)); self.links=defaultdict(deque)
    @commands.Cog.listener()
    async def on_message(self,msg):
        if msg.author.bot or not msg.guild: return
        cfg=await get_config(msg.guild.id)
        reason=None; now=time.monotonic(); key=(msg.guild.id,msg.author.id)
        q=self.recent[key]; q.append((now,msg.content))
        if cfg.get("antispam",1) and len(q)>=5 and now-q[0][0]<7: reason="Spam / rapid messages"
        if cfg.get("antiinvite") and re.search(r"(discord\.gg/|discord\.com/invite/)",msg.content,re.I): reason="Invite link filter"
        if cfg.get("antimention",1) and len(msg.mentions)>=8: reason="Mass mention protection"
        if reason:
            try:
                await msg.delete()
                await msg.channel.send(f"{msg.author.mention}, message blocked: **{reason}**.",delete_after=6)
                await send_log(msg.guild,f"Automod blocked {msg.author.mention}: {reason}")
            except discord.HTTPException: pass
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def automod(self,ctx,feature:str,state:str):
        keys={"antispam":"antispam","antiinvite":"antiinvite","mentionguard":"antimention"}
        if feature.lower() not in keys or state.lower() not in ("on","off"): return await ctx.reply("Usage: `.automod antispam|antiinvite|mentionguard on|off`")
        col=keys[feature.lower()]; val=int(state.lower()=="on")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(f"INSERT INTO guild_config(guild_id,{col}) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET {col}=excluded.{col}",(ctx.guild.id,val)); await db.commit()
        await ctx.reply(f"{feature} is now **{state.upper()}**.")
async def setup(bot): await bot.add_cog(AutoMod(bot))
