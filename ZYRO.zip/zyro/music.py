import asyncio, discord, yt_dlp
from collections import defaultdict, deque
from discord.ext import commands
from zyro.utils import embed

YDL_OPTS={"format":"bestaudio/best","noplaylist":True,"quiet":True,"no_warnings":True,"default_search":"ytsearch"}
FFMPEG_OPTS={"before_options":"-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5","options":"-vn"}
class Music(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.queues=defaultdict(deque); self.current={}
    async def extract(self,query):
        loop=asyncio.get_running_loop()
        def work():
            with yt_dlp.YoutubeDL(YDL_OPTS) as ydl:
                info=ydl.extract_info(query,download=False)
                if "entries" in info: info=next((x for x in info["entries"] if x),None)
                if not info: raise ValueError("No matching audio found.")
                return {"title":info.get("title","Unknown"),"url":info["url"],"webpage":info.get("webpage_url",query),"duration":info.get("duration",0)}
        return await loop.run_in_executor(None,work)
    async def next_track(self,guild):
        q=self.queues[guild.id]
        if not q: self.current.pop(guild.id,None); return
        track=q.popleft(); self.current[guild.id]=track
        vc=guild.voice_client
        if not vc or not vc.is_connected(): return
        source=discord.PCMVolumeTransformer(discord.FFmpegPCMAudio(track["url"],**FFMPEG_OPTS),volume=0.5)
        def after(error):
            if error: print("ZYRO music playback error:",error)
            asyncio.run_coroutine_threadsafe(self.next_track(guild),self.bot.loop)
        vc.play(source,after=after)
        ch=self.bot.get_channel(track.get("channel_id",0))
        if ch:
            asyncio.run_coroutine_threadsafe(ch.send(embed=embed("Now Playing",f"**{track['title']}**")),self.bot.loop)
    @commands.command()
    async def play(self,ctx,*,query):
        if not ctx.author.voice or not ctx.author.voice.channel: return await ctx.reply("Join a voice channel first.")
        vc=ctx.guild.voice_client
        if vc and vc.channel!=ctx.author.voice.channel: return await ctx.reply("Join the same voice channel as ZYRO.")
        if not vc: vc=await ctx.author.voice.channel.connect()
        try: track=await self.extract(query)
        except Exception as e: return await ctx.reply(f"Could not load audio: `{str(e)[:250]}`")
        track["channel_id"]=ctx.channel.id
        self.queues[ctx.guild.id].append(track)
        if not vc.is_playing() and not vc.is_paused(): await self.next_track(ctx.guild)
        else: await ctx.reply(embed=embed("Added to Queue",track["title"]))
    @commands.command()
    async def queue(self,ctx):
        q=list(self.queues[ctx.guild.id]); current=self.current.get(ctx.guild.id)
        desc=(f"**Playing:** {current['title']}\n" if current else "")+"\n".join(f"`{i+1}.` {t['title']}" for i,t in enumerate(q[:10]))
        await ctx.reply(embed=embed("Music Queue",desc or "Queue is empty."))
    @commands.command()
    async def pause(self,ctx):
        vc=ctx.guild.voice_client
        if vc and vc.is_playing(): vc.pause(); return await ctx.reply("Playback paused.")
        await ctx.reply("Nothing is playing.")
    @commands.command()
    async def resume(self,ctx):
        vc=ctx.guild.voice_client
        if vc and vc.is_paused(): vc.resume(); return await ctx.reply("Playback resumed.")
        await ctx.reply("Playback is not paused.")
    @commands.command()
    async def skip(self,ctx):
        vc=ctx.guild.voice_client
        if vc and (vc.is_playing() or vc.is_paused()): vc.stop(); return await ctx.reply("Skipped.")
        await ctx.reply("Nothing is playing.")
    @commands.command()
    async def stop(self,ctx):
        vc=ctx.guild.voice_client
        self.queues[ctx.guild.id].clear(); self.current.pop(ctx.guild.id,None)
        if vc: await vc.disconnect()
        await ctx.reply("Playback stopped and queue cleared.")
    @commands.command()
    async def volume(self,ctx,percent:int):
        vc=ctx.guild.voice_client
        if not vc or not vc.source: return await ctx.reply("Nothing is playing.")
        if not 1<=percent<=100: return await ctx.reply("Volume must be 1–100.")
        vc.source.volume=percent/100; await ctx.reply(f"Volume set to {percent}%.")
    @commands.command()
    async def nowplaying(self,ctx):
        track=self.current.get(ctx.guild.id)
        await ctx.reply(embed=embed("Now Playing",track["title"] if track else "Nothing is playing."))
async def setup(bot): await bot.add_cog(Music(bot))
