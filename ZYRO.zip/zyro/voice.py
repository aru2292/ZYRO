import discord, aiosqlite
from discord.ext import commands
from zyro.db import DB_PATH, get_config
from zyro.utils import embed

class Voice(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def vcsetup(self,ctx,category:discord.CategoryChannel=None):
        category=category or await ctx.guild.create_category("ZYRO VOICE")
        join=await ctx.guild.create_voice_channel("➕ Create a channel",category=category)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,join_to_create,voice_category) VALUES(?,?,?) ON CONFLICT(guild_id) DO UPDATE SET join_to_create=excluded.join_to_create,voice_category=excluded.voice_category",(ctx.guild.id,join.id,category.id)); await db.commit()
        await ctx.reply(embed=embed("VoiceMaster configured",f"Join {join.mention} to create your own temporary voice channel."))
    @commands.Cog.listener()
    async def on_voice_state_update(self,member,before,after):
        if member.bot: return
        cfg=await get_config(member.guild.id)
        if after.channel and after.channel.id==cfg.get("join_to_create"):
            cat=member.guild.get_channel(cfg.get("voice_category")) if cfg.get("voice_category") else None
            ch=await member.guild.create_voice_channel(f"{member.display_name}'s room",category=cat)
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("INSERT OR REPLACE INTO temp_channels VALUES(?,?,?)",(ch.id,member.id,member.guild.id)); await db.commit()
            await member.move_to(ch)
        if before.channel:
            async with aiosqlite.connect(DB_PATH) as db:
                cur=await db.execute("SELECT 1 FROM temp_channels WHERE channel_id=?",(before.channel.id,)); exists=await cur.fetchone()
                if exists and len(before.channel.members)==0:
                    await before.channel.delete(reason="ZYRO empty temporary voice cleanup")
                    await db.execute("DELETE FROM temp_channels WHERE channel_id=?",(before.channel.id,)); await db.commit()
    async def owned(self,ctx):
        if not ctx.author.voice or not ctx.author.voice.channel: return None
        ch=ctx.author.voice.channel
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT owner_id FROM temp_channels WHERE channel_id=?",(ch.id,)); row=await cur.fetchone()
        if not row or row[0]!=ctx.author.id: return None
        return ch
    @commands.command()
    async def vclock(self,ctx):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        await ch.set_permissions(ctx.guild.default_role,connect=False); await ctx.reply("Your room is locked.")
    @commands.command()
    async def vcunlock(self,ctx):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        await ch.set_permissions(ctx.guild.default_role,connect=True); await ctx.reply("Your room is unlocked.")
    @commands.command()
    async def vchide(self,ctx):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        await ch.set_permissions(ctx.guild.default_role,view_channel=False); await ctx.reply("Your room is hidden.")
    @commands.command()
    async def vcshow(self,ctx):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        await ch.set_permissions(ctx.guild.default_role,view_channel=True); await ctx.reply("Your room is visible.")
    @commands.command()
    async def vclimit(self,ctx,limit:int):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        if not 0<=limit<=99: return await ctx.reply("Limit must be 0–99.")
        await ch.edit(user_limit=limit); await ctx.reply(f"User limit: {limit or 'unlimited'}.")
    @commands.command()
    async def vcrename(self,ctx,*,name):
        ch=await self.owned(ctx)
        if not ch: return await ctx.reply("Join your own temporary voice channel first.")
        await ch.edit(name=name[:90]); await ctx.reply("Room renamed.")
    @commands.command()
    async def vcclaim(self,ctx):
        if not ctx.author.voice: return await ctx.reply("Join a temporary room first.")
        ch=ctx.author.voice.channel
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT owner_id FROM temp_channels WHERE channel_id=?",(ch.id,)); row=await cur.fetchone()
            if not row: return await ctx.reply("This is not a ZYRO room.")
            old=ch.guild.get_member(row[0])
            if old and old in ch.members: return await ctx.reply("The current owner is still in the room.")
            await db.execute("UPDATE temp_channels SET owner_id=? WHERE channel_id=?",(ctx.author.id,ch.id)); await db.commit()
        await ctx.reply("You are now the room owner.")
async def setup(bot): await bot.add_cog(Voice(bot))
