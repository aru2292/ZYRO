import aiosqlite, os
from config import DB_PATH

async def init_db():
    os.makedirs("db", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
        CREATE TABLE IF NOT EXISTS guild_config(
          guild_id INTEGER PRIMARY KEY, prefix TEXT, log_channel INTEGER,
          modlog_channel INTEGER, welcome_channel INTEGER, welcome_message TEXT,
          autorole_id INTEGER, antinuke INTEGER DEFAULT 0, antispam INTEGER DEFAULT 1,
          antiinvite INTEGER DEFAULT 0, antimention INTEGER DEFAULT 1,
          quarantine_role INTEGER, jail_role INTEGER, join_to_create INTEGER,
          voice_category INTEGER
        );
        CREATE TABLE IF NOT EXISTS warnings(
          id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER,
          moderator_id INTEGER, reason TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS whitelist(
          guild_id INTEGER, user_id INTEGER, PRIMARY KEY(guild_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS cases(
          id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, action TEXT,
          target_id INTEGER, moderator_id INTEGER, reason TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS afk(
          user_id INTEGER PRIMARY KEY, reason TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS birthdays(
          guild_id INTEGER, user_id INTEGER, day INTEGER, month INTEGER,
          PRIMARY KEY(guild_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS reminders(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, channel_id INTEGER,
          message TEXT, due_at INTEGER, sent INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS autoroles(guild_id INTEGER PRIMARY KEY, role_id INTEGER);
        CREATE TABLE IF NOT EXISTS temp_channels(channel_id INTEGER PRIMARY KEY, owner_id INTEGER, guild_id INTEGER);
        CREATE TABLE IF NOT EXISTS starboard(guild_id INTEGER PRIMARY KEY, channel_id INTEGER, threshold INTEGER DEFAULT 3);
        CREATE TABLE IF NOT EXISTS sticky(guild_id INTEGER, channel_id INTEGER, message TEXT, PRIMARY KEY(guild_id,channel_id));
        CREATE TABLE IF NOT EXISTS sticky_posts(channel_id INTEGER PRIMARY KEY, message_id INTEGER);
        CREATE TABLE IF NOT EXISTS disabled_commands(guild_id INTEGER, command TEXT, PRIMARY KEY(guild_id,command));
        """)
        await db.commit()

async def get_config(guild_id):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory=aiosqlite.Row
        cur=await db.execute("SELECT * FROM guild_config WHERE guild_id=?",(guild_id,))
        row=await cur.fetchone()
        return dict(row) if row else {}
