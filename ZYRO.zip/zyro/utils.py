import discord
from config import PREFIX
CYAN=0x35D9FF
DARK=0x0B1220
def embed(title, description=None, color=CYAN):
    return discord.Embed(title=f"✦ {title}", description=description, color=color)
async def send_log(guild, message, *, mod=False):
    from zyro.db import get_config
    cfg=await get_config(guild.id)
    channel_id=cfg.get("modlog_channel") if mod else cfg.get("log_channel")
    channel=guild.get_channel(channel_id) if channel_id else None
    if channel:
        try: await channel.send(embed=embed("Audit Log",message))
        except discord.HTTPException: pass
def human_duration(seconds):
    seconds=int(seconds); parts=[]
    for unit,size in (("d",86400),("h",3600),("m",60),("s",1)):
        n,seconds=divmod(seconds,size)
        if n: parts.append(f"{n}{unit}")
    return " ".join(parts) or "0s"
