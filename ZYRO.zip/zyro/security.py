import discord, aiosqlite
from discord.ext import commands
from zyro.db import DB_PATH, get_config
from zyro.utils import embed, send_log

class Security(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @commands.group(invoke_without_command=True)
    @commands.has_guild_permissions(administrator=True)
    async def antinuke(self,ctx):
        cfg=await get_config(ctx.guild.id)
        status = "ON" if cfg.get("antinuke") else "OFF"
        await ctx.reply(embed=embed("Anti-Nuke",f"Status: `{status}`\\nUse `.antinuke enable` / `.antinuke disable`\\nAdd trusted admins with `.whitelist @member`."))
    @antinuke.command(name="enable")
    @commands.has_guild_permissions(administrator=True)
    async def anti_enable(self,ctx):
        await self.set_flag(ctx,"antinuke",1); await ctx.reply("Anti-nuke monitoring enabled.")
    @antinuke.command(name="disable")
    @commands.has_guild_permissions(administrator=True)
    async def anti_disable(self,ctx):
        await self.set_flag(ctx,"antinuke",0); await ctx.reply("Anti-nuke monitoring disabled.")
    async def set_flag(self,ctx,key,value):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(f"INSERT INTO guild_config(guild_id,{key}) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET {key}=excluded.{key}",(ctx.guild.id,value)); await db.commit()
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def whitelist(self,ctx,member:discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR IGNORE INTO whitelist VALUES(?,?)",(ctx.guild.id,member.id)); await db.commit()
        await ctx.reply(f"{member.mention} added to ZYRO trusted list.")
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def unwhitelist(self,ctx,member:discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM whitelist WHERE guild_id=? AND user_id=?",(ctx.guild.id,member.id)); await db.commit()
        await ctx.reply("Member removed from trusted list.")
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def setlog(self,ctx,channel:discord.TextChannel=None):
        channel=channel or ctx.channel
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,log_channel) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET log_channel=excluded.log_channel",(ctx.guild.id,channel.id)); await db.commit()
        await ctx.reply(f"Security logs will be sent to {channel.mention}.")
    @commands.command()
    @commands.has_guild_permissions(administrator=True)
    async def modlog(self,ctx,channel:discord.TextChannel=None):
        channel=channel or ctx.channel
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,modlog_channel) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET modlog_channel=excluded.modlog_channel",(ctx.guild.id,channel.id)); await db.commit()
        await ctx.reply(f"Moderation logs set to {channel.mention}.")
    async def actor(self,guild,action,target_id=None):
        try:
            async for entry in guild.audit_logs(limit=8,action=action):
                recent=(discord.utils.utcnow()-entry.created_at).total_seconds()<12
                entry_target=getattr(entry.target,"id",None)
                if recent and (target_id is None or entry_target==target_id): return entry.user
        except (discord.Forbidden,discord.HTTPException): return None
    async def punish_if_untrusted(self,guild,action,label,target_id=None):
        cfg=await get_config(guild.id)
        if not cfg.get("antinuke"): return
        actor=await self.actor(guild,action,target_id)
        if not actor or actor.id==guild.owner_id or actor.id==self.bot.user.id: return
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT 1 FROM whitelist WHERE guild_id=? AND user_id=?",(guild.id,actor.id)); trusted=await cur.fetchone()
        if trusted: return
        member=guild.get_member(actor.id)
        if member:
            try:
                roles=[r for r in member.roles if r<guild.me.top_role and r!=guild.default_role]
                if roles: await member.remove_roles(*roles,reason="ZYRO anti-nuke: untrusted destructive action")
            except discord.HTTPException: pass
        await send_log(guild,f"⚠️ Anti-nuke detected **{label}** by {actor.mention}. Attempted to strip manageable roles. Check audit logs and bot role hierarchy.")
    @commands.Cog.listener()
    async def on_guild_channel_delete(self,ch):
        await self.punish_if_untrusted(ch.guild,discord.AuditLogAction.channel_delete,"channel deletion",ch.id)
    @commands.Cog.listener()
    async def on_guild_role_delete(self,role):
        await self.punish_if_untrusted(role.guild,discord.AuditLogAction.role_delete,"role deletion",role.id)
    @commands.Cog.listener()
    async def on_member_ban(self,guild,user):
        await self.punish_if_untrusted(guild,discord.AuditLogAction.ban,"member ban",user.id)
    @commands.Cog.listener()
    async def on_member_remove(self,member):
        await self.punish_if_untrusted(member.guild,discord.AuditLogAction.kick,"member kick",member.id)
    @commands.Cog.listener()
    async def on_member_join(self,member):
        if member.bot:
            await self.punish_if_untrusted(member.guild,discord.AuditLogAction.bot_add,"bot addition",member.id)
async def setup(bot): await bot.add_cog(Security(bot))
