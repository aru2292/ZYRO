import discord, aiosqlite
from discord.ext import commands
from zyro.db import DB_PATH
from zyro.utils import embed, send_log

class Moderation(commands.Cog):
    def __init__(self,bot): self.bot=bot
    async def case(self,ctx,action,target,reason):
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("INSERT INTO cases(guild_id,action,target_id,moderator_id,reason) VALUES(?,?,?,?,?)",(ctx.guild.id,action,target.id,ctx.author.id,reason))
            cid=cur.lastrowid; await db.commit()
        await send_log(ctx.guild,f"Case **#{cid}** • {action}\\nTarget: {target.mention} (`{target.id}`)\\nModerator: {ctx.author.mention}\\nReason: {reason}",mod=True)
    @commands.command()
    @commands.has_guild_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    async def ban(self,ctx,member:discord.Member,*,reason="No reason provided"):
        if member==ctx.author or member==ctx.guild.owner: return await ctx.reply("That member cannot be banned.")
        await member.ban(reason=f"{ctx.author}: {reason}",delete_message_seconds=0)
        await self.case(ctx,"Ban",member,reason); await ctx.reply(embed=embed("Member Banned",f"{member} • {reason}"))
    @commands.command()
    @commands.has_guild_permissions(kick_members=True)
    @commands.bot_has_guild_permissions(kick_members=True)
    async def kick(self,ctx,member:discord.Member,*,reason="No reason provided"):
        if member==ctx.author or member==ctx.guild.owner: return await ctx.reply("That member cannot be kicked.")
        await member.kick(reason=f"{ctx.author}: {reason}")
        await self.case(ctx,"Kick",member,reason); await ctx.reply(embed=embed("Member Kicked",f"{member} • {reason}"))
    @commands.command()
    @commands.has_guild_permissions(moderate_members=True)
    @commands.bot_has_guild_permissions(moderate_members=True)
    async def timeout(self,ctx,member:discord.Member,minutes:int,*,reason="No reason provided"):
        if not 1<=minutes<=40320: return await ctx.reply("Duration must be 1–40320 minutes.")
        await member.timeout(discord.utils.utcnow()+__import__('datetime').timedelta(minutes=minutes),reason=reason)
        await self.case(ctx,"Timeout",member,reason); await ctx.reply(f"{member.mention} timed out for {minutes} minutes.")
    @commands.command()
    @commands.has_guild_permissions(moderate_members=True)
    async def untimeout(self,ctx,member:discord.Member,*,reason="Timeout removed"):
        await member.timeout(None,reason=reason)
        await ctx.reply(f"Timeout removed for {member.mention}.")
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def purge(self,ctx,amount:int):
        if not 1<=amount<=100: return await ctx.reply("Choose 1–100 messages.")
        deleted=await ctx.channel.purge(limit=amount+1)
        msg=await ctx.send(f"Deleted {len(deleted)-1} messages."); await msg.delete(delay=5)
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def slowmode(self,ctx,seconds:int):
        if not 0<=seconds<=21600: return await ctx.reply("Slowmode must be 0–21600 seconds.")
        await ctx.channel.edit(slowmode_delay=seconds); await ctx.reply(f"Slowmode set to {seconds}s.")
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def lock(self,ctx):
        ow=ctx.channel.overwrites_for(ctx.guild.default_role); ow.send_messages=False
        await ctx.channel.set_permissions(ctx.guild.default_role,overwrite=ow); await ctx.reply("Channel locked.")
    @commands.command()
    @commands.has_guild_permissions(manage_channels=True)
    async def unlock(self,ctx):
        ow=ctx.channel.overwrites_for(ctx.guild.default_role); ow.send_messages=None
        await ctx.channel.set_permissions(ctx.guild.default_role,overwrite=ow); await ctx.reply("Channel unlocked.")
    @commands.command()
    @commands.has_guild_permissions(manage_nicknames=True)
    async def nick(self,ctx,member:discord.Member,*,nickname=None):
        await member.edit(nick=nickname,reason=f"By {ctx.author}"); await ctx.reply("Nickname updated.")
    @commands.command()
    @commands.has_guild_permissions(ban_members=True)
    async def unban(self,ctx,user_id:int,*,reason="Unbanned by moderator"):
        user=await self.bot.fetch_user(user_id); await ctx.guild.unban(user,reason=reason); await ctx.reply(f"Unbanned {user}.")
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def warn(self,ctx,member:discord.Member,*,reason="No reason provided"):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)",(ctx.guild.id,member.id,ctx.author.id,reason)); await db.commit()
        await ctx.reply(embed=embed("Warning Issued",f"{member.mention}\\nReason: {reason}"))
        await send_log(ctx.guild,f"Warning: {member.mention} • {reason}",mod=True)
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def warnings(self,ctx,member:discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT id,reason,created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 15",(ctx.guild.id,member.id)); rows=await cur.fetchall()
        await ctx.reply(embed=embed(f"Warnings for {member}", "\n".join(f"#{r[0]} • {r[1]} ({r[2]})" for r in rows) or "No warnings."))
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def clearwarns(self,ctx,member:discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM warnings WHERE guild_id=? AND user_id=?",(ctx.guild.id,member.id)); await db.commit()
        await ctx.reply(f"Cleared warnings for {member.mention}.")
async def setup(bot): await bot.add_cog(Moderation(bot))
