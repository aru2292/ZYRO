import discord, asyncio, time, platform
from discord.ext import commands, tasks
from config import PREFIX, OWNER_IDS, STATUS
from zyro.db import get_config, DB_PATH
from zyro.utils import embed, send_log, CYAN
import aiosqlite

class Core(commands.Cog):
    def __init__(self, bot): self.bot=bot; self.started=time.time()
    @commands.Cog.listener()
    async def on_ready(self):
        print(f"ZYRO online as {self.bot.user} | {len(self.bot.guilds)} guilds | {len(self.bot.commands)} prefix commands")
        if not self.presence.is_running(): self.presence.start()
    @tasks.loop(minutes=5)
    async def presence(self):
        await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching,name=STATUS))
    @presence.before_loop
    async def before_presence(self): await self.bot.wait_until_ready()
    @commands.command(name="help")
    async def help_cmd(self,ctx,category=None):
        groups={
          "security":"antinuke, whitelist, unwhitelist, security, setlog, modlog",
          "moderation":"ban, kick, timeout, untimeout, warn, warnings, clearwarns, purge, slowmode, lock, unlock, nick, unban",
          "automod":"automod antispam on/off, automod antiinvite on/off, automod mentionguard on/off",
          "voice":"vcsetup, vclock, vcunlock, vchide, vcshow, vclimit, vcrename, vcclaim",
          "utility":"ping, botinfo, serverinfo, userinfo, avatar, invite, poll, say, afk, unafk, prefix, setprefix, uptime",
          "community":"welcome, autorole, sticky, unsticky, announce, roleinfo, emojiinfo",
          "music":"play, pause, resume, skip, stop, queue, volume, nowplaying (requires voice dependencies)"
        }
        if category:
            key=category.lower()
            if key not in groups: return await ctx.reply("Unknown category. Try `.help`.")
            return await ctx.reply(embed=embed(f"ZYRO / {key.title()}",f"```{groups[key]}```"))
        e=embed("ZYRO Command Center","**Prefix:** `.` (server admins can change it)\\n**Slash commands:** use `/` in Discord.")
        for k,v in groups.items(): e.add_field(name=f"✧ {k.title()}",value=f"`{v}`",inline=False)
        e.set_footer(text="Development by ARIAN • ZYRO")
        await ctx.reply(embed=e)
    @commands.command()
    async def ping(self,ctx):
        await ctx.reply(embed=embed("Pong",f"Gateway latency: `{self.bot.latency*1000:.0f} ms`"))
    @commands.command()
    async def botinfo(self,ctx):
        e=embed("ZYRO System",f"Servers: `{len(self.bot.guilds)}`\\nUsers cached: `{len(self.bot.users)}`\\nCommands: `{len(self.bot.commands)}`\\nPython: `{platform.python_version()}`\\nLibrary: `discord.py {discord.__version__}`\\nUptime: `{int(time.time()-self.started)}s`")
        e.set_footer(text="Development by ARIAN")
        await ctx.reply(embed=e)
    @commands.command()
    async def serverinfo(self,ctx):
        g=ctx.guild
        e=embed(g.name,f"Members: `{g.member_count}`\\nRoles: `{len(g.roles)}`\\nChannels: `{len(g.channels)}`\\nCreated: <t:{int(g.created_at.timestamp())}:R>")
        if g.icon: e.set_thumbnail(url=g.icon.url)
        await ctx.reply(embed=e)
    @commands.command()
    async def userinfo(self,ctx,member:discord.Member=None):
        m=member or ctx.author
        e=embed(str(m),f"ID: `{m.id}`\\nJoined: <t:{int(m.joined_at.timestamp())}:R>\\nCreated: <t:{int(m.created_at.timestamp())}:R>\\nTop role: {m.top_role.mention}")
        e.set_thumbnail(url=m.display_avatar.url); await ctx.reply(embed=e)
    @commands.command()
    async def avatar(self,ctx,member:discord.Member=None):
        m=member or ctx.author
        e=embed(f"{m.display_name}'s Avatar"); e.set_image(url=m.display_avatar.url); await ctx.reply(embed=e)
    @commands.command()
    async def invite(self,ctx):
        url=discord.utils.oauth_url(self.bot.user.id,permissions=discord.Permissions(view_audit_log=True,manage_channels=True,manage_roles=True,manage_messages=True,moderate_members=True,kick_members=True,ban_members=True,connect=True,speak=True,send_messages=True,embed_links=True,read_message_history=True,view_channel=True,add_reactions=True),scopes=("bot","applications.commands"))
        await ctx.reply(f"Invite ZYRO: {url}")
    @commands.command()
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def setprefix(self,ctx,prefix:str):
        if not 1<=len(prefix)<=5: return await ctx.reply("Prefix must be 1–5 characters.")
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO guild_config(guild_id,prefix) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET prefix=excluded.prefix",(ctx.guild.id,prefix)); await db.commit()
        await ctx.reply(f"Prefix updated to `{prefix}`")
    @commands.command()
    @commands.guild_only()
    async def prefix(self,ctx):
        cfg=await get_config(ctx.guild.id); await ctx.reply(f"Prefix: `{cfg.get('prefix') or PREFIX}`")
    @commands.Cog.listener()
    async def on_message(self,message):
        if message.author.bot or not message.guild: return
        async with aiosqlite.connect(DB_PATH) as db:
            cur=await db.execute("SELECT reason FROM afk WHERE user_id=?",(message.author.id,)); row=await cur.fetchone()
            if row:
                await db.execute("DELETE FROM afk WHERE user_id=?",(message.author.id,)); await db.commit()
                try: await message.reply("Welcome back! Your AFK status has been removed.",delete_after=8)
                except discord.HTTPException: pass
            for user in message.mentions[:3]:
                cur=await db.execute("SELECT reason FROM afk WHERE user_id=?",(user.id,)); afk=await cur.fetchone()
                if afk: await message.reply(f"{user.display_name} is AFK: {afk[0]}",delete_after=10)
    @commands.command()
    async def afk(self,ctx,*,reason="AFK"):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR REPLACE INTO afk(user_id,reason) VALUES(?,?)",(ctx.author.id,reason)); await db.commit()
        await ctx.reply(f"AFK enabled: {reason}")
    @commands.command()
    async def unafk(self,ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM afk WHERE user_id=?",(ctx.author.id,)); await db.commit()
        await ctx.reply("AFK removed.")
    @commands.command()
    async def poll(self,ctx,*,question):
        e=embed("Community Poll",question); msg=await ctx.send(embed=e)
        for emoji in ("👍","👎"): await msg.add_reaction(emoji)
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def say(self,ctx,*,message):
        await ctx.message.delete(); await ctx.send(message[:2000])
    @commands.command()
    @commands.has_guild_permissions(manage_messages=True)
    async def announce(self,ctx,*,message):
        await ctx.send(embed=embed("Announcement",message))
    @commands.command()
    async def roleinfo(self,ctx,role:discord.Role):
        await ctx.reply(embed=embed(role.name,f"ID: `{role.id}`\\nMembers: `{len(role.members)}`\\nPosition: `{role.position}`\\nMentionable: `{role.mentionable}`"))
    @commands.command()
    async def emojiinfo(self,ctx,emoji:discord.Emoji):
        await ctx.reply(embed=embed(emoji.name,f"ID: `{emoji.id}`\\nAnimated: `{emoji.animated}`"))
    @commands.command()
    async def uptime(self,ctx): await ctx.reply(f"Online for `{int(time.time()-self.started)}s`.")
async def setup(bot): await bot.add_cog(Core(bot))
