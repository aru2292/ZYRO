# ✦ ZYRO — All-in-one Discord Bot

**Quick start:** upload this zip + Dockerfile to GitHub, deploy on Railway, set ONE variable: `TOKEN`. Owner, data folder and emojis are set up automatically.
**ZYRO DEVELOPMENT**

## Deploy (Railway)
1. Repo root: `Dockerfile` + `ZYRO-Bot.zip` (delete the old zip when you upload a new one).
2. Variables: `TOKEN`, `OWNER_IDS` (your Discord ID), `DATA_DIR=/data` + a Volume mounted at `/data`.
3. Developer Portal → Bot → enable **Server Members Intent** + **Message Content Intent**.
4. Invite with Administrator, then drag **ZYRO's role to the very TOP** of the server roles and run `&zyrocheck`.

## Security
- Layer 1: `&antinuke enable` → role `ZYRO ./unbypassble` (refuses to enable if risky roles are above ZYRO).
- Layer 2 (premium): `&pantinuke enable` → role `ZYRO+++ ./unbypassble`, `&pwl @user` daily limits, `&pautomod enable`.

## Premium (bot owner)
`&premium grant @user 3month` (7d, 1month, 6month, 1year, lifetime …) → user is DM'd + gets No-Prefix.
User runs `&premium activate` in their server. Owner/extra-owner there can use `&botavatar`, `&botbanner`, `&botbio`.

## New in this version
`&panic` / `&unpanic` (nuke emergency) • `&admins` (who can nuke you) • modmail • confessions • roleall/removeall • sticky roles • voice-time stats (`&vctime`, `&vctop`) • AI (`&ask`, `&aichannel`; set `ANTHROPIC_API_KEY` or `AI_API_KEY`) • slash commands auto-trimmed to Discord's 100 limit (prefix commands always work).

## Custom emojis
Upload emojis (Developer Portal → Emojis), then fill `custom_emojis.json` (see `EMOJI_LIST.md`). Every unicode emoji in messages, embeds, buttons and menus is replaced automatically. Empty = unicode.

## Emoji pack (premium)
Run once as bot owner: `&emojisync` (or `&emojisync clean`). It uploads the pack as Application Emojis, maps them, and the whole bot switches to custom emojis. `&emojireset` goes back to unicode.

## ZYRO DEVELOPMENT — v3
- Prefix `&` • Slash: every command also works as `/module command` (grouped because Discord allows only 100).
- Staff teams: `&zteam @user ADMIN|TEAM ZYRO|CORE TEAM` (Developer = built-in ID + bot owner). Premium quota: TEAM ZYRO 200, CORE TEAM 100, Admin/Developer unlimited.
- Support: https://discord.gg/dsA3sbcHH
