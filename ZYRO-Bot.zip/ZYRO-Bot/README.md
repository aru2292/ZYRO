# ⚡ ZYRO — All-in-One Discord Bot

**Development by ARIAN**

ZYRO is a high-performance, multipurpose Discord bot focused on **security (Anti-Nuke)**, **moderation**, **Voice Master (VC setup)**, community tools, and more. Built on top of a solid modular architecture and cleaned for easy deployment.

---

## ✨ Key Features

- 🛡️ **Advanced Anti-Nuke** — Full protection (ban, kick, role, channel, webhook, bot add, prune, everyone, guild update, etc.)
- ⚖️ **AutoMod** — Anti-spam, anti-link, anti-invite, anti-caps, anti-mass-mention, anti-emoji-spam
- 🔊 **Voice Master** — Dynamic temporary voice channels
- 👋 **Welcome System** — Highly customizable
- 🎉 **Giveaways**
- 💤 **AFK System**
- 📊 **Stats, Tracker, Logging**
- 🎭 **Roles, Steal emoji, Utility, Moderation**
- 💎 **Premium / Boost system** (optional)
- 🤖 **Jishaku** (owner only)
- Pure **Unicode emojis** (no custom emoji dependency)

> Music system can be added later with Lavalink / Wavelink for best quality. Current base is optimized for Railway free tier.

---

## 🚀 Deploy on Railway (Recommended Free Host)

### 1. Create Discord Application
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. New Application → name it **ZYRO**
3. Bot tab → Add Bot → Reset Token → Copy TOKEN
4. Enable: **Message Content Intent**, **Server Members Intent**, **Presence Intent** (optional)
5. OAuth2 → URL Generator → scopes: `bot` + `applications.commands` → permissions: Administrator (or fine-tune)
6. Copy the invite link and invite the bot to your server

### 2. Push to GitHub
1. Create a new **private** GitHub repository (recommended private)
2. Upload all files from this ZYRO-Bot folder (or use Git)
3. Make sure `.env` is **NOT** uploaded (it is in .gitignore)

### 3. Deploy on Railway
1. Go to [railway.app](https://railway.app) → Login with GitHub
2. New Project → Deploy from GitHub repo → select your ZYRO repo
3. Railway will detect the **Dockerfile** automatically
4. Go to **Variables** tab and add:
   ```
   TOKEN=your_bot_token_here
   OWNER_ID=your_discord_user_id
   ```
   (Optional: SUPPORT_LINK, INVITE_LINK, VOTE_LINK)
5. Deploy → wait for build → bot comes online

### 4. Check Logs
In Railway → Deployments → View Logs. You should see:
```
⚡ ZYRO BOT ONLINE
Logged in as : ZYRO#xxxx
Development by ARIAN
```

---

## 🛠️ Local Development

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and put your TOKEN + OWNER_ID
python main.py
```

---

## 📁 Project Structure

```
ZYRO-Bot/
├── main.py              # Entry point
├── emojis.py            # Pure Unicode emojis
├── requirements.txt
├── Dockerfile           # Railway ready
├── .env.example
├── cogs/                # Commands
├── antinuke/            # Anti-nuke modules
├── automod/             # Auto moderation
├── events/              # Event listeners
└── db/                  # SQLite databases (auto-created)
```

---

## 🔧 Important Notes

- Default prefix: `+` (change with `+setprefix`)
- Owner commands require correct `OWNER_ID`
- Database files are created automatically on first run
- Never commit `.env` or real `db/*.db` files
- For production, keep the repo **private**

---

## 👨‍💻 Credit

**Development by ARIAN**

Original base architecture improved, cleaned, Unicode-emoji converted, branded and made Railway-ready as **ZYRO**.

---

## 📜 License

Private use / personal project. Do not resell as-is.
