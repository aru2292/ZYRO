"""
ZYRO Music Cog (Basic)
Development by ARIAN

Note: For high-quality 24/7 music use Lavalink + Wavelink later.
This is a lightweight placeholder with join/leave + info.
"""

import discord
from discord.ext import commands
from emojis import MUSIC, CHECK, CROSS, VOICE, INFO, LOADING

class Music(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="join", aliases=["j", "connect"])
    async def join(self, ctx: commands.Context):
        """Join your current voice channel"""
        if not ctx.author.voice:
            return await ctx.send(f"{CROSS} You must be in a voice channel.")
        
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            if ctx.voice_client.channel == channel:
                return await ctx.send(f"{INFO} Already connected to {channel.mention}")
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        
        await ctx.send(f"{CHECK} {VOICE} Joined **{channel.name}**")

    @commands.command(name="leave", aliases=["dc", "disconnect", "stop"])
    async def leave(self, ctx: commands.Context):
        """Leave the voice channel"""
        if not ctx.voice_client:
            return await ctx.send(f"{CROSS} I am not connected to any voice channel.")
        
        await ctx.voice_client.disconnect()
        await ctx.send(f"{CHECK} Disconnected.")

    @commands.command(name="musichelp", aliases=["mhelp"])
    async def musichelp(self, ctx: commands.Context):
        embed = discord.Embed(
            title=f"{MUSIC} ZYRO Music Commands",
            description=(
                f"{CHECK} `+join` / `+j` — Join your voice channel\n"
                f"{CHECK} `+leave` / `+dc` — Leave voice channel\n\n"
                f"{INFO} **Full music (play, queue, skip, etc.)** requires Lavalink.\n"
                f"Current version keeps the bot lightweight for free hosts (Railway).\n\n"
                f"**Development by ARIAN**"
            ),
            color=0x2B2D31
        )
        await ctx.send(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
