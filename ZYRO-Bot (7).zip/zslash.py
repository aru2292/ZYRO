"""Slash-command gateway: EVERY prefix command also works as /module command. ZYRO DEVELOPMENT
Discord allows only 100 global slash commands, so commands are grouped per module: /music play, /moderation ban ..."""
import re
import typing
import logging

import discord
from discord import app_commands
from discord.ext import commands
from discord.ext.commands.view import StringView

log = logging.getLogger("zyro.slash")
SKIP_COGS = {"Jishaku", "Dev", "EmojiSync", "Cogs", "React", "NoPrefix"}
PRIORITY = set("""ping help play skip stop pause resume queue volume nowplaying loop shuffle join leave serverinfo userinfo avatar
ban kick unban warn timeout balance daily rank leaderboard poll ask 8ball meme premium zyrocheck vctop modmailsetup confess""".split())


def _safe(name: str):
    n = re.sub(r"[^a-z0-9_-]", "", name.lower())[:32]
    return n or None


def _desc(cmd) -> str:
    d = (cmd.short_doc or cmd.help or cmd.description or "").strip().split("\n")[0] or f"Run the {cmd.name} command"
    return d[:100]


async def run(bot, interaction: discord.Interaction, cmd_name: str, target, channel, text):
    cmd = bot.get_command(cmd_name)
    if cmd is None:
        return await interaction.response.send_message("That command is not available.", ephemeral=True)
    await interaction.response.defer()
    parts = [x.mention for x in (target, channel) if x is not None]
    if text:
        parts.append(text)
    payload = {"id": interaction.id, "reactions": [], "embeds": [], "mention_everyone": False, "tts": False, "pinned": False,
               "edited_timestamp": None, "type": 20, "flags": 0, "content": "", "mentions": [], "mention_roles": [], "attachments": []}
    chan = interaction.channel or discord.PartialMessageable(state=interaction._state, id=interaction.channel_id, guild_id=interaction.guild_id)
    msg = discord.Message(state=interaction._state, channel=chan, data=payload)
    msg.author = interaction.user
    ctx = commands.Context(message=msg, bot=bot, view=StringView(" ".join(parts)), prefix="/", invoked_with=cmd.name,
                           command=cmd, interaction=interaction)
    sent = [False]
    for attr in ("send", "reply"):
        orig = getattr(ctx, attr)

        async def wrapper(*a, _o=orig, **k):
            sent[0] = True
            return await _o(*a, **k)
        setattr(ctx, attr, wrapper)
    await bot.invoke(ctx)
    if not sent[0]:
        try:
            await interaction.delete_original_response()
        except Exception:
            pass


def _make(bot, name):
    async def callback(interaction: discord.Interaction,
                       target: typing.Optional[typing.Union[discord.Member, discord.Role]] = None,
                       channel: typing.Optional[discord.abc.GuildChannel] = None,
                       text: typing.Optional[str] = None):
        await run(bot, interaction, name, target, channel, text)
    return callback


def build(bot) -> int:
    tree = bot.tree
    by: dict = {}
    for cmd in bot.commands:
        if cmd.hidden or (cmd.cog_name or "") in SKIP_COGS:
            continue
        by.setdefault(cmd.cog_name or "Misc", []).append(cmd)
    taken = {c.name for c in tree.get_commands()}
    count = 0
    for cog, cmds in sorted(by.items()):
        base = _safe(cog) or "misc"
        cmds = sorted(cmds, key=lambda c: c.name)
        for n, i in enumerate(range(0, len(cmds), 25)):
            gname = base if n == 0 else f"{base}{n + 1}"
            while gname in taken:
                gname += "x"
            grp = app_commands.Group(name=gname[:32], description=f"{cog} commands"[:100])
            seen = set()
            for c in cmds[i:i + 25]:
                nm = _safe(c.name)
                if not nm or nm in seen:
                    continue
                seen.add(nm)
                try:
                    grp.add_command(app_commands.Command(name=nm, description=_desc(c), callback=_make(bot, c.name)))
                    count += 1
                except Exception as e:
                    log.warning("slash skip %s: %s", c.name, e)
            if grp.commands:
                tree.add_command(grp)
                taken.add(gname)
    return count


def trim(bot, limit: int = 100):
    """Keep total top-level slash commands <= 100 (groups cover everything; extra single hybrids are dropped first)."""
    tree = bot.tree
    singles = [c for c in tree.get_commands() if not isinstance(c, app_commands.Group)]
    for c in singles:
        if len(tree.get_commands()) <= limit:
            break
        if c.name not in PRIORITY:
            tree.remove_command(c.name)
    while len(tree.get_commands()) > limit:
        tree.remove_command(tree.get_commands()[-1].name)
