# ZYRO emoji pack — 100% Unicode (no custom/server emojis needed, works in every server)
# ZYRO DEVELOPMENT

# --- Main ---
CHECK = "✅"
VERIFIED_CHECK = "☑️"
CROSS = "❌"
CROSS_MARK = "✖️"
TICK = "✔️"
ZTICK = "✔️"
ERROR_X = "⛔"
LOCK = "🔒"
UNLOCK = "🔓"
GHOST = "👻"
UNGHOST = "🫥"
BOOST = "🚀"
INFO = "⚠️"
CART = "🛒"
SUPPORT = "🛟"
DELETE = "🗑️"
LOADING = "⏳"

# --- Stats ---
STATS = "📊"
UPTIME = "🕰️"
DATABASE = "🗄️"
VERIFIED_DEV = "🛠️"
OS_SYSTEM = "🖥️"
CPU = "⚙️"
RAM = "🧠"
STORAGE = "💾"
CROWN = "👑"
GEARS = "⚙️"
LINK = "🔗"
CREDITS = "💳"

# --- Utility ---
TIMER = "⏱️"
REPLY = "↳"
REPLY_2 = "╰┈➤"
BELL = "🔔"

# --- Role / Status ---
VIP = "💎"
FRIEND = "🤝"
VERIFIED = "🛡️"
ENABLED = "🟢"
DISABLED = "🔴"
DISABLED_OFF = "⚫"

# --- ZYRO extra symbols (rare / stylish) ---
STAR = "✦"
DIAMOND = "❖"
ARROW = "➤"
SPARK = "✧"
FLOWER = "❀"
DOT = "•"
MUSIC = "🎵"
NOTE = "♪"
PLAY = "▶️"
PAUSE = "⏸️"
STOP = "⏹️"
SKIP = "⏭️"
SHUFFLE = "🔀"
LOOP = "🔁"
VOLUME = "🔊"
COIN = "🪙"
GEM = "💠"
FIRE = "🔥"
SHIELD = "🛡️"
SWORD = "⚔️"
BAN = "🔨"
PARTY = "🎉"
HEART = "💜"
SPARKLES = "✨"
ROCKET = "🚀"
BOLT = "⚡"
TARGET = "🎯"
TICKET = "🎫"
GIFT = "🎁"
MAIL = "📩"
PIN = "📌"


# --- More emojis used across ZYRO (embeds, buttons, menus) ---
ROBOT = "🤖"
STAR_YELLOW = "⭐"
SIREN = "🚨"
MEMBERS = "👥"
ROLE_TAG = "🏷️"
BIRTHDAY = "🎂"
MODMAIL = "📨"
NOTE_PAD = "📝"
SEARCH = "🔎"
GOLD = "🥇"
SILVER = "🥈"
BRONZE = "🥉"
FOLDER = "📁"
OPEN_FOLDER = "📂"
MIC = "🎙️"
HEADPHONES = "🎧"
GAMEPAD = "🎮"
BULB = "💡"
THUMBS_UP = "👍"
THUMBS_DOWN = "👎"
PLUS = "➕"
MINUS = "➖"
RECYCLE = "♻️"
USER = "👤"
TOOLBOX = "🧰"
CHAT = "💬"
SMILE = "😀"
CLIPBOARD = "📋"
WRENCH = "🔧"
REFRESH = "🔄"
RADIO_KNOB = "🔘"
NUMBERS = "🔢"
SHUSH = "🤫"
MAGNIFIER = "🔍"
SLOT_CHERRY = "🍒"
SLOT_LEMON = "🍋"
SLOT_GRAPE = "🍇"
SLOT_MACHINE = "🎰"
MONEY_BAG = "💰"
DIZZY = "😵"
HAND_UP = "🙋"
MASKS = "🎭"
PENCIL = "✏️"
INBOX = "📥"
OUTBOX = "📤"
INFINITY = "♾️"
INFO_I = "ℹ️"
LOCK_KEY = "🔐"
CHART_UP = "📈"
CONSTRUCTION = "🏗️"
RECEIPT = "🧾"
PICTURE = "🖼️"
WAVE = "👋"
THOUGHT = "💭"
PREV = "◀️"
HOME = "🏠"
BOOK = "📖"
TROPHY = "🏆"
BOOT = "👢"
BOOM = "💥"
EIGHT_BALL = "🎱"
DICE = "🎲"
ROCK = "🪨"
PAPER = "📄"
SCISSORS = "✂️"
COOL = "😎"
THINKING = "🤔"
LOVE = "💞"
LAUGH = "😂"
MONOCLE = "🧐"
DEVIL = "😈"
SHRUG = "🤷"
OPTION_A = "🅰️"
OPTION_B = "🅱️"
PALETTE = "🎨"
STOP_SIGN = "🛑"
ABACUS = "🧮"
CLOCK = "🕒"
WEATHER = "🌤️"
QR_CODE = "🔳"
YELLOW_DOT = "🟡"
ORANGE_DOT = "🟠"
NAME_BADGE = "📛"
EMPTY_MAILBOX = "📭"
QUESTION = "❓"
NUM_1 = "1️⃣"
NUM_2 = "2️⃣"
NUM_3 = "3️⃣"
NUM_4 = "4️⃣"
NUM_5 = "5️⃣"
NUM_6 = "6️⃣"
NUM_7 = "7️⃣"
NUM_8 = "8️⃣"
NUM_9 = "9️⃣"
NUM_10 = "🔟"


# --- VoiceMaster interface icons (red set) ---
VC_LOCK = "🔏"
VC_UNLOCK = "🔑"
VC_HIDE = "🙈"
VC_UNHIDE = "👀"
VC_LIMIT = "🚧"
VC_BAN = "🚫"
VC_PERMIT = "🪪"
VC_KICK = "🦵"
VC_BITRATE = "📶"
VC_REGION = "🌍"
VC_CLAIM = "🚩"
VC_TRANSFER = "↔️"

FIRST = "⏪"
LAST = "⏩"

# --- Plain text symbols (NOT auto-replaced everywhere; only where the code uses these constants) ---
ARROW_RIGHT = "→"
ARROW_LONG = "➜"
BAR = "▬"
SYMBOL_ONLY = {"ARROW", "STAR", "SPARK", "DIAMOND", "FLOWER", "DOT", "NOTE", "REPLY", "REPLY_2", "ARROW_RIGHT", "ARROW_LONG", "BAR"}

# snapshot of default unicode values (before any custom override)
_DEFAULT = {k: v for k, v in dict(globals()).items() if k.isupper() and isinstance(v, str) and k != "SYMBOL_ONLY"}

# --- Custom emoji override -------------------------------------------------------------------
# Sources (later wins):  ./custom_emojis.json   then   $DATA_DIR/custom_emojis.json  (written by `&emojisync`)
import json as _json
import os as _os
import re as _re

_HERE = _os.path.dirname(_os.path.abspath(__file__))
_MAP: dict = {}
_RE = None
_installed = False


def _norm(s: str) -> str:
    return s.replace("\ufe0f", "")


def _files():
    return [_os.path.join(_HERE, "custom_emojis.json"), _os.path.join(_os.getenv("DATA_DIR", "db"), "custom_emojis.json")]


def reload():
    """(Re)load custom emojis. Unicode defaults are restored first, then overrides are applied."""
    global _MAP, _RE
    for k, v in _DEFAULT.items():
        globals()[k] = v
    for p in _files():
        if not _os.path.exists(p):
            continue
        try:
            with open(p, encoding="utf-8") as f:
                for k, v in _json.load(f).items():
                    if v and isinstance(v, str) and k in _DEFAULT:
                        globals()[k] = v.strip()
        except Exception as e:
            print("custom emoji file error:", p, e)
    _MAP = {}
    for name, d in _DEFAULT.items():
        cur = globals()[name]
        if cur != d and name not in SYMBOL_ONLY:
            _MAP.setdefault(_norm(d), cur)
    if _MAP:
        keys = sorted(_MAP, key=len, reverse=True)
        _RE = _re.compile("|".join("\ufe0f?".join(_re.escape(ch) for ch in k) + "\ufe0f?" for k in keys))
    else:
        _RE = None
    return len(_MAP)


def translate(text):
    """Replace unicode emojis with your custom emojis (no-op if none configured)."""
    if not _RE or not isinstance(text, str) or not text:
        return text
    return _RE.sub(lambda m: _MAP.get(_norm(m.group(0)), m.group(0)), text)


def _tr_embed(e):
    if e is None:
        return
    try:
        if e.title:
            e.title = translate(e.title)
        if e.description:
            e.description = translate(e.description)
        for i, f in enumerate(list(e.fields)):
            e.set_field_at(i, name=translate(f.name), value=translate(f.value), inline=f.inline)
    except Exception:
        pass


def install():
    """Patch discord.py once so every unicode emoji is shown as the custom emoji (works live after reload())."""
    global _installed
    if _installed:
        return
    _installed = True
    import functools
    import discord
    from discord.ext import commands

    def wrap(cls, name):
        orig = getattr(cls, name, None)
        if orig is None:
            return

        @functools.wraps(orig)
        async def w(self, *a, **k):
            if _RE:
                a = list(a)
                if a and isinstance(a[0], str):
                    a[0] = translate(a[0])
                if isinstance(k.get("content"), str):
                    k["content"] = translate(k["content"])
                _tr_embed(k.get("embed"))
                for e in (k.get("embeds") or []):
                    _tr_embed(e)
            return await orig(self, *a, **k)
        setattr(cls, name, w)

    for cls, name in ((commands.Context, "send"), (commands.Context, "reply"), (discord.abc.Messageable, "send"),
                      (discord.Message, "edit"), (discord.Message, "reply"), (discord.InteractionResponse, "send_message"),
                      (discord.InteractionResponse, "edit_message"), (discord.Webhook, "send"), (discord.WebhookMessage, "edit"),
                      (discord.Interaction, "edit_original_response")):
        try:
            wrap(cls, name)
        except Exception:
            pass

    def wrap_init(cls):
        orig = cls.__init__

        @functools.wraps(orig)
        def init(self, *a, **k):
            if _RE and isinstance(k.get("emoji"), str):
                k["emoji"] = translate(k["emoji"])
            return orig(self, *a, **k)
        cls.__init__ = init

    for cls in (discord.ui.Button, discord.SelectOption):
        try:
            wrap_init(cls)
        except Exception:
            pass
    td = getattr(discord.ui, "TextDisplay", None)
    if td:
        o = td.__init__

        @functools.wraps(o)
        def tinit(self, content, *a, **k):
            return o(self, translate(content), *a, **k)
        td.__init__ = tinit
    print(f"[emojis] translator installed ({len(_MAP)} custom emojis active)")


reload()

# --- Compatibility mappings ---
EMOJIES = {
    "lock": LOCK, "unlock": UNLOCK, "ghost": GHOST, "unghost": UNGHOST,
    "boost": BOOST, "info": INFO, "cross": CROSS, "cart": CART, "check": CHECK,
}

ROLE_EMOJIS = {
    "Developer": VERIFIED_DEV, "Vip": VIP, "Friend": FRIEND,
    "Owner": CROWN, "Verified": VERIFIED,
}
