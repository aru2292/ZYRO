"""Shared helpers for ZYRO cogs. ZYRO DEVELOPMENT"""
import os
import discord
from config import DATA_DIR, EMBED_COLOR, FOOTER
from emojis import CHECK, CROSS, INFO


def db_path(name: str) -> str:
    return str(DATA_DIR / name)


def embed(title: str = None, desc: str = None, color: int = EMBED_COLOR, footer: bool = True) -> discord.Embed:
    e = discord.Embed(title=title, description=desc, color=color)
    if footer:
        e.set_footer(text=FOOTER)
    return e


def ok(text: str) -> discord.Embed:
    return embed(None, f"{CHECK} {text}", 0x2ECC71)


def err(text: str) -> discord.Embed:
    return embed(None, f"{CROSS} {text}", 0xE74C3C)


def warn(text: str) -> discord.Embed:
    return embed(None, f"{INFO} {text}", 0xF1C40F)


def fmt_dur(seconds) -> str:
    try:
        seconds = int(seconds or 0)
    except Exception:
        return "LIVE"
    if seconds <= 0:
        return "LIVE"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def progress_bar(pos: int, total: int, size: int = 14) -> str:
    if not total:
        return "▬" * size
    i = min(size - 1, int(size * pos / total))
    return "▬" * i + "🔘" + "▬" * (size - i - 1)


def can_act(ctx, target: discord.Member) -> str | None:
    """Return an error string if ctx.author / bot can't act on target (role hierarchy)."""
    if target.id == ctx.author.id:
        return "You can't do that to yourself."
    if target.id == ctx.guild.owner_id:
        return "You can't do that to the server owner."
    if ctx.author.id != ctx.guild.owner_id and target.top_role >= ctx.author.top_role:
        return "That member's top role is higher or equal to yours."
    if target.top_role >= ctx.guild.me.top_role:
        return "That member's top role is higher or equal to mine."
    return None


def risky_above(guild: discord.Guild):
    """Roles (with real members) that sit above ZYRO's top role and have dangerous perms -> ZYRO could not punish them."""
    me = guild.me
    out = []
    for r in guild.roles:
        if r.is_default() or r.id == me.top_role.id or r.position < me.top_role.position:
            continue
        p = r.permissions
        if not (p.administrator or p.manage_guild or p.ban_members or p.kick_members or p.manage_roles or p.manage_channels):
            continue
        if any(m.id != guild.owner_id and m.id != me.id for m in r.members):
            out.append(r)
    return out
