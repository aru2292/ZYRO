"""ZYRO mention reply — premium look. ZYRO DEVELOPMENT"""
from pathlib import Path
import discord
from discord.ext import commands

import zpremium as zp
from config import SUPPORT_LINK, INVITE_LINK
from emojis import STAR, ARROW, BOOK, CROWN

BANNER = Path(__file__).resolve().parent.parent / "assets" / "mention_banner.png"


class MentionView(discord.ui.View):
    def __init__(self, bot, message, prefix):
        super().__init__(timeout=120)
        self.bot, self.message, self.prefix = bot, message, prefix
        self.message_sent = None
        h = discord.ui.Button(label="Help", emoji=BOOK, style=discord.ButtonStyle.primary)
        h.callback = self.help_cb
        p = discord.ui.Button(label="Premium", emoji=CROWN, style=discord.ButtonStyle.secondary)
        p.callback = self.prem_cb
        self.add_item(h)
        self.add_item(p)
        inv = bot.invite_link or INVITE_LINK
        if inv:
            self.add_item(discord.ui.Button(label="Invite", style=discord.ButtonStyle.link, url=inv))
        if SUPPORT_LINK:
            self.add_item(discord.ui.Button(label="Support", style=discord.ButtonStyle.link, url=SUPPORT_LINK))

    async def interaction_check(self, i):
        if i.user.id != self.message.author.id:
            await i.response.send_message("Tag me yourself to use these buttons 💜", ephemeral=True)
            return False
        return True

    async def _run(self, i, name):
        await i.response.defer()
        cmd = self.bot.get_command(name)
        ctx = await self.bot.get_context(self.message)
        ctx.command, ctx.invoked_with, ctx.prefix = cmd, name, self.prefix
        await self.bot.invoke(ctx)

    async def help_cb(self, i):
        await self._run(i, "help")

    async def prem_cb(self, i):
        await self._run(i, "premium")

    async def on_timeout(self):
        if self.message_sent:
            try:
                await self.message_sent.edit(view=None)
            except Exception:
                pass


class MentionReply(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not self.bot.user:
            return
        if message.content.strip() not in (f"<@{self.bot.user.id}>", f"<@!{self.bot.user.id}>"):
            return
        prefixes = await self.bot.get_prefix(message)
        plist = prefixes if isinstance(prefixes, list) else [prefixes]
        prefix = next((p for p in plist if not str(p).startswith("<@")), "&")
        b = self.bot
        premium = False
        if message.guild:
            try:
                premium = await zp.guild_premium(message.guild.id)
            except Exception:
                pass
        e = discord.Embed(color=0x7B2FFF, title=f"{STAR} ZYRO {STAR}")
        e.description = (f"Hey {message.author.mention}! I'm **ZYRO** — security, music, moderation, economy and much more, all in one bot.\n\n"
                         f"{ARROW} Prefix: **`{prefix}`**  •  Slash: **`/`**\n"
                         f"{ARROW} Start with `{prefix}help`  •  `{prefix}antinuke enable`  •  `{prefix}play <song>`")
        e.add_field(name="Servers", value=f"`{len(b.guilds):,}`")
        e.add_field(name="Users", value=f"`{sum(g.member_count or 0 for g in b.guilds):,}`")
        e.add_field(name="Commands", value=f"`{len(set(b.walk_commands()))}`")
        e.add_field(name="Latency", value=f"`{round(b.latency * 1000)}ms`")
        e.add_field(name="ZYRO+++", value="💎 **Active here**" if premium else f"`{prefix}premium`")
        e.set_thumbnail(url=b.user.display_avatar.url)
        e.set_footer(text="ZYRO DEVELOPMENT")
        kw = {}
        if BANNER.exists():
            e.set_image(url="attachment://zyro_banner.png")
            kw["file"] = discord.File(BANNER, filename="zyro_banner.png")
        view = MentionView(b, message, prefix)
        try:
            view.message_sent = await message.reply(embed=e, view=view, mention_author=False, **kw)
        except discord.Forbidden:
            try:
                await message.channel.send(f"Hey! My prefix is `{prefix}` — use `{prefix}help`")
            except Exception:
                pass
        except Exception:
            try:
                kw.pop("file", None)
                e.set_image(url=None)
                view.message_sent = await message.reply(embed=e, view=view, mention_author=False)
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(MentionReply(bot))
