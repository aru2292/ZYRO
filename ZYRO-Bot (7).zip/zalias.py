"""Short aliases for every command (applied at startup; skipped if the alias is already taken). ZYRO DEVELOPMENT"""
ALIASES = {
    "serverinfo": ["si", "guildinfo", "server", "sinfo"], "userinfo": ["ui", "whois", "profile", "uinfo", "user"],
    "avatar": ["av", "pfp", "dp"], "banner": ["bn", "ban2"], "ping": ["pg", "latency", "ms"], "uptime": ["up"],
    "stats": ["botinfo", "bi", "about"], "invite": ["inv", "add"], "support": ["supp", "server2", "sup"], "vote": ["v"],
    "setprefix": ["prefix", "sp", "pre"], "resetprefix": ["rp", "rprefix"],
    "antinuke": ["an", "anti", "antiwizz"], "whitelist": ["wl", "wlist2"], "unwhitelist": ["unwl", "uwl"], "extraowner": ["eo", "owner"],
    "premium": ["prem", "pr"], "zteam": ["zt", "team"],
    "warn": ["w", "wrn"], "ban": ["b", "bn2"], "unban": ["ub", "uban"], "kick": ["k", "kk"], "mute": ["mt", "silence"], "unmute": ["umt", "um"],
    "lock": ["lk", "lockchannel"], "unlock": ["ulk", "unlockchannel"], "hide": ["hd", "hidechannel"], "unhide": ["uhd", "unhidechannel"],
    "purge": ["clear", "prg", "cls", "clean"], "snipe": ["sn", "s2"],
    "volume": ["vol", "vl"], "shuffle": ["shuf", "mix"], "remove": ["rm", "rmq"], "musicsetup": ["msetup", "ms"],
    "vcmute": ["vcm"], "vcunmute": ["vcum"], "vcdeafen": ["vcd"], "vcundeafen": ["vcud"], "vckick": ["vck"], "vcmove": ["vcmv"],
    "vcpull": ["vcp"], "vcmoveall": ["vcma"], "vcmuteall": ["vcmall"], "vcunmuteall": ["vcuma"], "vcinfo": ["vci"], "vclimit": ["vcl"],
    "vctime": ["vct"], "setvc": ["vcsetup", "vcs"],
    "delwarn": ["dw", "rmwarn"], "clearwarns": ["cw"], "untimeout": ["uto", "unto"], "softban": ["sb", "sban"], "tempban": ["tb", "tban"],
    "slowmode": ["sm", "slow"], "nuke": ["nk"], "lockdown": ["ld", "lockall"], "unlockdown": ["uld", "unlockall"], "unbanall": ["uba"],
    "deposit": ["dep"], "withdraw": ["with", "wd"], "daily": ["dly"], "work": ["wk"], "crime": ["cr"], "bet": ["gamble"],
    "levelrole": ["lr", "lvlrole"], "levelchannel": ["lc", "lvlch"], "leveling": ["lvl2", "xp"],
    "ticketsetup": ["tsetup", "tks"], "ticketadd": ["ta", "tadd"], "ticketremove": ["tr", "trem"],
    "autorole": ["arole", "joinrole"], "autoroleremove": ["arr", "rmautorole"], "starboard": ["star", "sbd"], "setsuggest": ["suggestch", "ssg"],
    "suggest": ["sug", "idea"], "sticky": ["stick"], "unsticky": ["unstick"], "setcounting": ["counting", "setcount"],
    "roleinfo": ["ri", "rinfo"], "channelinfo": ["ci", "cinfo"], "userbanner": ["ubn"], "calc": ["c", "calculate"], "poll": ["vote2", "pl"],
    "weather": ["wthr", "wx"], "qr": ["qrcode"], "emojilist": ["emojis", "el"],
    "pantinuke": ["pan", "antinuke+"], "pwl": ["pw", "pwhitelist"], "pautomod": ["pam", "automod+"], "panic": ["emergency", "pnc"],
    "unpanic": ["unp", "upanic"], "admins": ["adm", "whohasadmin"], "zyrocheck": ["zc", "secure", "securitycheck"],
    "backup": ["bk", "bkp"], "antiraid": ["raid", "ar2"], "verifysetup": ["vsetup", "verify"],
    "modmailsetup": ["mms", "modmail"], "mmclose": ["mmc", "closethread"], "confessionsetup": ["confsetup"], "roleall": ["ra", "giveall"],
    "removeall": ["rall", "takeall"], "stickyroles": ["sr", "stickyrole"], "buttonroles": ["btnroles", "br"], "statschannel": ["sc", "counter"],
    "birthday": ["bday", "bd"], "setlogs": ["logchannel", "logs"], "removelogs": ["rmlogs"], "ask": ["ai", "chat"], "aichannel": ["aich"],
    "embed": ["emb"], "giveaway": ["gw", "gaw"], "roles": ["rl"], "remind": ["reminder", "rmd"], "greet": ["gt", "welcome"],
    "steal": ["eadd"], "afk": ["away"], "help": ["h", "menu", "commands", "cmds"], "voicemaster": ["vm"],
    "nowplaying": ["np", "current"], "clearqueue": ["cq"], "skipto": ["st", "jump"], "filter": ["fx"], "loop": ["repeat", "lp"],
    "membercount": ["mc", "members"], "servericon": ["sicon", "sico"], "timestamp": ["tstamp", "unix"], "coinflip": ["flip", "cf"],
    "8ball": ["8b", "ball"], "meme": ["memes"], "action": ["act"], "roast": ["burn"], "ship": ["love"], "leaderboard": ["lb", "top"],
    "balance": ["bal", "wallet", "money"], "richest": ["baltop", "ecolb"], "rank": ["level", "lvl"], "pay": ["give", "send"],
}


def apply(bot) -> int:
    n = 0
    for name, aliases in ALIASES.items():
        cmd = bot.all_commands.get(name)
        if not cmd:
            continue
        for a in aliases:
            if a not in bot.all_commands:
                try:
                    cmd.aliases = list(cmd.aliases) + [a]
                    bot.all_commands[a] = cmd
                    n += 1
                except Exception:
                    pass
    return n
