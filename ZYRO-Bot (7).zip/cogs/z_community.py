"""ZYRO Community: modmail, confessions, roleall, sticky roles. ZYRO DEVELOPMENT"""
import asyncio
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, warn, db_path

DB = db_path("community.db")
DANGER = ("administrator", "manage_guild", "manage_roles", "manage_channels", "ban_members", "kick_members",
          "manage_webhooks", "mention_everyone")


class Community(commands.Cog, name="Community"):
    """Modmail, anonymous confessions, bulk roles and sticky roles."""

    def __init__(self, bot):
        self.bot = bot
        self.cool: dict = {}
        self.running: set = set()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS mm_cfg (guild_id INTEGER PRIMARY KEY, category_id INTEGER, staff_role INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS mm_threads (channel_id INTEGER PRIMARY KEY, guild_id INTEGER, user_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS conf_cfg (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, counter INTEGER DEFAULT 0)")
            await db.execute("CREATE TABLE IF NOT EXISTS conf_log (guild_id INTEGER, num INTEGER, user_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS sticky_cfg (guild_id INTEGER PRIMARY KEY)")
            await db.execute("CREATE TABLE IF NOT EXISTS sticky_roles (guild_id INTEGER, user_id INTEGER, roles TEXT, PRIMARY KEY (guild_id, user_id))")
            await db.commit()

    # ================= MODMAIL =================
    @commands.hybrid_command(name="modmailsetup", description="Enable modmail: members DM the bot, staff reply in a channel")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def modmailsetup(self, ctx, staff_role: discord.Role):
        cat = await ctx.guild.create_category("📨 Modmail", overwrites={
            ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            staff_role: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            ctx.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True)})
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO mm_cfg VALUES (?, ?, ?)", (ctx.guild.id, cat.id, staff_role.id))
            await db.commit()
        await ctx.send(embed=ok("Modmail enabled. Members just **DM the bot**; a private channel opens for staff.\nStaff type normally in the thread to reply. Close with `&mmclose`."))

    @commands.command(name="mmclose", aliases=["closethread"])
    @commands.guild_only()
    async def mmclose(self, ctx, *, reason: str = "No reason"):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id FROM mm_threads WHERE channel_id=?", (ctx.channel.id,)) as c:
                r = await c.fetchone()
            if not r:
                return await ctx.send(embed=err("This is not a modmail thread."))
            await db.execute("DELETE FROM mm_threads WHERE channel_id=?", (ctx.channel.id,))
            await db.commit()
        u = self.bot.get_user(r[0])
        if u:
            try:
                await u.send(embed=embed("📨 Modmail closed", f"Your thread in **{ctx.guild.name}** was closed.\nReason: {reason}"))
            except Exception:
                pass
        await ctx.send("Closing in 5s…")
        await asyncio.sleep(5)
        try:
            await ctx.channel.delete(reason="Modmail closed")
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if m.author.bot:
            return
        # user DM -> staff thread
        if m.guild is None:
            if self.cool.get(m.author.id, 0) > asyncio.get_event_loop().time():
                return
            async with aiosqlite.connect(DB) as db:
                for g in self.bot.guilds:
                    if not g.get_member(m.author.id):
                        continue
                    async with db.execute("SELECT category_id, staff_role FROM mm_cfg WHERE guild_id=?", (g.id,)) as c:
                        cfg = await c.fetchone()
                    if not cfg:
                        continue
                    async with db.execute("SELECT channel_id FROM mm_threads WHERE guild_id=? AND user_id=?", (g.id, m.author.id)) as c:
                        t = await c.fetchone()
                    ch = g.get_channel(t[0]) if t else None
                    if not ch:
                        cat = g.get_channel(cfg[0])
                        if not cat:
                            continue
                        ch = await g.create_text_channel(f"mail-{m.author.name}"[:90], category=cat, topic=f"Modmail with {m.author} ({m.author.id})")
                        await db.execute("INSERT OR REPLACE INTO mm_threads VALUES (?, ?, ?)", (ch.id, g.id, m.author.id))
                        await db.commit()
                        role = g.get_role(cfg[1])
                        await ch.send(content=role.mention if role else None, embed=embed("📨 New modmail", f"From {m.author.mention} (`{m.author.id}`)\nType here to reply. `&mmclose` to close."))
                        try:
                            await m.author.send(embed=ok(f"Thread opened with **{g.name}** staff. Send your messages here."))
                        except Exception:
                            pass
                    e = embed(None, m.content or "*attachment*", 0x3498DB)
                    e.set_author(name=str(m.author), icon_url=m.author.display_avatar.url)
                    if m.attachments:
                        e.set_image(url=m.attachments[0].url)
                    await ch.send(embed=e)
                    await m.add_reaction("✅")
                    return
            return
        # staff reply in thread -> user DM
        if m.content.startswith(("&", "+", "!", "?", ".", "-")):
            return
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id FROM mm_threads WHERE channel_id=?", (m.channel.id,)) as c:
                r = await c.fetchone()
        if r:
            u = self.bot.get_user(r[0]) or await self.bot.fetch_user(r[0])
            try:
                e = embed(None, m.content or "*attachment*", 0x2ECC71)
                e.set_author(name=f"{m.guild.name} Staff", icon_url=m.guild.icon.url if m.guild.icon else None)
                if m.attachments:
                    e.set_image(url=m.attachments[0].url)
                await u.send(embed=e)
                await m.add_reaction("📨")
            except Exception:
                await m.channel.send(embed=err("Couldn't DM that user (DMs closed)."))

    # ================= CONFESSIONS =================
    @commands.hybrid_command(name="confessionsetup", description="Set the anonymous confession channel")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def confessionsetup(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT INTO conf_cfg (guild_id, channel_id) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id", (ctx.guild.id, channel.id))
            await db.commit()
        await ctx.send(embed=ok(f"Confessions → {channel.mention}. Members use `&confess <text>` (their message is deleted)."))

    @commands.hybrid_command(name="confess", description="Send an anonymous confession")
    @commands.cooldown(1, 30, commands.BucketType.user)
    @commands.guild_only()
    async def confess(self, ctx, *, text: str):
        if ctx.interaction is None:
            try:
                await ctx.message.delete()
            except Exception:
                pass
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT channel_id, counter FROM conf_cfg WHERE guild_id=?", (ctx.guild.id,)) as c:
                cfg = await c.fetchone()
            ch = ctx.guild.get_channel(cfg[0]) if cfg else None
            if not ch:
                return await ctx.send(embed=err("Confessions are not set up."), delete_after=8)
            n = cfg[1] + 1
            await db.execute("UPDATE conf_cfg SET counter=? WHERE guild_id=?", (n, ctx.guild.id))
            await db.execute("INSERT INTO conf_log VALUES (?, ?, ?)", (ctx.guild.id, n, ctx.author.id))
            await db.commit()
        await ch.send(embed=embed(f"🤫 Anonymous Confession #{n}", text[:3800]), allowed_mentions=discord.AllowedMentions.none())
        await ctx.send(embed=ok("Your confession was posted anonymously."), ephemeral=True, delete_after=6)

    @commands.hybrid_command(name="confessinfo", description="(Admin) who wrote confession #N")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def confessinfo(self, ctx, number: int):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id FROM conf_log WHERE guild_id=? AND num=?", (ctx.guild.id, number)) as c:
                r = await c.fetchone()
        await ctx.send(embed=embed("🔍 Confession", f"#{number} was written by <@{r[0]}>") if r else err("Not found."), ephemeral=True)

    # ================= ROLE ALL =================
    @commands.command(name="roleall", help="roleall <humans|bots|all> <role> — give a role to many members")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def roleall(self, ctx, who: str, role: discord.Role):
        if role >= ctx.guild.me.top_role or role.managed or any(getattr(role.permissions, d) for d in DANGER):
            return await ctx.send(embed=err("I won't mass-give that role (above me / managed / dangerous permissions)."))
        if ctx.guild.id in self.running:
            return await ctx.send(embed=err("A bulk role job is already running here."))
        who = who.lower()
        targets = [m for m in ctx.guild.members if role not in m.roles and (who == "all" or (who == "bots") == m.bot)]
        if who not in ("all", "humans", "bots"):
            return await ctx.send(embed=err("Use `humans`, `bots` or `all`."))
        eta = int(len(targets) * 1.0 / 60) + 1
        msg = await ctx.send(embed=warn(f"Giving {role.mention} to **{len(targets)}** members… ~{eta} min (rate limits)."))
        self.running.add(ctx.guild.id)
        done = 0
        try:
            for m in targets:
                try:
                    await m.add_roles(role, reason=f"roleall by {ctx.author}")
                    done += 1
                except Exception:
                    pass
                await asyncio.sleep(1.0)
        finally:
            self.running.discard(ctx.guild.id)
        await msg.edit(embed=ok(f"Done: **{done}/{len(targets)}** members got {role.mention}."))

    @commands.command(name="removeall", help="removeall <role> — remove a role from everyone")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def removeall(self, ctx, role: discord.Role):
        if role >= ctx.guild.me.top_role or role.managed:
            return await ctx.send(embed=err("I can't edit that role."))
        if ctx.guild.id in self.running:
            return await ctx.send(embed=err("A bulk role job is already running here."))
        self.running.add(ctx.guild.id)
        done = 0
        try:
            for m in list(role.members):
                try:
                    await m.remove_roles(role, reason=f"removeall by {ctx.author}")
                    done += 1
                except Exception:
                    pass
                await asyncio.sleep(1.0)
        finally:
            self.running.discard(ctx.guild.id)
        await ctx.send(embed=ok(f"Removed {role.mention} from **{done}** members."))

    # ================= STICKY ROLES =================
    @commands.hybrid_command(name="stickyroles", description="Give members their old roles back when they rejoin: on/off")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def stickyroles(self, ctx, state: str):
        on = state.lower() in ("on", "enable", "true")
        async with aiosqlite.connect(DB) as db:
            if on:
                await db.execute("INSERT OR IGNORE INTO sticky_cfg VALUES (?)", (ctx.guild.id,))
            else:
                await db.execute("DELETE FROM sticky_cfg WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok(f"Sticky roles **{'enabled' if on else 'disabled'}** (dangerous roles are never restored)."))

    @commands.Cog.listener()
    async def on_member_remove(self, m: discord.Member):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT 1 FROM sticky_cfg WHERE guild_id=?", (m.guild.id,)) as c:
                if not await c.fetchone():
                    return
            ids = [str(r.id) for r in m.roles if not r.is_default() and not r.managed and not any(getattr(r.permissions, d) for d in DANGER)]
            if ids:
                await db.execute("INSERT OR REPLACE INTO sticky_roles VALUES (?, ?, ?)", (m.guild.id, m.id, ",".join(ids)))
                await db.commit()

    @commands.Cog.listener()
    async def on_member_join(self, m: discord.Member):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT roles FROM sticky_roles WHERE guild_id=? AND user_id=?", (m.guild.id, m.id)) as c:
                r = await c.fetchone()
        if not r:
            return
        roles = [m.guild.get_role(int(i)) for i in r[0].split(",")]
        roles = [x for x in roles if x and x < m.guild.me.top_role and not any(getattr(x.permissions, d) for d in DANGER)]
        if roles:
            try:
                await m.add_roles(*roles, reason="ZYRO sticky roles")
            except Exception:
                pass


async def setup(bot):
    await bot.add_cog(Community(bot))
