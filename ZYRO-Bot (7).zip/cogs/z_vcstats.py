"""ZYRO Voice time tracking. ZYRO DEVELOPMENT"""
import time
import aiosqlite
import discord
from discord.ext import commands, tasks
from zutil import embed, err, db_path

DB = db_path("vcstats.db")


def fmt(sec: int) -> str:
    h, r = divmod(int(sec), 3600)
    m, _ = divmod(r, 60)
    return f"{h}h {m}m"


class VCStats(commands.Cog, name="VCStats"):
    """Tracks how long members spend in voice channels."""

    def __init__(self, bot):
        self.bot = bot
        self.join: dict = {}
        self.flush.start()

    def cog_unload(self):
        self.flush.cancel()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS vc (guild_id INTEGER, user_id INTEGER, seconds INTEGER DEFAULT 0, PRIMARY KEY (guild_id, user_id))")
            await db.commit()

    async def add(self, gid, uid, sec):
        if sec <= 0:
            return
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO vc (guild_id, user_id) VALUES (?, ?)", (gid, uid))
            await db.execute("UPDATE vc SET seconds = seconds + ? WHERE guild_id=? AND user_id=?", (int(sec), gid, uid))
            await db.commit()

    @commands.Cog.listener()
    async def on_ready(self):
        now = time.time()
        for g in self.bot.guilds:
            for vc in g.voice_channels:
                for m in vc.members:
                    if not m.bot:
                        self.join.setdefault((g.id, m.id), now)

    @commands.Cog.listener()
    async def on_voice_state_update(self, m, b, a):
        if m.bot:
            return
        key = (m.guild.id, m.id)
        if b.channel is None and a.channel is not None:
            self.join[key] = time.time()
        elif b.channel is not None and a.channel is None:
            t = self.join.pop(key, None)
            if t:
                await self.add(m.guild.id, m.id, time.time() - t)

    @tasks.loop(minutes=10)
    async def flush(self):
        now = time.time()
        for (gid, uid), t in list(self.join.items()):
            await self.add(gid, uid, now - t)
            self.join[(gid, uid)] = now

    @flush.before_loop
    async def _w(self):
        await self.bot.wait_until_ready()

    @commands.hybrid_command(name="vctime", description="How long a member has spent in voice")
    @commands.guild_only()
    async def vctime(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        await self.flush()
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT seconds FROM vc WHERE guild_id=? AND user_id=?", (ctx.guild.id, member.id)) as c:
                r = await c.fetchone()
        await ctx.send(embed=embed("🎙️ Voice time", f"{member.mention} has spent **{fmt(r[0] if r else 0)}** in voice."))

    @commands.hybrid_command(name="vctop", aliases=["vclb"], description="Voice time leaderboard")
    @commands.guild_only()
    async def vctop(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, seconds FROM vc WHERE guild_id=? ORDER BY seconds DESC LIMIT 10", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No voice data yet."))
        medals = ["🥇", "🥈", "🥉"]
        await ctx.send(embed=embed("🎙️ Voice Leaderboard", "\n".join(f"{medals[i] if i < 3 else f'`{i + 1}.`'} <@{u}> — **{fmt(s)}**" for i, (u, s) in enumerate(rows))))


async def setup(bot):
    await bot.add_cog(VCStats(bot))
