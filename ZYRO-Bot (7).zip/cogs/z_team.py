"""ZYRO staff teams: DEVELOPER > ADMIN > TEAM ZYRO / CORE TEAM. ZYRO DEVELOPMENT"""
import time
import aiosqlite
import discord
from discord.ext import commands
from config import OWNER_IDS
from zutil import embed, ok, err, db_path

DB = db_path("zteam.db")
TEAMS = ["ADMIN", "TEAM ZYRO", "CORE TEAM"]
LIMITS = {"TEAM ZYRO": 200, "CORE TEAM": 100}      # how many premium users each team member may give
ALIAS = {"ADMIN": "ADMIN", "ADMINS": "ADMIN", "TEAM ZYRO": "TEAM ZYRO", "TEAMZYRO": "TEAM ZYRO", "ZYRO": "TEAM ZYRO",
         "CORE TEAM": "CORE TEAM", "CORETEAM": "CORE TEAM", "CORE": "CORE TEAM"}


def norm(t: str):
    t = " ".join((t or "").upper().replace("_", " ").replace("-", " ").split())
    return ALIAS.get(t)


async def init():
    async with aiosqlite.connect(DB) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS team (user_id INTEGER PRIMARY KEY, team TEXT, added_by INTEGER, added_at INTEGER)")
        await db.commit()


async def team_of(uid: int):
    if uid in OWNER_IDS:
        return "DEVELOPER"
    await init()
    async with aiosqlite.connect(DB) as db:
        async with db.execute("SELECT team FROM team WHERE user_id=?", (uid,)) as c:
            r = await c.fetchone()
    return r[0] if r else None


async def level(uid: int) -> int:
    return {"DEVELOPER": 3, "ADMIN": 2, "TEAM ZYRO": 1, "CORE TEAM": 1}.get(await team_of(uid), 0)


async def grant_limit(uid: int):
    """None = unlimited (developer/admin), 0 = not allowed, else quota."""
    t = await team_of(uid)
    if t in ("DEVELOPER", "ADMIN"):
        return None
    return LIMITS.get(t, 0)


async def get_teams() -> dict:
    await init()
    out = {"DEVELOPER": list(OWNER_IDS), "ADMIN": [], "TEAM ZYRO": [], "CORE TEAM": []}
    async with aiosqlite.connect(DB) as db:
        async with db.execute("SELECT user_id, team FROM team") as c:
            for uid, t in await c.fetchall():
                out.setdefault(t, []).append(uid)
    return out


_names: dict = {}


async def get_teams_named(bot) -> dict:
    """team -> [(user_id, display name)] — fresh from the DB every call, names cached."""
    teams = await get_teams()
    out = {}
    for t, ids in teams.items():
        rows = []
        for uid in ids:
            if uid not in _names:
                u = bot.get_user(uid)
                if u is None:
                    try:
                        u = await bot.fetch_user(uid)
                    except Exception:
                        u = None
                _names[uid] = (getattr(u, "global_name", None) or getattr(u, "name", None)) if u else "Unknown user"
            rows.append((uid, _names[uid] or "Unknown user"))
        out[t] = rows
    return out


async def can_grant(ctx) -> bool:          # developer / admin / team zyro / core team
    return await level(ctx.author.id) >= 1


async def admin_check(ctx) -> bool:        # developer / admin
    return await level(ctx.author.id) >= 2


class ZTeam(commands.Cog, name="ZTeam"):
    """Staff teams for ZYRO."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await init()

    @commands.group(name="zteam", aliases=["zt", "team"], invoke_without_command=True)
    async def zteam(self, ctx, user: discord.User = None, *, team: str = None):
        """zteam @user ADMIN | TEAM ZYRO | CORE TEAM — manage ZYRO staff teams."""
        lvl = await level(ctx.author.id)
        if user is None or team is None:
            return await ctx.send(embed=embed("👥 ZYRO Teams", f"`{ctx.prefix}zteam @user ADMIN` (developer only)\n`{ctx.prefix}zteam @user TEAM ZYRO`\n"
                                              f"`{ctx.prefix}zteam @user CORE TEAM`\n`{ctx.prefix}zteam remove @user`\n`{ctx.prefix}zteam list`\n\n"
                                              "**Premium quota:** Developer/Admin unlimited • TEAM ZYRO 200 • CORE TEAM 100"))
        if lvl < 2:
            return await ctx.send(embed=err("Only the **Developer** or an **Admin** can manage teams."))
        t = norm(team)
        if not t:
            return await ctx.send(embed=err("Team must be `ADMIN`, `TEAM ZYRO` or `CORE TEAM`."))
        if t == "ADMIN" and lvl < 3:
            return await ctx.send(embed=err("Only the **Developer** can add Admins."))
        if user.bot or user.id in OWNER_IDS:
            return await ctx.send(embed=err("That user can't be added (bot or already a Developer)."))
        if await team_of(user.id) == "ADMIN" and lvl < 3:
            return await ctx.send(embed=err("Only the **Developer** can change an Admin."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO team VALUES (?, ?, ?, ?)", (user.id, t, ctx.author.id, int(time.time())))
            await db.commit()
        await ctx.send(embed=ok(f"{user.mention} is now in **{t}**."), allowed_mentions=discord.AllowedMentions.none())

    @zteam.command(name="remove", aliases=["rm", "del"])
    async def z_remove(self, ctx, user: discord.User):
        lvl = await level(ctx.author.id)
        cur = await team_of(user.id)
        if lvl < 2 or (cur == "ADMIN" and lvl < 3):
            return await ctx.send(embed=err("You can't remove that user."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM team WHERE user_id=?", (user.id,))
            await db.commit()
        await ctx.send(embed=ok(f"{user.mention} removed from the teams."), allowed_mentions=discord.AllowedMentions.none())

    @zteam.command(name="list", aliases=["ls"])
    async def z_list(self, ctx):
        t = await get_teams()
        e = embed("👥 ZYRO Teams")
        for k in ("DEVELOPER", "ADMIN", "TEAM ZYRO", "CORE TEAM"):
            e.add_field(name=k, value="\n".join(f"<@{u}>" for u in t.get(k, [])) or "—", inline=False)
        await ctx.send(embed=e, allowed_mentions=discord.AllowedMentions.none())


async def setup(bot):
    await bot.add_cog(ZTeam(bot))
