"""ZYRO security self-check. ZYRO DEVELOPMENT"""
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path


class GuardCheck(commands.Cog, name="Security"):
    """Checks whether ZYRO can really protect your server."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="zyrocheck", aliases=["antinukecheck", "securitycheck"], description="Check if ZYRO antinuke can really protect this server")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def zyrocheck(self, ctx):
        g, me = ctx.guild, ctx.guild.me
        async with aiosqlite.connect(db_path("anti.db")) as db:
            async with db.execute("SELECT status FROM antinuke WHERE guild_id=?", (g.id,)) as c:
                r = await c.fetchone()
        on = bool(r and r[0])
        p = me.guild_permissions
        above = [r for r in g.roles if not r.is_default() and r.position >= me.top_role.position and r.id != me.top_role.id
                 and (r.permissions.administrator or r.permissions.ban_members or r.permissions.manage_guild or r.permissions.manage_roles)]
        admin_bots = [m for m in g.members if m.bot and m.id != me.id and m.guild_permissions.administrator]
        lines = [
            f"{'✅' if on else '❌'} Antinuke enabled",
            f"{'✅' if p.administrator else '❌'} I have Administrator",
            f"{'✅' if p.view_audit_log else '❌'} View Audit Log",
            f"{'✅' if not above else '❌'} My role is above every risky role" + (f" (**{len(above)}** above me: {', '.join(r.mention for r in above[:6])})" if above else ""),
            f"{'✅' if not admin_bots else '⚠️'} Other bots with Administrator: **{len(admin_bots)}**" + (f" — {', '.join(b.mention for b in admin_bots[:6])}" if admin_bots else ""),
        ]
        if above:
            lines.append(f"\n**FIX:** Server Settings → Roles → drag **{me.top_role.name}** to the very TOP (under nothing). Without this ZYRO cannot ban/kick those admins.")
        good = on and p.administrator and p.view_audit_log and not above
        await ctx.send(embed=embed("🛡️ ZYRO Security Check", "\n".join(lines), 0x2ECC71 if good else 0xE74C3C))


async def setup(bot):
    await bot.add_cog(GuardCheck(bot))
