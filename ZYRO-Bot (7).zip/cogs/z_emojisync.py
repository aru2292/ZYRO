"""ZYRO emoji sync: uploads the premium emoji pack as Application Emojis and maps them. ZYRO DEVELOPMENT"""
import os
import json
import asyncio
from pathlib import Path

import discord
from discord.ext import commands
import emojis
from zutil import embed, ok, err

ROOT = Path(__file__).resolve().parent.parent
PACK = ROOT / "emoji_pack"
OUT = Path(os.getenv("DATA_DIR", "db")) / "custom_emojis.json"
VER_FILE = OUT.parent / "emoji_version.txt"


def pack_version():
    try:
        return (PACK / "version.txt").read_text().strip()
    except Exception:
        return "1"


def stored_version():
    try:
        return VER_FILE.read_text().strip()
    except Exception:
        return ""


class EmojiSync(commands.Cog, name="EmojiSync"):
    """Bot-owner tools: upload the ZYRO emoji pack and switch the whole bot to custom emojis."""

    def __init__(self, bot):
        self.bot = bot
        self.lock = asyncio.Lock()
        self.auto_done = False

    async def run_sync(self, style="tiles", force=False):
        """Upload missing pack emojis as Application Emojis, write the mapping, switch the bot over."""
        async with self.lock:
            mapping = json.loads((PACK / "map.json").read_text())
            keys = sorted(set(mapping.values()))
            existing = {e.name: e for e in await self.bot.fetch_application_emojis()}
            made = failed = 0
            for k in keys:
                name = f"zyro_{k}"
                if name in existing:
                    if not force:
                        continue
                    try:
                        await existing[name].delete()
                    except Exception:
                        pass
                try:
                    existing[name] = await self.bot.create_application_emoji(name=name, image=(PACK / style / f"{k}.png").read_bytes())
                    made += 1
                except Exception:
                    failed += 1
                await asyncio.sleep(0.6)
            data = {c: str(existing[f"zyro_{k}"]) for c, k in mapping.items() if f"zyro_{k}" in existing}
            OUT.parent.mkdir(parents=True, exist_ok=True)
            OUT.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
            VER_FILE.write_text(pack_version())
            n = emojis.reload()
            emojis.install()
            return made, failed, len(data), n, data

    @commands.Cog.listener()
    async def on_ready(self):
        """First boot: upload the emoji pack automatically (set AUTO_EMOJI=0 to disable)."""
        if self.auto_done or os.getenv("AUTO_EMOJI", "1") == "0":
            return
        try:
            have = set(json.loads(OUT.read_text()).keys()) if OUT.exists() else set()
            if set(json.loads((PACK / "map.json").read_text()).keys()) <= have and stored_version() == pack_version():
                return                                  # everything already synced and up to date
        except Exception:
            pass
        self.auto_done = True
        try:
            print("[emojis] first boot -> uploading the ZYRO emoji pack automatically...")
            made, failed, mapped, live, _ = await self.run_sync("tiles", force=stored_version() != pack_version() and OUT.exists())
            print(f"[emojis] done: uploaded {made}, failed {failed}, mapped {mapped}")
        except Exception as e:
            print("[emojis] auto sync skipped:", e)

    @commands.command(name="emojisync", aliases=["syncemojis"])
    @commands.is_owner()
    async def emojisync(self, ctx, style: str = "tiles", force: str = ""):
        """emojisync [tiles|clean] [force] — upload pack, map it, switch the bot to custom emojis."""
        style = style.lower()
        if style not in ("tiles", "clean"):
            return await ctx.send(embed=err("Use `emojisync tiles` or `emojisync clean` (add `force` to re-upload)."))
        msg = await ctx.send(embed=embed("⏳ Emoji sync", "Uploading… ~1 minute."))
        try:
            made, failed, mapped, live, data = await self.run_sync(style, force.lower() == "force")
        except Exception as e:
            return await msg.edit(embed=err(f"Sync failed: `{e}`"))
        await msg.edit(embed=ok(f"Done! Uploaded **{made}**, failed **{failed}**, mapped **{mapped}** ({live} live).\n{' '.join(list(data.values())[:12])}\n\n"
                                "Active now in messages, embeds and buttons."))

    @commands.command(name="emojireset")
    @commands.is_owner()
    async def emojireset(self, ctx):
        """Go back to normal unicode emojis."""
        if OUT.exists():
            OUT.unlink()
        emojis.reload()
        await ctx.send(embed=ok("Back to unicode emojis (uploaded emojis stay in the portal)."))

    @commands.command(name="emojistatus")
    @commands.is_owner()
    async def emojistatus(self, ctx):
        """Shows how many custom emojis are active."""
        await ctx.send(embed=embed("🎨 Emoji status", f"Active custom emojis: **{len(emojis._MAP)}**\nFile: `{OUT}` {'✅ exists' if OUT.exists() else '❌ none'}\nPreview: {' '.join(list(emojis._MAP.values())[:10]) or '—'}"))


async def setup(bot):
    await bot.add_cog(EmojiSync(bot))
