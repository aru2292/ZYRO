"""ZYRO VoiceMaster — premium temporary voice channels + 12-button interface. ZYRO DEVELOPMENT"""
import time
from pathlib import Path

import aiosqlite
import discord
from discord import ui
from discord.ext import commands, tasks

from zutil import db_path
from emojis import (CHECK, CROSS, VC_LOCK, VC_UNLOCK, VC_HIDE, VC_UNHIDE, VC_LIMIT, VC_BAN, VC_PERMIT,
                    VC_KICK, VC_BITRATE, VC_REGION, VC_CLAIM, VC_TRANSFER)

DB_PATH = db_path("voicemaster.db")
BANNER = Path(__file__).resolve().parent.parent / "assets" / "vc_interface.png"
RED = 0xD91E36
REGIONS = ["us-west", "us-east", "us-central", "us-south", "rotterdam", "singapore", "southafrica", "sydney",
           "brazil", "hongkong", "russia", "japan", "india", "south-korea"]


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS voicemaster (
            guild_id INTEGER PRIMARY KEY, category_id INTEGER, interface_id INTEGER, joinvc_id INTEGER, panel_msg_id INTEGER)""")
        await db.execute("CREATE TABLE IF NOT EXISTS vc_owners (channel_id INTEGER PRIMARY KEY, owner_id INTEGER)")
        await db.commit()


def chan_name(m: discord.Member) -> str:
    """ZAYAN'S Channel  (display/main name, never the @username)"""
    return f"{m.display_name.upper()}'S Channel"[:100]


def panel_embed() -> discord.Embed:
    e = discord.Embed(title="ZYRO Voice Channel Interface", description="Use this interface to manage your voice channel!", color=RED)
    e.set_image(url="attachment://vc_interface.png")
    e.set_footer(text="ZYRO • ZYRO DEVELOPMENT")
    return e


def panel_file() -> discord.File:
    return discord.File(BANNER, filename="vc_interface.png")


# ---------------- modals / pickers ----------------
class LimitModal(ui.Modal, title="Set User Limit"):
    box = ui.TextInput(label="Limit (0 = unlimited, max 99)", placeholder="e.g. 5", max_length=2)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, i: discord.Interaction):
        try:
            n = int(str(self.box).strip())
            assert 0 <= n <= 99
        except Exception:
            return await i.response.send_message(f"{CROSS} Enter a number from 0 to 99.", ephemeral=True)
        await self.vc.edit(user_limit=n)
        await i.response.send_message(f"{CHECK} User limit: **{n or 'unlimited'}**", ephemeral=True)


class BitrateModal(ui.Modal, title="Set Bitrate (kbps)"):
    box = ui.TextInput(label="Bitrate in kbps", placeholder="e.g. 64", max_length=3)

    def __init__(self, vc):
        super().__init__()
        self.vc = vc

    async def on_submit(self, i: discord.Interaction):
        top = max(8, self.vc.guild.bitrate_limit // 1000)
        try:
            n = int(str(self.box).strip())
            assert 8 <= n <= top
        except Exception:
            return await i.response.send_message(f"{CROSS} Enter a number from 8 to {top}.", ephemeral=True)
        await self.vc.edit(bitrate=n * 1000)
        await i.response.send_message(f"{CHECK} Bitrate: **{n} kbps**", ephemeral=True)


class PickUser(ui.View):
    def __init__(self, author_id, action):
        super().__init__(timeout=60)
        self.author_id, self.action = author_id, action
        sel = ui.UserSelect(placeholder="Select a member…", min_values=1, max_values=1)
        sel.callback = self.on_pick
        self.add_item(sel)

    async def interaction_check(self, i):
        return i.user.id == self.author_id

    async def on_pick(self, i: discord.Interaction):
        member = i.guild.get_member(int(i.data["values"][0]))
        if not member:
            return await i.response.edit_message(content=f"{CROSS} Member not found.", view=None)
        await self.action(i, member)


class RegionPick(ui.View):
    def __init__(self, author_id, vc):
        super().__init__(timeout=60)
        self.author_id, self.vc = author_id, vc
        sel = ui.Select(placeholder="Choose a voice region…", options=[discord.SelectOption(label="Automatic", value="auto")] +
                        [discord.SelectOption(label=r, value=r) for r in REGIONS])
        sel.callback = self.pick
        self.add_item(sel)

    async def interaction_check(self, i):
        return i.user.id == self.author_id

    async def pick(self, i: discord.Interaction):
        v = i.data["values"][0]
        await self.vc.edit(rtc_region=None if v == "auto" else v)
        await i.response.edit_message(content=f"{CHECK} Region: **{v}**", view=None)


# ---------------- the interface ----------------
class VoiceMasterView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def vc_of(self, i: discord.Interaction, need_owner=True):
        m = i.user
        if not m.voice or not m.voice.channel:
            await i.response.send_message(f"{CROSS} Join your voice channel first.", ephemeral=True)
            return None
        vc = m.voice.channel
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id FROM vc_owners WHERE channel_id=?", (vc.id,)) as c:
                row = await c.fetchone()
        if not row:
            await i.response.send_message(f"{CROSS} This is not a ZYRO VoiceMaster channel.", ephemeral=True)
            return None
        if need_owner and row[0] != m.id:
            await i.response.send_message(f"{CROSS} Only the channel owner (<@{row[0]}>) can use this. If they left, press **Claim**.", ephemeral=True)
            return None
        return vc

    async def done(self, i, text):
        await i.response.send_message(f"{CHECK} {text}", ephemeral=True)

    @ui.button(emoji=VC_LOCK, style=discord.ButtonStyle.gray, custom_id="vm_lock", row=0)
    async def lock(self, i, b):
        if vc := await self.vc_of(i):
            await vc.set_permissions(i.guild.default_role, connect=False)
            await self.done(i, "Channel **locked**.")

    @ui.button(emoji=VC_UNLOCK, style=discord.ButtonStyle.gray, custom_id="vm_unlock", row=0)
    async def unlock(self, i, b):
        if vc := await self.vc_of(i):
            await vc.set_permissions(i.guild.default_role, connect=None)
            await self.done(i, "Channel **unlocked**.")

    @ui.button(emoji=VC_HIDE, style=discord.ButtonStyle.gray, custom_id="vm_hide", row=0)
    async def hide(self, i, b):
        if vc := await self.vc_of(i):
            await vc.set_permissions(i.guild.default_role, view_channel=False)
            await self.done(i, "Channel **hidden**.")

    @ui.button(emoji=VC_UNHIDE, style=discord.ButtonStyle.gray, custom_id="vm_unhide", row=0)
    async def unhide(self, i, b):
        if vc := await self.vc_of(i):
            await vc.set_permissions(i.guild.default_role, view_channel=None)
            await self.done(i, "Channel **visible**.")

    @ui.button(emoji=VC_LIMIT, style=discord.ButtonStyle.gray, custom_id="vm_limit", row=1)
    async def limit(self, i, b):
        if vc := await self.vc_of(i):
            await i.response.send_modal(LimitModal(vc))

    @ui.button(emoji=VC_BAN, style=discord.ButtonStyle.gray, custom_id="vm_ban", row=1)
    async def ban(self, i, b):
        if vc := await self.vc_of(i):
            async def act(ii, member):
                if member.id in (i.user.id, i.guild.me.id):
                    return await ii.response.edit_message(content=f"{CROSS} You can't ban that user.", view=None)
                await vc.set_permissions(member, connect=False)
                if member.voice and member.voice.channel == vc:
                    await member.move_to(None)
                await ii.response.edit_message(content=f"{CHECK} {member.mention} is **banned** from this channel.", view=None)
            await i.response.send_message("Who do you want to ban?", view=PickUser(i.user.id, act), ephemeral=True)

    @ui.button(emoji=VC_PERMIT, style=discord.ButtonStyle.gray, custom_id="vm_permit", row=1)
    async def permit(self, i, b):
        if vc := await self.vc_of(i):
            async def act(ii, member):
                await vc.set_permissions(member, connect=True, view_channel=True)
                await ii.response.edit_message(content=f"{CHECK} {member.mention} is **permitted** (works even when locked/hidden).", view=None)
            await i.response.send_message("Who do you want to permit?", view=PickUser(i.user.id, act), ephemeral=True)

    @ui.button(emoji=VC_KICK, style=discord.ButtonStyle.gray, custom_id="vm_kick", row=1)
    async def kick(self, i, b):
        if vc := await self.vc_of(i):
            async def act(ii, member):
                if member.id == i.user.id or not (member.voice and member.voice.channel == vc):
                    return await ii.response.edit_message(content=f"{CROSS} That member is not in your channel.", view=None)
                await member.move_to(None)
                await ii.response.edit_message(content=f"{CHECK} Kicked {member.mention}.", view=None)
            await i.response.send_message("Who do you want to kick?", view=PickUser(i.user.id, act), ephemeral=True)

    @ui.button(emoji=VC_BITRATE, style=discord.ButtonStyle.gray, custom_id="vm_bitrate", row=2)
    async def bitrate(self, i, b):
        if vc := await self.vc_of(i):
            await i.response.send_modal(BitrateModal(vc))

    @ui.button(emoji=VC_REGION, style=discord.ButtonStyle.gray, custom_id="vm_region", row=2)
    async def region(self, i, b):
        if vc := await self.vc_of(i):
            await i.response.send_message("Pick a region:", view=RegionPick(i.user.id, vc), ephemeral=True)

    @ui.button(emoji=VC_CLAIM, style=discord.ButtonStyle.gray, custom_id="vm_claim", row=2)
    async def claim(self, i, b):
        vc = await self.vc_of(i, need_owner=False)
        if not vc:
            return
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id FROM vc_owners WHERE channel_id=?", (vc.id,)) as c:
                owner = (await c.fetchone())[0]
            if owner == i.user.id:
                return await i.response.send_message(f"{CROSS} You already own this channel.", ephemeral=True)
            if any(m.id == owner for m in vc.members):
                return await i.response.send_message(f"{CROSS} The owner is still in the channel.", ephemeral=True)
            await db.execute("UPDATE vc_owners SET owner_id=? WHERE channel_id=?", (i.user.id, vc.id))
            await db.commit()
        try:
            await vc.edit(name=chan_name(i.user))
        except Exception:
            pass
        await self.done(i, f"You are now the owner of **{vc.name}**.")

    @ui.button(emoji=VC_TRANSFER, style=discord.ButtonStyle.gray, custom_id="vm_transfer", row=2)
    async def transfer(self, i, b):
        if vc := await self.vc_of(i):
            async def act(ii, member):
                if member.bot or member.id == i.user.id or not (member.voice and member.voice.channel == vc):
                    return await ii.response.edit_message(content=f"{CROSS} Pick a human who is inside your channel.", view=None)
                async with aiosqlite.connect(DB_PATH) as db:
                    await db.execute("UPDATE vc_owners SET owner_id=? WHERE channel_id=?", (member.id, vc.id))
                    await db.commit()
                try:
                    await vc.edit(name=chan_name(member))
                except Exception:
                    pass
                await ii.response.edit_message(content=f"{CHECK} Ownership transferred to {member.mention}.", view=None)
            await i.response.send_message("Transfer ownership to:", view=PickUser(i.user.id, act), ephemeral=True)


# ---------------- cog ----------------
class VoiceMaster(commands.Cog, name="VoiceMaster"):
    def __init__(self, bot):
        self.bot = bot
        self.recent: dict = {}
        bot.add_view(VoiceMasterView())
        self.cleanup_task.start()

    def cog_unload(self):
        self.cleanup_task.stop()

    @commands.group(name="voicemaster", aliases=["vm"], invoke_without_command=True)
    async def voicemaster(self, ctx):
        await ctx.send(f"Use `{ctx.prefix}vm setup`, `{ctx.prefix}vm panel` or `{ctx.prefix}vm remove`.")

    @voicemaster.command(name="setup")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def vm_setup(self, ctx):
        g = ctx.guild
        if not g.me.guild_permissions >= discord.Permissions(manage_channels=True, move_members=True, manage_permissions=True):
            return await ctx.send(f"{CROSS} I need Manage Channels, Move Members and Manage Permissions.")
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT 1 FROM voicemaster WHERE guild_id=?", (g.id,)) as c:
                if await c.fetchone():
                    return await ctx.send(f"{CROSS} VoiceMaster is already set up. Use `{ctx.prefix}vm panel` to resend the interface.")
        try:
            cat = await g.create_category("ZYRO | VoiceMaster")
            join = await cat.create_voice_channel("➕ Join To Create")
            iface = await cat.create_text_channel("interface", overwrites={g.default_role: discord.PermissionOverwrite(send_messages=False)})
            msg = await iface.send(embed=panel_embed(), file=panel_file(), view=VoiceMasterView())
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("INSERT OR REPLACE INTO voicemaster VALUES (?,?,?,?,?)", (g.id, cat.id, iface.id, join.id, msg.id))
                await db.commit()
            await ctx.send(f"{CHECK} VoiceMaster ready! Join {join.mention} to get your own channel — controls are in {iface.mention}.")
        except discord.Forbidden:
            await ctx.send(f"{CROSS} I'm missing permissions to create channels / send messages.")

    @voicemaster.command(name="panel")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def vm_panel(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT interface_id FROM voicemaster WHERE guild_id=?", (ctx.guild.id,)) as c:
                row = await c.fetchone()
        ch = ctx.guild.get_channel(row[0]) if row else None
        if not ch:
            return await ctx.send(f"{CROSS} Run `{ctx.prefix}vm setup` first.")
        await ch.send(embed=panel_embed(), file=panel_file(), view=VoiceMasterView())
        await ctx.send(f"{CHECK} Interface sent to {ch.mention}.")

    @voicemaster.command(name="remove")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def vm_remove(self, ctx):
        g = ctx.guild
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT category_id, interface_id, joinvc_id FROM voicemaster WHERE guild_id=?", (g.id,)) as c:
                row = await c.fetchone()
            if not row:
                return await ctx.send(f"{CROSS} VoiceMaster is not set up.")
            for cid in row:
                ch = g.get_channel(cid)
                if ch:
                    try:
                        await ch.delete()
                    except Exception:
                        pass
            await db.execute("DELETE FROM voicemaster WHERE guild_id=?", (g.id,))
            await db.commit()
        await ctx.send(f"{CHECK} VoiceMaster removed.")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel:
            return
        async with aiosqlite.connect(DB_PATH) as db:
            if after.channel:
                async with db.execute("SELECT joinvc_id, category_id, interface_id FROM voicemaster WHERE guild_id=?", (member.guild.id,)) as c:
                    row = await c.fetchone()
                if row and after.channel.id == row[0] and time.time() - self.recent.get(member.id, 0) > 4:
                    self.recent[member.id] = time.time()
                    cat = member.guild.get_channel(row[1])
                    if cat:
                        try:
                            vc = await cat.create_voice_channel(
                                chan_name(member),
                                overwrites={member: discord.PermissionOverwrite(view_channel=True, connect=True, speak=True)})
                            await member.move_to(vc)
                            await db.execute("INSERT OR REPLACE INTO vc_owners VALUES (?,?)", (vc.id, member.id))
                            await db.commit()
                            iface = member.guild.get_channel(row[2])
                            try:
                                e = discord.Embed(title="ZYRO Voice Channel", color=RED,
                                                  description=f"Welcome {member.mention}! This is **your** channel.\nManage it from {iface.mention if iface else 'the interface channel'}.")
                                e.set_footer(text="ZYRO • ZYRO DEVELOPMENT")
                                await vc.send(embed=e)
                            except Exception:
                                pass
                        except discord.HTTPException:
                            pass
            if before.channel:
                async with db.execute("SELECT 1 FROM vc_owners WHERE channel_id=?", (before.channel.id,)) as c:
                    owned = await c.fetchone()
                if owned and len(before.channel.members) == 0:
                    try:
                        await before.channel.delete()
                    except Exception:
                        pass
                    await db.execute("DELETE FROM vc_owners WHERE channel_id=?", (before.channel.id,))
                    await db.commit()

    @tasks.loop(hours=1.0)
    async def cleanup_task(self):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT channel_id FROM vc_owners") as c:
                rows = await c.fetchall()
            for (cid,) in rows:
                ch = self.bot.get_channel(cid)
                if not ch or len(ch.members) == 0:
                    try:
                        if ch:
                            await ch.delete()
                    except Exception:
                        pass
                    await db.execute("DELETE FROM vc_owners WHERE channel_id=?", (cid,))
            await db.commit()

    @cleanup_task.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await init_db()
    await bot.add_cog(VoiceMaster(bot))
