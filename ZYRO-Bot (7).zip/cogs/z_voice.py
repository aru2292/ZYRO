"""ZYRO Voice tools (vcsetup / vc moderation). ZYRO DEVELOPMENT"""
import discord
from discord.ext import commands
from zutil import embed, ok, err


class VoiceTools(commands.Cog, name="Voice"):
    """Voice channel moderation & utilities."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="vcmute", description="Server-mute a member in voice")
    @commands.has_permissions(mute_members=True)
    @commands.bot_has_permissions(mute_members=True)
    @commands.guild_only()
    async def vcmute(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.edit(mute=True, reason=f"vcmute by {ctx.author}")
        await ctx.send(embed=ok(f"Muted {member.mention} in voice."))

    @commands.hybrid_command(name="vcunmute", description="Server-unmute a member in voice")
    @commands.has_permissions(mute_members=True)
    @commands.bot_has_permissions(mute_members=True)
    @commands.guild_only()
    async def vcunmute(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.edit(mute=False)
        await ctx.send(embed=ok(f"Unmuted {member.mention}."))

    @commands.hybrid_command(name="vcdeafen", description="Server-deafen a member")
    @commands.has_permissions(deafen_members=True)
    @commands.bot_has_permissions(deafen_members=True)
    @commands.guild_only()
    async def vcdeafen(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.edit(deafen=True)
        await ctx.send(embed=ok(f"Deafened {member.mention}."))

    @commands.hybrid_command(name="vcundeafen", description="Undeafen a member")
    @commands.has_permissions(deafen_members=True)
    @commands.bot_has_permissions(deafen_members=True)
    @commands.guild_only()
    async def vcundeafen(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.edit(deafen=False)
        await ctx.send(embed=ok(f"Undeafened {member.mention}."))

    @commands.hybrid_command(name="vckick", description="Kick a member from voice")
    @commands.has_permissions(move_members=True)
    @commands.bot_has_permissions(move_members=True)
    @commands.guild_only()
    async def vckick(self, ctx, member: discord.Member):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.move_to(None, reason=f"vckick by {ctx.author}")
        await ctx.send(embed=ok(f"Kicked {member.mention} from voice."))

    @commands.hybrid_command(name="vcmove", description="Move a member to another voice channel")
    @commands.has_permissions(move_members=True)
    @commands.bot_has_permissions(move_members=True)
    @commands.guild_only()
    async def vcmove(self, ctx, member: discord.Member, channel: discord.VoiceChannel):
        if not member.voice:
            return await ctx.send(embed=err("Member is not in a voice channel."))
        await member.move_to(channel)
        await ctx.send(embed=ok(f"Moved {member.mention} to **{channel.name}**."))

    @commands.hybrid_command(name="vcpull", description="Pull a member into your voice channel")
    @commands.has_permissions(move_members=True)
    @commands.bot_has_permissions(move_members=True)
    @commands.guild_only()
    async def vcpull(self, ctx, member: discord.Member):
        if not ctx.author.voice or not member.voice:
            return await ctx.send(embed=err("Both of you must be in voice channels."))
        await member.move_to(ctx.author.voice.channel)
        await ctx.send(embed=ok(f"Pulled {member.mention} to you."))

    @commands.hybrid_command(name="vcmoveall", description="Move everyone from your VC to another VC")
    @commands.has_permissions(move_members=True)
    @commands.bot_has_permissions(move_members=True)
    @commands.guild_only()
    async def vcmoveall(self, ctx, channel: discord.VoiceChannel):
        if not ctx.author.voice:
            return await ctx.send(embed=err("Join a voice channel first."))
        n = 0
        for m in list(ctx.author.voice.channel.members):
            try:
                await m.move_to(channel)
                n += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"Moved **{n}** members to **{channel.name}**."))

    @commands.hybrid_command(name="vcmuteall", description="Mute everyone in your VC (except you)")
    @commands.has_permissions(mute_members=True)
    @commands.bot_has_permissions(mute_members=True)
    @commands.guild_only()
    async def vcmuteall(self, ctx):
        if not ctx.author.voice:
            return await ctx.send(embed=err("Join a voice channel first."))
        n = 0
        for m in ctx.author.voice.channel.members:
            if m.id != ctx.author.id and not m.bot:
                try:
                    await m.edit(mute=True)
                    n += 1
                except Exception:
                    pass
        await ctx.send(embed=ok(f"Muted **{n}** members."))

    @commands.hybrid_command(name="vcunmuteall", description="Unmute everyone in your VC")
    @commands.has_permissions(mute_members=True)
    @commands.bot_has_permissions(mute_members=True)
    @commands.guild_only()
    async def vcunmuteall(self, ctx):
        if not ctx.author.voice:
            return await ctx.send(embed=err("Join a voice channel first."))
        n = 0
        for m in ctx.author.voice.channel.members:
            try:
                await m.edit(mute=False)
                n += 1
            except Exception:
                pass
        await ctx.send(embed=ok(f"Unmuted **{n}** members."))

    @commands.hybrid_command(name="vcinfo", description="Info about a voice channel")
    @commands.guild_only()
    async def vcinfo(self, ctx, channel: discord.VoiceChannel = None):
        channel = channel or (ctx.author.voice.channel if ctx.author.voice else None)
        if not channel:
            return await ctx.send(embed=err("Join or specify a voice channel."))
        e = embed(f"🔊 {channel.name}")
        e.add_field(name="Members", value=str(len(channel.members)))
        e.add_field(name="Limit", value=str(channel.user_limit or "∞"))
        e.add_field(name="Bitrate", value=f"{channel.bitrate // 1000} kbps")
        e.add_field(name="Category", value=channel.category.name if channel.category else "None")
        if channel.members:
            e.add_field(name="In channel", value=", ".join(m.display_name for m in channel.members[:20]), inline=False)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="vclimit", description="Set user limit of your voice channel")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def vclimit(self, ctx, limit: int):
        if not ctx.author.voice:
            return await ctx.send(embed=err("Join a voice channel first."))
        await ctx.author.voice.channel.edit(user_limit=max(0, min(limit, 99)))
        await ctx.send(embed=ok(f"Limit set to **{limit}**."))

    @commands.hybrid_command(name="setvc", aliases=["vcsetup"], description="Create a full voice hub (category + VC)")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def setvc(self, ctx):
        cat = await ctx.guild.create_category("✦ ZYRO Voice ✦")
        await ctx.guild.create_voice_channel("🎧・Lounge", category=cat)
        await ctx.guild.create_voice_channel("🎵・Music", category=cat)
        await ctx.guild.create_voice_channel("🎮・Gaming", category=cat)
        await ctx.send(embed=ok("Voice hub created! For join-to-create channels use the **VoiceMaster** setup command."))


async def setup(bot):
    await bot.add_cog(VoiceTools(bot))
