"""ZYRO Antinuke Whitelist — per-action toggles, owner/extra-owner only. ZYRO DEVELOPMENT"""
import discord
from discord.ext import commands
import aiosqlite
from zutil import embed, ok, err, db_path

DB = db_path("anti.db")

ACTIONS = {
    "ban": "Ban", "kick": "Kick", "prune": "Prune", "botadd": "Bot Add",
    "serverup": "Server Update", "memup": "Member Update",
    "chcr": "Channel Create", "chdl": "Channel Delete", "chup": "Channel Update",
    "rlcr": "Role Create", "rldl": "Role Delete", "rlup": "Role Update",
    "meneve": "Mention Everyone", "mngweb": "Manage Webhooks",
}

SCHEMA = """CREATE TABLE IF NOT EXISTS whitelisted_users (
    guild_id INTEGER, user_id INTEGER,
    ban BOOLEAN DEFAULT FALSE, kick BOOLEAN DEFAULT FALSE, prune BOOLEAN DEFAULT FALSE,
    botadd BOOLEAN DEFAULT FALSE, serverup BOOLEAN DEFAULT FALSE, memup BOOLEAN DEFAULT FALSE,
    chcr BOOLEAN DEFAULT FALSE, chdl BOOLEAN DEFAULT FALSE, chup BOOLEAN DEFAULT FALSE,
    rlcr BOOLEAN DEFAULT FALSE, rlup BOOLEAN DEFAULT FALSE, rldl BOOLEAN DEFAULT FALSE,
    meneve BOOLEAN DEFAULT FALSE, mngweb BOOLEAN DEFAULT FALSE, mngstemo BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (guild_id, user_id))"""


async def init():
    async with aiosqlite.connect(DB) as db:
        await db.execute(SCHEMA)
        await db.execute("CREATE TABLE IF NOT EXISTS extraowners (guild_id INTEGER, owner_id INTEGER, PRIMARY KEY (guild_id, owner_id))")
        await db.commit()


async def is_trusted(ctx) -> bool:
    """Server owner, ZYRO extra owner, or ZYRO bot owner."""
    if ctx.author.id == ctx.guild.owner_id or await ctx.bot.is_owner(ctx.author):
        return True
    async with aiosqlite.connect(DB) as db:
        async with db.execute("SELECT 1 FROM extraowners WHERE guild_id=? AND owner_id=?", (ctx.guild.id, ctx.author.id)) as c:
            return await c.fetchone() is not None


async def get_perms(gid, uid) -> dict:
    cols = ", ".join(ACTIONS)
    async with aiosqlite.connect(DB) as db:
        async with db.execute(f"SELECT {cols} FROM whitelisted_users WHERE guild_id=? AND user_id=?", (gid, uid)) as c:
            row = await c.fetchone()
    if row is None:
        return {}
    return {k: bool(v) for k, v in zip(ACTIONS, row)}


async def set_perms(gid, uid, enabled: set):
    sets = ", ".join(f"{k}=?" for k in ACTIONS)
    vals = [1 if k in enabled else 0 for k in ACTIONS]
    async with aiosqlite.connect(DB) as db:
        await db.execute("INSERT OR IGNORE INTO whitelisted_users (guild_id, user_id) VALUES (?, ?)", (gid, uid))
        await db.execute(f"UPDATE whitelisted_users SET {sets} WHERE guild_id=? AND user_id=?", (*vals, gid, uid))
        await db.commit()


def render(guild, target, perms: dict, author) -> discord.Embed:
    lines = [f"{'🟢' if perms.get(k) else '🔴'} **{name}**" for k, name in ACTIONS.items()]
    e = embed(f"🛡️ Whitelist — {guild.name}", "\n".join(lines))
    e.add_field(name="Target", value=target.mention)
    e.add_field(name="Set by", value=author.mention)
    e.add_field(name="Allowed", value=f"{sum(perms.values())}/{len(ACTIONS)}")
    return e


class WLView(discord.ui.View):
    def __init__(self, ctx, target, perms):
        super().__init__(timeout=180)
        self.ctx, self.target, self.perms = ctx, target, dict(perms)
        self.message = None
        self._build()

    def _build(self):
        self.clear_items()
        sel = discord.ui.Select(
            placeholder="Choose allowed actions (selected = whitelisted)",
            min_values=0, max_values=len(ACTIONS),
            options=[discord.SelectOption(label=n, value=k, default=bool(self.perms.get(k))) for k, n in ACTIONS.items()],
        )
        sel.callback = self.on_select
        self.add_item(sel)
        for label, style, cb in (("Allow ALL", discord.ButtonStyle.success, self.all_cb),
                                 ("Clear ALL", discord.ButtonStyle.danger, self.none_cb),
                                 ("Done", discord.ButtonStyle.secondary, self.done_cb)):
            b = discord.ui.Button(label=label, style=style)
            b.callback = cb
            self.add_item(b)

    async def interaction_check(self, i: discord.Interaction) -> bool:
        if i.user.id != self.ctx.author.id:
            await i.response.send_message("Only the command user can use this.", ephemeral=True)
            return False
        return True

    async def _save_and_render(self, i):
        await set_perms(self.ctx.guild.id, self.target.id, {k for k, v in self.perms.items() if v})
        self._build()
        await i.response.edit_message(embed=render(self.ctx.guild, self.target, self.perms, self.ctx.author), view=self)

    async def on_select(self, i: discord.Interaction):
        chosen = set(i.data.get("values", []))
        self.perms = {k: (k in chosen) for k in ACTIONS}
        await self._save_and_render(i)

    async def all_cb(self, i):
        self.perms = {k: True for k in ACTIONS}
        await self._save_and_render(i)

    async def none_cb(self, i):
        self.perms = {k: False for k in ACTIONS}
        await self._save_and_render(i)

    async def done_cb(self, i):
        await self._cleanup()
        await i.response.edit_message(embed=render(self.ctx.guild, self.target, self.perms, self.ctx.author), view=None)
        self.stop()

    async def _cleanup(self):
        if not any(self.perms.values()):     # no ghost "whitelisted with nothing" rows
            async with aiosqlite.connect(DB) as db:
                await db.execute("DELETE FROM whitelisted_users WHERE guild_id=? AND user_id=?", (self.ctx.guild.id, self.target.id))
                await db.commit()

    async def on_timeout(self):
        await self._cleanup()
        if self.message:
            try:
                await self.message.edit(view=None)
            except Exception:
                pass


class Whitelist(commands.Cog, name="Whitelist"):
    """Antinuke whitelist: each action is separate, only owner/extra-owner can edit."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await init()

    @commands.command(name="whitelist", aliases=["wl"], help="Whitelist a user for chosen antinuke actions.")
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.guild_only()
    async def whitelist(self, ctx, member: discord.Member = None):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can manage the whitelist."))
        if member is None:
            return await ctx.send(embed=embed("🛡️ Whitelist", f"`{ctx.prefix}whitelist @user` — pick exactly which actions are allowed\n`{ctx.prefix}whitelisted` — list\n`{ctx.prefix}unwhitelist @user` — remove\n`{ctx.prefix}whitelistreset` — remove everyone"))
        if member.id == ctx.guild.owner_id:
            return await ctx.send(embed=err("The server owner is always allowed."))
        perms = await get_perms(ctx.guild.id, member.id)
        view = WLView(ctx, member, perms)
        view.message = await ctx.send(embed=render(ctx.guild, member, perms, ctx.author), view=view)

    @commands.command(name="whitelisted", aliases=["wlist"], help="Shows the whitelisted users.")
    @commands.guild_only()
    async def whitelisted(self, ctx):
        if not await is_trusted(ctx):
            return await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can view this."))
        cols = ", ".join(ACTIONS)
        async with aiosqlite.connect(DB) as db:
            async with db.execute(f"SELECT user_id, {cols} FROM whitelisted_users WHERE guild_id=?", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=embed("🛡️ Whitelisted", "Nobody is whitelisted."))
        lines = []
        for r in rows[:40]:
            allowed = [ACTIONS[k] for k, v in zip(ACTIONS, r[1:]) if v]
            txt = "ALL actions" if len(allowed) == len(ACTIONS) else (", ".join(allowed) or "none")
            lines.append(f"<@{r[0]}> — {txt[:150]}")
        await ctx.send(embed=embed(f"🛡️ Whitelisted ({len(rows)})", "\n".join(lines)))

    @commands.command(name="whitelistreset", aliases=["wlreset"], help="Remove everyone from the whitelist.")
    @commands.guild_only()
    async def whitelistreset(self, ctx):
        if ctx.author.id != ctx.guild.owner_id and not await self.bot.is_owner(ctx.author):
            return await ctx.send(embed=err("Only the **Server Owner** can reset the whitelist."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM whitelisted_users WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok("Whitelist reset."))


async def setup(bot):
    await bot.add_cog(Whitelist(bot))
