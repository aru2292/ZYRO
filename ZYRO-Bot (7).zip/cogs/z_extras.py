"""ZYRO Extras: button roles, stats channels, birthdays. ZYRO DEVELOPMENT"""
import datetime
import aiosqlite
import discord
from discord.ext import commands, tasks
from zutil import embed, ok, err, db_path

DB = db_path("extras.db")
KINDS = {
    "members": ("👥 Members", lambda g: g.member_count),
    "bots": ("🤖 Bots", lambda g: sum(1 for m in g.members if m.bot)),
    "humans": ("🙋 Humans", lambda g: g.member_count - sum(1 for m in g.members if m.bot)),
    "channels": ("📁 Channels", lambda g: len(g.channels)),
    "roles": ("🏷️ Roles", lambda g: len(g.roles)),
    "boosts": ("🚀 Boosts", lambda g: g.premium_subscription_count or 0),
}


class Extras(commands.Cog, name="Extras"):
    """Button roles, live stats channels and birthdays."""

    def __init__(self, bot):
        self.bot = bot
        self.stats_loop.start()
        self.bday_loop.start()
        self._last_bday = None

    def cog_unload(self):
        self.stats_loop.cancel()
        self.bday_loop.cancel()

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS stats (guild_id INTEGER, channel_id INTEGER PRIMARY KEY, kind TEXT)")
            await db.execute("CREATE TABLE IF NOT EXISTS bday (guild_id INTEGER, user_id INTEGER, day INTEGER, month INTEGER, PRIMARY KEY (guild_id, user_id))")
            await db.execute("CREATE TABLE IF NOT EXISTS bday_cfg (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()

    # ---------------- button roles ----------------
    @commands.hybrid_command(name="buttonroles", aliases=["btnroles"], description="Create a button-role panel with up to 5 roles")
    @commands.has_permissions(manage_roles=True)
    @commands.guild_only()
    async def buttonroles(self, ctx, role1: discord.Role, role2: discord.Role = None, role3: discord.Role = None,
                          role4: discord.Role = None, role5: discord.Role = None):
        roles = [r for r in (role1, role2, role3, role4, role5) if r]
        for r in roles:
            if r >= ctx.guild.me.top_role or r.managed or r.permissions.administrator:
                return await ctx.send(embed=err(f"I can't safely give {r.mention} (above me / managed / admin)."))
        view = discord.ui.View(timeout=None)
        for r in roles:
            view.add_item(discord.ui.Button(label=r.name[:40], style=discord.ButtonStyle.secondary, custom_id=f"zbr:{r.id}"))
        await ctx.channel.send(embed=embed("🎭 Pick your roles", "Press a button to get / remove a role.\n" + "\n".join(r.mention for r in roles)), view=view)
        if ctx.interaction:
            await ctx.send(embed=ok("Panel created."), ephemeral=True)

    @commands.Cog.listener()
    async def on_interaction(self, i: discord.Interaction):
        cid = (i.data or {}).get("custom_id", "") if i.type == discord.InteractionType.component else ""
        if not cid.startswith("zbr:") or not i.guild:
            return
        role = i.guild.get_role(int(cid.split(":")[1]))
        if not role or role >= i.guild.me.top_role or role.permissions.administrator:
            return await i.response.send_message("That role is unavailable.", ephemeral=True)
        try:
            if role in i.user.roles:
                await i.user.remove_roles(role, reason="ZYRO button role")
                await i.response.send_message(f"➖ Removed {role.mention}", ephemeral=True)
            else:
                await i.user.add_roles(role, reason="ZYRO button role")
                await i.response.send_message(f"➕ Added {role.mention}", ephemeral=True)
        except Exception:
            await i.response.send_message("I couldn't change that role.", ephemeral=True)

    # ---------------- stats channels ----------------
    @commands.hybrid_command(name="statschannel", description="Create a live stats voice channel: members/bots/humans/channels/roles/boosts")
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def statschannel(self, ctx, kind: str):
        kind = kind.lower()
        if kind not in KINDS:
            return await ctx.send(embed=err("Kinds: " + ", ".join(f"`{k}`" for k in KINDS)))
        label, fn = KINDS[kind]
        ch = await ctx.guild.create_voice_channel(
            f"{label}: {fn(ctx.guild)}",
            overwrites={ctx.guild.default_role: discord.PermissionOverwrite(connect=False, view_channel=True)},
            reason="ZYRO stats channel")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO stats VALUES (?, ?, ?)", (ctx.guild.id, ch.id, kind))
            await db.commit()
        await ctx.send(embed=ok(f"Created {ch.mention} (updates every 10 minutes)."))

    @tasks.loop(minutes=10)
    async def stats_loop(self):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT guild_id, channel_id, kind FROM stats") as c:
                rows = await c.fetchall()
            for gid, cid, kind in rows:
                g = self.bot.get_guild(gid)
                ch = g.get_channel(cid) if g else None
                if not ch:
                    if g:
                        await db.execute("DELETE FROM stats WHERE channel_id=?", (cid,))
                    continue
                label, fn = KINDS.get(kind, KINDS["members"])
                name = f"{label}: {fn(g)}"
                if ch.name != name:
                    try:
                        await ch.edit(name=name, reason="ZYRO stats update")
                    except Exception:
                        pass
            await db.commit()

    @stats_loop.before_loop
    async def _w1(self):
        await self.bot.wait_until_ready()

    # ---------------- birthdays ----------------
    @commands.group(name="birthday", aliases=["bday"], invoke_without_command=True)
    @commands.guild_only()
    async def birthday(self, ctx):
        p = ctx.prefix
        await ctx.send(embed=embed("🎂 Birthdays", f"`{p}birthday set DD-MM` — save yours\n`{p}birthday remove`\n`{p}birthday channel #channel` — (admin) announcements\n`{p}birthdays` — upcoming list"))

    @birthday.command(name="set")
    async def b_set(self, ctx, date: str):
        try:
            d, m = (int(x) for x in date.replace("/", "-").split("-"))
            datetime.date(2000, m, d)
        except Exception:
            return await ctx.send(embed=err("Use format `DD-MM`, e.g. `25-12`."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO bday VALUES (?, ?, ?, ?)", (ctx.guild.id, ctx.author.id, d, m))
            await db.commit()
        await ctx.send(embed=ok(f"Birthday saved: **{d:02d}-{m:02d}** 🎂"))

    @birthday.command(name="remove")
    async def b_remove(self, ctx):
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM bday WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id))
            await db.commit()
        await ctx.send(embed=ok("Birthday removed."))

    @birthday.command(name="channel")
    @commands.has_permissions(manage_guild=True)
    async def b_channel(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO bday_cfg VALUES (?, ?)", (ctx.guild.id, channel.id))
            await db.commit()
        await ctx.send(embed=ok(f"Birthday wishes will be sent in {channel.mention}."))

    @commands.command(name="birthdays", aliases=["bdays"])
    @commands.guild_only()
    async def birthdays(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, day, month FROM bday WHERE guild_id=?", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No birthdays saved."))
        today = datetime.date.today()

        def nxt(d, m):
            try:
                x = datetime.date(today.year, m, d)
            except ValueError:
                x = datetime.date(today.year, 3, 1)
            return x if x >= today else x.replace(year=today.year + 1)
        rows.sort(key=lambda r: nxt(r[1], r[2]))
        await ctx.send(embed=embed("🎂 Upcoming Birthdays", "\n".join(f"<@{u}> — **{d:02d}-{m:02d}**" for u, d, m in rows[:15])))

    @tasks.loop(minutes=30)
    async def bday_loop(self):
        today = datetime.datetime.utcnow().date()
        if self._last_bday == today:
            return
        self._last_bday = today
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT guild_id, user_id FROM bday WHERE day=? AND month=?", (today.day, today.month)) as c:
                rows = await c.fetchall()
            for gid, uid in rows:
                async with db.execute("SELECT channel_id FROM bday_cfg WHERE guild_id=?", (gid,)) as c:
                    cfg = await c.fetchone()
                g = self.bot.get_guild(gid)
                ch = g.get_channel(cfg[0]) if (g and cfg) else None
                if ch:
                    try:
                        await ch.send(f"🎉🎂 Happy Birthday <@{uid}>! 🎂🎉", allowed_mentions=discord.AllowedMentions(users=True))
                    except Exception:
                        pass

    @bday_loop.before_loop
    async def _w2(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(Extras(bot))
