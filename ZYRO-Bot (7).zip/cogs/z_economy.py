"""ZYRO Economy. ZYRO DEVELOPMENT"""
import random
import time
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path
from emojis import COIN

DB = db_path("economy.db")


class Economy(commands.Cog, name="Economy"):
    """Coins, daily rewards, work, gambling and leaderboards."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("""CREATE TABLE IF NOT EXISTS eco (
                guild_id INTEGER, user_id INTEGER, wallet INTEGER DEFAULT 0, bank INTEGER DEFAULT 0,
                last_daily REAL DEFAULT 0, last_work REAL DEFAULT 0, last_crime REAL DEFAULT 0, last_rob REAL DEFAULT 0,
                PRIMARY KEY (guild_id, user_id))""")
            await db.commit()

    async def get(self, gid, uid):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO eco (guild_id, user_id) VALUES (?, ?)", (gid, uid))
            await db.commit()
            async with db.execute("SELECT wallet, bank, last_daily, last_work, last_crime, last_rob FROM eco WHERE guild_id=? AND user_id=?", (gid, uid)) as c:
                return await c.fetchone()

    async def add(self, gid, uid, wallet=0, bank=0, **stamps):
        await self.get(gid, uid)
        sets = ["wallet = wallet + ?", "bank = bank + ?"]
        vals = [wallet, bank]
        for k, v in stamps.items():
            sets.append(f"{k} = ?")
            vals.append(v)
        async with aiosqlite.connect(DB) as db:
            await db.execute(f"UPDATE eco SET {', '.join(sets)} WHERE guild_id=? AND user_id=?", (*vals, gid, uid))
            await db.commit()

    @staticmethod
    def left(ts, cd):
        r = ts + cd - time.time()
        return r if r > 0 else 0

    @commands.hybrid_command(name="balance", aliases=["bal", "wallet"], description="Check your balance")
    @commands.guild_only()
    async def balance(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        w, b, *_ = await self.get(ctx.guild.id, member.id)
        e = embed(f"{COIN} {member.display_name}'s Balance")
        e.add_field(name="Wallet", value=f"`{w:,}`")
        e.add_field(name="Bank", value=f"`{b:,}`")
        e.add_field(name="Net Worth", value=f"`{w + b:,}`")
        e.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="daily", description="Claim your daily coins")
    @commands.guild_only()
    async def daily(self, ctx):
        _, _, ld, *_ = await self.get(ctx.guild.id, ctx.author.id)
        r = self.left(ld, 86400)
        if r:
            return await ctx.send(embed=err(f"Come back in **{int(r // 3600)}h {int(r % 3600 // 60)}m**."))
        amt = random.randint(500, 1000)
        await self.add(ctx.guild.id, ctx.author.id, wallet=amt, last_daily=time.time())
        await ctx.send(embed=ok(f"You claimed **{amt:,}** {COIN} daily coins!"))

    @commands.hybrid_command(name="work", description="Work for coins (1h cooldown)")
    @commands.guild_only()
    async def work(self, ctx):
        _, _, _, lw, *_ = await self.get(ctx.guild.id, ctx.author.id)
        r = self.left(lw, 3600)
        if r:
            return await ctx.send(embed=err(f"You're tired. Rest **{int(r // 60)}m {int(r % 60)}s**."))
        amt = random.randint(100, 400)
        job = random.choice(["developer", "chef", "streamer", "driver", "designer", "barista"])
        await self.add(ctx.guild.id, ctx.author.id, wallet=amt, last_work=time.time())
        await ctx.send(embed=ok(f"You worked as a **{job}** and earned **{amt:,}** {COIN}"))

    @commands.hybrid_command(name="crime", description="Risky crime for big coins (2h cooldown)")
    @commands.guild_only()
    async def crime(self, ctx):
        w, _, _, _, lc, _ = await self.get(ctx.guild.id, ctx.author.id)
        r = self.left(lc, 7200)
        if r:
            return await ctx.send(embed=err(f"Lay low for **{int(r // 60)}m**."))
        if random.random() < 0.55:
            amt = random.randint(300, 900)
            await self.add(ctx.guild.id, ctx.author.id, wallet=amt, last_crime=time.time())
            return await ctx.send(embed=ok(f"Crime paid off! You got **{amt:,}** {COIN}"))
        fine = min(w, random.randint(100, 400))
        await self.add(ctx.guild.id, ctx.author.id, wallet=-fine, last_crime=time.time())
        await ctx.send(embed=err(f"You got caught and paid a fine of **{fine:,}** {COIN}"))

    @commands.hybrid_command(name="rob", description="Try to rob someone")
    @commands.guild_only()
    async def rob(self, ctx, member: discord.Member):
        if member.bot or member.id == ctx.author.id:
            return await ctx.send(embed=err("Invalid target."))
        w, _, _, _, _, lr = await self.get(ctx.guild.id, ctx.author.id)
        r = self.left(lr, 3600)
        if r:
            return await ctx.send(embed=err(f"Wait **{int(r // 60)}m**."))
        tw, *_ = await self.get(ctx.guild.id, member.id)
        if tw < 200:
            return await ctx.send(embed=err("Not worth robbing (they have < 200 in wallet)."))
        if random.random() < 0.4:
            amt = random.randint(int(tw * 0.1), int(tw * 0.4))
            await self.add(ctx.guild.id, member.id, wallet=-amt)
            await self.add(ctx.guild.id, ctx.author.id, wallet=amt, last_rob=time.time())
            return await ctx.send(embed=ok(f"You stole **{amt:,}** {COIN} from {member.mention}!"))
        fine = min(w, 150)
        await self.add(ctx.guild.id, ctx.author.id, wallet=-fine, last_rob=time.time())
        await ctx.send(embed=err(f"You got caught! Paid **{fine:,}** {COIN}"))

    @commands.hybrid_command(name="deposit", aliases=["dep"], description="Deposit coins (number or 'all')")
    @commands.guild_only()
    async def deposit(self, ctx, amount: str):
        w, *_ = await self.get(ctx.guild.id, ctx.author.id)
        amt = w if amount.lower() == "all" else int(amount) if amount.isdigit() else 0
        if amt <= 0 or amt > w:
            return await ctx.send(embed=err("Invalid amount."))
        await self.add(ctx.guild.id, ctx.author.id, wallet=-amt, bank=amt)
        await ctx.send(embed=ok(f"Deposited **{amt:,}** {COIN}"))

    @commands.hybrid_command(name="withdraw", aliases=["with"], description="Withdraw coins (number or 'all')")
    @commands.guild_only()
    async def withdraw(self, ctx, amount: str):
        _, b, *_ = await self.get(ctx.guild.id, ctx.author.id)
        amt = b if amount.lower() == "all" else int(amount) if amount.isdigit() else 0
        if amt <= 0 or amt > b:
            return await ctx.send(embed=err("Invalid amount."))
        await self.add(ctx.guild.id, ctx.author.id, wallet=amt, bank=-amt)
        await ctx.send(embed=ok(f"Withdrew **{amt:,}** {COIN}"))

    @commands.hybrid_command(name="pay", aliases=["give"], description="Give coins to someone")
    @commands.guild_only()
    async def pay(self, ctx, member: discord.Member, amount: int):
        w, *_ = await self.get(ctx.guild.id, ctx.author.id)
        if member.bot or member.id == ctx.author.id or amount <= 0 or amount > w:
            return await ctx.send(embed=err("Invalid target or amount."))
        await self.add(ctx.guild.id, ctx.author.id, wallet=-amount)
        await self.add(ctx.guild.id, member.id, wallet=amount)
        await ctx.send(embed=ok(f"Sent **{amount:,}** {COIN} to {member.mention}"))

    @commands.hybrid_command(name="bet", description="Coinflip bet (double or nothing)")
    @commands.guild_only()
    async def bet(self, ctx, amount: int):
        w, *_ = await self.get(ctx.guild.id, ctx.author.id)
        if amount <= 0 or amount > w:
            return await ctx.send(embed=err("Invalid amount."))
        if random.random() < 0.48:
            await self.add(ctx.guild.id, ctx.author.id, wallet=amount)
            return await ctx.send(embed=ok(f"You won **{amount:,}** {COIN}!"))
        await self.add(ctx.guild.id, ctx.author.id, wallet=-amount)
        await ctx.send(embed=err(f"You lost **{amount:,}** {COIN}"))

    @commands.hybrid_command(name="slots", description="Play the slot machine")
    @commands.guild_only()
    async def slots(self, ctx, amount: int):
        w, *_ = await self.get(ctx.guild.id, ctx.author.id)
        if amount <= 0 or amount > w:
            return await ctx.send(embed=err("Invalid amount."))
        sym = ["🍒", "🍋", "🍇", "🔔", "💎", "7️⃣"]
        r = [random.choice(sym) for _ in range(3)]
        if r[0] == r[1] == r[2]:
            mult = 10 if r[0] == "7️⃣" else 5
        elif len(set(r)) == 2:
            mult = 1.5
        else:
            mult = 0
        delta = int(amount * mult) - amount
        await self.add(ctx.guild.id, ctx.author.id, wallet=delta)
        txt = f"🎰 | {' '.join(r)} |\n" + (f"**Won {int(amount * mult):,}** {COIN}" if mult else f"**Lost {amount:,}** {COIN}")
        await ctx.send(embed=embed("Slots", txt, 0x2ECC71 if mult else 0xE74C3C))

    @commands.hybrid_command(name="richest", aliases=["ecolb", "baltop"], description="Richest members")
    @commands.guild_only()
    async def richest(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, wallet+bank AS t FROM eco WHERE guild_id=? ORDER BY t DESC LIMIT 10", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No data yet."))
        medals = ["🥇", "🥈", "🥉"]
        desc = "\n".join(f"{medals[i] if i < 3 else f'`{i + 1}.`'} <@{u}> — `{t:,}` {COIN}" for i, (u, t) in enumerate(rows))
        await ctx.send(embed=embed("💰 Richest Members", desc))


async def setup(bot):
    await bot.add_cog(Economy(bot))
