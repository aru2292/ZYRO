"""ZYRO Leveling. ZYRO DEVELOPMENT"""
import time
import random
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path

DB = db_path("levels.db")


def need(level: int) -> int:
    return 5 * level ** 2 + 50 * level + 100


class Leveling(commands.Cog, name="Leveling"):
    """XP, ranks, leaderboard and level roles."""

    def __init__(self, bot):
        self.bot = bot
        self.cool: dict[tuple, float] = {}
        self.enabled: dict[int, tuple] = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS xp (guild_id INTEGER, user_id INTEGER, xp INTEGER DEFAULT 0, level INTEGER DEFAULT 0, PRIMARY KEY (guild_id, user_id))")
            await db.execute("CREATE TABLE IF NOT EXISTS lvl_cfg (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 1, channel_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS lvl_roles (guild_id INTEGER, level INTEGER, role_id INTEGER, PRIMARY KEY (guild_id, level))")
            await db.commit()

    async def cfg(self, gid):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT enabled, channel_id FROM lvl_cfg WHERE guild_id=?", (gid,)) as c:
                r = await c.fetchone()
        return r or (1, None)

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if m.author.bot or not m.guild or not m.content:
            return
        key = (m.guild.id, m.author.id)
        if time.time() - self.cool.get(key, 0) < 45:
            return
        self.cool[key] = time.time()
        enabled, ch = await self.cfg(m.guild.id)
        if not enabled:
            return
        gain = random.randint(12, 24)
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO xp (guild_id, user_id) VALUES (?, ?)", key)
            await db.execute("UPDATE xp SET xp = xp + ? WHERE guild_id=? AND user_id=?", (gain, *key))
            async with db.execute("SELECT xp, level FROM xp WHERE guild_id=? AND user_id=?", key) as c:
                xp, lvl = await c.fetchone()
            leveled = False
            while xp >= need(lvl):
                xp -= need(lvl)
                lvl += 1
                leveled = True
            if leveled:
                await db.execute("UPDATE xp SET xp=?, level=? WHERE guild_id=? AND user_id=?", (xp, lvl, *key))
            await db.commit()
            role_id = None
            if leveled:
                async with db.execute("SELECT role_id FROM lvl_roles WHERE guild_id=? AND level<=? ORDER BY level DESC LIMIT 1", (m.guild.id, lvl)) as c:
                    r = await c.fetchone()
                    role_id = r[0] if r else None
        if leveled:
            target = m.guild.get_channel(ch) if ch else m.channel
            try:
                await (target or m.channel).send(f"🎉 {m.author.mention} reached **level {lvl}**!")
            except Exception:
                pass
            if role_id:
                role = m.guild.get_role(role_id)
                if role:
                    try:
                        await m.author.add_roles(role, reason="ZYRO level role")
                    except Exception:
                        pass

    @commands.hybrid_command(name="rank", aliases=["level", "lvl"], description="Show your level")
    @commands.guild_only()
    async def rank(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT xp, level FROM xp WHERE guild_id=? AND user_id=?", (ctx.guild.id, member.id)) as c:
                r = await c.fetchone()
            xp, lvl = r or (0, 0)
            async with db.execute("SELECT COUNT(*) FROM xp WHERE guild_id=? AND (level>? OR (level=? AND xp>?))", (ctx.guild.id, lvl, lvl, xp)) as c:
                pos = (await c.fetchone())[0] + 1
        n = need(lvl)
        bar = "█" * int(10 * xp / n) + "░" * (10 - int(10 * xp / n))
        e = embed(f"✦ {member.display_name}'s Rank")
        e.add_field(name="Level", value=str(lvl))
        e.add_field(name="Rank", value=f"#{pos}")
        e.add_field(name="XP", value=f"`{bar}` {xp}/{n}", inline=False)
        e.set_thumbnail(url=member.display_avatar.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="leaderboard", aliases=["lb", "top"], description="XP leaderboard")
    @commands.guild_only()
    async def leaderboard(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, level, xp FROM xp WHERE guild_id=? ORDER BY level DESC, xp DESC LIMIT 10", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No data yet — start chatting!"))
        medals = ["🥇", "🥈", "🥉"]
        desc = "\n".join(f"{medals[i] if i < 3 else f'`{i + 1}.`'} <@{u}> — Level **{l}** ({x} xp)" for i, (u, l, x) in enumerate(rows))
        await ctx.send(embed=embed("🏆 Leaderboard", desc))

    @commands.hybrid_command(name="levelrole", description="Give a role at a level: levelrole <level> <role>")
    @commands.has_permissions(manage_roles=True)
    @commands.guild_only()
    async def levelrole(self, ctx, level: int, role: discord.Role):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO lvl_roles VALUES (?, ?, ?)", (ctx.guild.id, level, role.id))
            await db.commit()
        await ctx.send(embed=ok(f"{role.mention} will be given at level **{level}**."))

    @commands.hybrid_command(name="levelchannel", description="Set level-up announcement channel")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def levelchannel(self, ctx, channel: discord.TextChannel):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT INTO lvl_cfg (guild_id, channel_id) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id", (ctx.guild.id, channel.id))
            await db.commit()
        await ctx.send(embed=ok(f"Level-ups will be announced in {channel.mention}"))

    @commands.hybrid_command(name="leveling", description="Enable/disable leveling: leveling on|off")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def leveling(self, ctx, state: str):
        on = 1 if state.lower() in ("on", "enable", "true") else 0
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT INTO lvl_cfg (guild_id, enabled) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled", (ctx.guild.id, on))
            await db.commit()
        await ctx.send(embed=ok(f"Leveling **{'enabled' if on else 'disabled'}**."))


async def setup(bot):
    await bot.add_cog(Leveling(bot))
