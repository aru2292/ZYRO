"""ZYRO+++ Antinuke — 2nd layer, premium only. Per-day whitelist LIMITS, instant punish, auto-revert.
ZYRO DEVELOPMENT"""
import time
import datetime
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, warn, db_path, risky_above
from cogs.anti_wl import is_trusted
import zpremium as zp

DB = db_path("pantinuke.db")
ROLE_NAME = "ZYRO+++ ./unbypassble"

ACTIONS = {
    "ban": "Ban members", "kick": "Kick members", "prune": "Prune members", "botadd": "Add bots",
    "chcr": "Create channels", "chdl": "Delete channels", "rlcr": "Create roles", "rldl": "Delete roles",
    "webhook": "Create webhooks", "everyone": "@everyone / @here", "serverup": "Update server",
}
AA = discord.AuditLogAction
AUDIT_MAP = {AA.ban: "ban", AA.kick: "kick", AA.member_prune: "prune", AA.bot_add: "botadd", AA.channel_create: "chcr",
             AA.channel_delete: "chdl", AA.role_create: "rlcr", AA.role_delete: "rldl", AA.webhook_create: "webhook", AA.guild_update: "serverup"}


def today() -> str:
    return datetime.datetime.utcnow().strftime("%Y-%m-%d")


class LimitModal(discord.ui.Modal):
    def __init__(self, view, action):
        super().__init__(title=f"Daily limit: {ACTIONS[action]}"[:45])
        self.view_, self.action = view, action
        self.box = discord.ui.TextInput(label="Per day (0 = blocked, -1 = unlimited)", placeholder="e.g. 2", max_length=5)
        self.add_item(self.box)

    async def on_submit(self, i: discord.Interaction):
        try:
            n = int(self.box.value.strip())
            assert -1 <= n <= 9999
        except Exception:
            return await i.response.send_message("Enter a number from -1 to 9999.", ephemeral=True)
        await self.view_.cog.set_limit(i.guild.id, self.view_.target.id, self.action, n)
        await self.view_.refresh(i)


class LimitView(discord.ui.View):
    def __init__(self, cog, ctx, target):
        super().__init__(timeout=300)
        self.cog, self.ctx, self.target = cog, ctx, target
        sel = discord.ui.Select(placeholder="Pick an action to set its daily limit",
                                options=[discord.SelectOption(label=n, value=k) for k, n in ACTIONS.items()])
        sel.callback = self.pick
        self.add_item(sel)

    async def interaction_check(self, i):
        if i.user.id != self.ctx.author.id:
            await i.response.send_message("Only the command user can use this.", ephemeral=True)
            return False
        return True

    async def pick(self, i: discord.Interaction):
        await i.response.send_modal(LimitModal(self, i.data["values"][0]))

    async def render(self):
        lims = await self.cog.limits(self.ctx.guild.id, self.target.id)
        used = await self.cog.usage(self.ctx.guild.id, self.target.id)
        lines = []
        for k, n in ACTIONS.items():
            v = lims.get(k, 0)
            txt = "⛔ blocked" if v == 0 else "♾️ unlimited" if v < 0 else f"✅ {used.get(k, 0)}/{v} today"
            lines.append(f"**{n}** — {txt}")
        return embed(f"🛡️ ZYRO+++ Limits — {self.target}", "\n".join(lines) + "\n\n*Beyond the limit = instant punishment.*")

    async def refresh(self, i):
        await i.response.edit_message(embed=await self.render(), view=self)

    @discord.ui.button(label="1/day all", style=discord.ButtonStyle.primary, row=1)
    async def one(self, i, b):
        for k in ACTIONS:
            await self.cog.set_limit(i.guild.id, self.target.id, k, 1)
        await self.refresh(i)

    @discord.ui.button(label="Unlimited all", style=discord.ButtonStyle.success, row=1)
    async def inf(self, i, b):
        for k in ACTIONS:
            await self.cog.set_limit(i.guild.id, self.target.id, k, -1)
        await self.refresh(i)

    @discord.ui.button(label="Block all", style=discord.ButtonStyle.danger, row=1)
    async def block(self, i, b):
        for k in ACTIONS:
            await self.cog.set_limit(i.guild.id, self.target.id, k, 0)
        await self.refresh(i)

    @discord.ui.button(label="Done", style=discord.ButtonStyle.secondary, row=1)
    async def done(self, i, b):
        await i.response.edit_message(view=None)
        self.stop()


class PAntinuke(commands.Cog, name="ZYRO+++ Antinuke"):
    """2nd-layer antinuke (premium)."""

    def __init__(self, bot):
        self.bot = bot
        self._act: dict = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS pcfg (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0, punish TEXT DEFAULT 'ban', log_channel INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS plimits (guild_id INTEGER, user_id INTEGER, action TEXT, lim INTEGER, PRIMARY KEY (guild_id, user_id, action))")
            await db.execute("CREATE TABLE IF NOT EXISTS pcount (guild_id INTEGER, user_id INTEGER, action TEXT, day TEXT, cnt INTEGER, PRIMARY KEY (guild_id, user_id, action, day))")
            await db.commit()

    # ---------- storage ----------
    async def cfg(self, gid):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT enabled, punish, log_channel FROM pcfg WHERE guild_id=?", (gid,)) as c:
                r = await c.fetchone()
        return dict(enabled=bool(r[0]), punish=r[1], log=r[2]) if r else dict(enabled=False, punish="ban", log=None)

    async def set_cfg(self, gid, **kw):
        await self.cfg(gid)
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO pcfg (guild_id) VALUES (?)", (gid,))
            for k, v in kw.items():
                await db.execute(f"UPDATE pcfg SET {k}=? WHERE guild_id=?", (v, gid))
            await db.commit()
        self._act.pop(gid, None)

    async def limits(self, gid, uid):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT action, lim FROM plimits WHERE guild_id=? AND user_id=?", (gid, uid)) as c:
                return {a: l for a, l in await c.fetchall()}

    async def set_limit(self, gid, uid, action, lim):
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO plimits VALUES (?, ?, ?, ?)", (gid, uid, action, lim))
            await db.commit()

    async def usage(self, gid, uid):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT action, cnt FROM pcount WHERE guild_id=? AND user_id=? AND day=?", (gid, uid, today())) as c:
                return {a: n for a, n in await c.fetchall()}

    async def is_extra_owner(self, gid, uid):
        try:
            async with aiosqlite.connect(db_path("anti.db")) as db:
                async with db.execute("SELECT 1 FROM extraowners WHERE guild_id=? AND owner_id=?", (gid, uid)) as c:
                    return await c.fetchone() is not None
        except Exception:
            return False

    async def active(self, gid) -> bool:
        c = self._act.get(gid)
        if c and time.time() - c[0] < 20:
            return c[1]
        v = (await self.cfg(gid))["enabled"] and await zp.guild_premium(gid)
        self._act[gid] = (time.time(), v)
        return v

    async def allowed(self, g: discord.Guild, uid: int, action: str) -> bool:
        if uid == g.owner_id or uid == self.bot.user.id or await self.is_extra_owner(g.id, uid):
            return True
        lim = (await self.limits(g.id, uid)).get(action, 0)
        if lim < 0:
            return True
        if lim == 0:
            return False
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO pcount VALUES (?, ?, ?, ?, 0)", (g.id, uid, action, today()))
            await db.execute("UPDATE pcount SET cnt=cnt+1 WHERE guild_id=? AND user_id=? AND action=? AND day=?", (g.id, uid, action, today()))
            async with db.execute("SELECT cnt FROM pcount WHERE guild_id=? AND user_id=? AND action=? AND day=?", (g.id, uid, action, today())) as c:
                n = (await c.fetchone())[0]
            await db.commit()
        return n <= lim

    # ---------- punishment / logging ----------
    async def punish(self, g: discord.Guild, uid: int, reason: str) -> str:
        mode = (await self.cfg(g.id))["punish"]
        m = g.get_member(uid)
        try:
            if mode == "kick" and m:
                await g.kick(m, reason=reason)
                return "kicked"
            if mode == "strip" and m:
                await m.edit(roles=[r for r in m.roles if r.is_default() or r.managed], reason=reason)
                return "stripped of all roles"
            await g.ban(discord.Object(uid), reason=reason, delete_message_days=0)
            return "banned"
        except discord.Forbidden:
            pass
        except Exception:
            pass
        try:
            if m:
                await m.edit(roles=[r for r in m.roles if r.is_default() or r.managed], reason=reason)
                return "stripped of roles (could not ban — my role is below theirs!)"
        except Exception:
            pass
        return "NOT punished (my role is below theirs — drag my role to the top!)"

    async def log(self, g: discord.Guild, title: str, desc: str):
        e = embed(title, desc, 0xE74C3C)
        ch = g.get_channel((await self.cfg(g.id))["log"] or 0)
        try:
            if ch:
                await ch.send(embed=e)
            elif g.owner:
                await g.owner.send(embed=e)
        except Exception:
            pass

    async def revert(self, g: discord.Guild, entry, key):
        try:
            t = entry.target
            tid = getattr(t, "id", None)
            b = entry.before
            if key == "ban" and tid:
                await g.unban(discord.Object(tid), reason="ZYRO+++ revert")
            elif key == "chcr" and tid and g.get_channel(tid):
                await g.get_channel(tid).delete(reason="ZYRO+++ revert")
            elif key == "chdl":
                name = getattr(b, "name", None) or "restored-channel"
                typ = getattr(b, "type", None)
                if typ == discord.ChannelType.voice:
                    await g.create_voice_channel(name, reason="ZYRO+++ recovery")
                elif typ == discord.ChannelType.category:
                    await g.create_category(name, reason="ZYRO+++ recovery")
                else:
                    await g.create_text_channel(name, topic=getattr(b, "topic", None), nsfw=bool(getattr(b, "nsfw", False)), reason="ZYRO+++ recovery")
            elif key == "rlcr" and tid and g.get_role(tid):
                await g.get_role(tid).delete(reason="ZYRO+++ revert")
            elif key == "rldl":
                await g.create_role(name=getattr(b, "name", None) or "restored-role", colour=getattr(b, "colour", None) or discord.Colour.default(),
                                    permissions=getattr(b, "permissions", None) or discord.Permissions.none(),
                                    hoist=bool(getattr(b, "hoist", False)), mentionable=bool(getattr(b, "mentionable", False)), reason="ZYRO+++ recovery")
            elif key == "botadd" and tid:
                await g.kick(discord.Object(tid), reason="ZYRO+++ revert")
            elif key == "webhook" and tid:
                wh = await self.bot.fetch_webhook(tid)
                await wh.delete(reason="ZYRO+++ revert")
        except Exception:
            pass

    # ---------- detection (real-time audit log events) ----------
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        key = AUDIT_MAP.get(entry.action)
        g = entry.guild
        uid = entry.user_id
        if not key or not uid or uid == self.bot.user.id or not await self.active(g.id):
            return
        if key == "serverup":     # only act on dangerous guild edits, not every tiny change
            names = {a for a in ("name", "vanity_url_code", "icon", "verification_level", "owner")}
            if not any(hasattr(entry.after, n) for n in names):
                return
        if await self.allowed(g, uid, key):
            return
        res = await self.punish(g, uid, f"ZYRO+++ {ACTIONS[key]} not allowed")
        await self.revert(g, entry, key)
        await self.log(g, "🚨 ZYRO+++ Antinuke", f"<@{uid}> tried **{ACTIONS[key]}** beyond their daily limit.\n**Result:** {res}\nChange reverted where possible.")

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if not m.guild or m.author.bot or not m.mention_everyone or not await self.active(m.guild.id):
            return
        if await self.allowed(m.guild, m.author.id, "everyone"):
            return
        try:
            await m.delete()
        except Exception:
            pass
        res = await self.punish(m.guild, m.author.id, "ZYRO+++ @everyone/@here not allowed")
        await self.log(m.guild, "🚨 ZYRO+++ Antinuke", f"{m.author.mention} used **@everyone/@here** beyond their daily limit.\n**Result:** {res}")

    # ---------- commands ----------
    async def gate(self, ctx, need_premium=True) -> bool:
        if need_premium and not await zp.guild_premium(ctx.guild.id):
            await ctx.send(embed=err("**ZYRO+++** needs premium. Get it from the bot owner, then run `&premium activate` here."))
            return False
        if not await is_trusted(ctx):
            await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can use this."))
            return False
        return True

    @commands.group(name="pantinuke", aliases=["antinuke+", "zyro+++antinuke", "pan"], invoke_without_command=True)
    @commands.guild_only()
    async def pantinuke(self, ctx):
        c = await self.cfg(ctx.guild.id)
        gp = await zp.guild_premium(ctx.guild.id)
        p = ctx.prefix
        logtxt = "<#%s>" % c["log"] if c["log"] else "owner DM"
        await ctx.send(embed=embed("🛡️ ZYRO+++ Antinuke (2nd layer)", (
            f"**Premium:** {'🟢 active' if gp else '🔴 not active'}   **Status:** {'🟢 ON' if c['enabled'] else '🔴 OFF'}\n"
            f"**Punishment:** `{c['punish']}`   **Logs:** {logtxt}\n\n"
            "Layer 1 (`antinuke`) stops anyone not whitelisted.\n"
            "Layer 2 (this) limits **everyone** per day — even whitelisted people — so a hacked/rogue trusted admin can't nuke.\n\n"
            f"`{p}pantinuke enable` / `disable`\n`{p}pwl @user` — set daily limits\n`{p}pwl list` • `{p}pwl remove @user` • `{p}pwl reset`\n"
            f"`{p}pantinuke punish ban|kick|strip`\n`{p}pantinuke logs #channel`\n`{p}pantinuke usage @user`")))

    @pantinuke.command(name="enable", aliases=["on", "setup"])
    async def p_enable(self, ctx):
        if not await self.gate(ctx):
            return
        risky = risky_above(ctx.guild)
        if risky:
            return await ctx.send(embed=embed("❌ Setup blocked", (
                f"These roles are **above my role**, so I could not punish them: {', '.join(r.mention for r in risky[:8])}\n\n"
                f"**Fix:** Server Settings → Roles → drag **{ctx.guild.me.top_role.name}** to the very **TOP**, then run `{ctx.prefix}pantinuke enable` again."), 0xE74C3C))
        role = discord.utils.get(ctx.guild.roles, name=ROLE_NAME)
        try:
            if not role:
                role = await ctx.guild.create_role(name=ROLE_NAME, permissions=discord.Permissions(administrator=True), reason="ZYRO+++ antinuke")
            await role.edit(position=max(1, ctx.guild.me.top_role.position - 1))
            await ctx.guild.me.add_roles(role)
        except Exception:
            pass
        await self.set_cfg(ctx.guild.id, enabled=1)
        await ctx.send(embed=ok(f"**ZYRO+++ Antinuke enabled** — role **{ROLE_NAME}** active.\n"
                                f"⚠️ From now on only the **owner / extra owners** and users you add with `{ctx.prefix}pwl @user` can ban, kick, prune, add bots, create/delete channels & roles, create webhooks or ping @everyone. Everyone else is punished instantly."))

    @pantinuke.command(name="disable", aliases=["off"])
    async def p_disable(self, ctx):
        if not await self.gate(ctx, need_premium=False):
            return
        await self.set_cfg(ctx.guild.id, enabled=0)
        await ctx.send(embed=ok("ZYRO+++ Antinuke disabled."))

    @pantinuke.command(name="punish")
    async def p_punish(self, ctx, mode: str):
        if not await self.gate(ctx):
            return
        if mode.lower() not in ("ban", "kick", "strip"):
            return await ctx.send(embed=err("Use `ban`, `kick` or `strip`."))
        await self.set_cfg(ctx.guild.id, punish=mode.lower())
        await ctx.send(embed=ok(f"Punishment: **{mode.lower()}**"))

    @pantinuke.command(name="logs")
    async def p_logs(self, ctx, channel: discord.TextChannel):
        if not await self.gate(ctx):
            return
        await self.set_cfg(ctx.guild.id, log_channel=channel.id)
        await ctx.send(embed=ok(f"Alerts → {channel.mention}"))

    @pantinuke.command(name="usage")
    async def p_usage(self, ctx, member: discord.Member):
        if not await self.gate(ctx):
            return
        v = LimitView(self, ctx, member)
        await ctx.send(embed=await v.render())

    @commands.group(name="pwl", aliases=["premiumwhitelist", "pwhitelist"], invoke_without_command=True)
    @commands.guild_only()
    async def pwl(self, ctx, member: discord.Member = None):
        if not await self.gate(ctx):
            return
        if not member:
            return await ctx.send(embed=embed("🛡️ ZYRO+++ Whitelist", f"`{ctx.prefix}pwl @user` — set daily limits (ban/kick/prune/everyone…)\n`{ctx.prefix}pwl list` • `{ctx.prefix}pwl remove @user` • `{ctx.prefix}pwl reset`\n`{ctx.prefix}pwl set @user ban 2`"))
        v = LimitView(self, ctx, member)
        await ctx.send(embed=await v.render(), view=v)

    @pwl.command(name="set")
    async def pwl_set(self, ctx, member: discord.Member, action: str, limit: int):
        if not await self.gate(ctx):
            return
        action = action.lower()
        if action not in ACTIONS:
            return await ctx.send(embed=err("Actions: " + ", ".join(f"`{a}`" for a in ACTIONS)))
        await self.set_limit(ctx.guild.id, member.id, action, max(-1, min(limit, 9999)))
        await ctx.send(embed=ok(f"{member.mention}: **{ACTIONS[action]}** = `{limit}`/day"))

    @pwl.command(name="list")
    async def pwl_list(self, ctx):
        if not await self.gate(ctx):
            return
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, action, lim FROM plimits WHERE guild_id=? AND lim != 0 ORDER BY user_id", (ctx.guild.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("Nobody is in the premium whitelist."))
        by: dict = {}
        for u, a, l in rows:
            by.setdefault(u, []).append(f"{a}={'∞' if l < 0 else l}")
        await ctx.send(embed=embed("🛡️ ZYRO+++ Whitelist", "\n".join(f"<@{u}> — {', '.join(v)}" for u, v in list(by.items())[:30])))

    @pwl.command(name="remove")
    async def pwl_remove(self, ctx, member: discord.Member):
        if not await self.gate(ctx):
            return
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM plimits WHERE guild_id=? AND user_id=?", (ctx.guild.id, member.id))
            await db.commit()
        await ctx.send(embed=ok(f"{member.mention} removed from the premium whitelist."))

    @pwl.command(name="reset")
    async def pwl_reset(self, ctx):
        if not await self.gate(ctx):
            return
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM plimits WHERE guild_id=?", (ctx.guild.id,))
            await db.commit()
        await ctx.send(embed=ok("Premium whitelist cleared."))


async def setup(bot):
    await bot.add_cog(PAntinuke(bot))
