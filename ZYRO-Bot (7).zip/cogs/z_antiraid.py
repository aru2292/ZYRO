"""ZYRO Anti-Raid, Account-age gate & Captcha verification. ZYRO DEVELOPMENT"""
import time
import random
import asyncio
import datetime
from collections import deque

import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path
from cogs.anti_wl import is_trusted

DB = db_path("antiraid.db")


class CaptchaModal(discord.ui.Modal):
    def __init__(self, role: discord.Role, a: int, b: int):
        super().__init__(title="ZYRO Verification")
        self.role, self.answer = role, a + b
        self.box = discord.ui.TextInput(label=f"What is {a} + {b} ?", min_length=1, max_length=3, required=True)
        self.add_item(self.box)

    async def on_submit(self, i: discord.Interaction):
        if self.box.value.strip() != str(self.answer):
            return await i.response.send_message("❌ Wrong answer, press the button and try again.", ephemeral=True)
        try:
            await i.user.add_roles(self.role, reason="ZYRO verification")
            await i.response.send_message("✅ You are verified! Welcome.", ephemeral=True)
        except Exception:
            await i.response.send_message("❌ I can't give that role (my role must be above it).", ephemeral=True)


class VerifyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Verify", emoji="✅", style=discord.ButtonStyle.success, custom_id="zyro_verify")
    async def verify(self, i: discord.Interaction, b: discord.ui.Button):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT role_id FROM verify WHERE guild_id=?", (i.guild.id,)) as c:
                r = await c.fetchone()
        role = i.guild.get_role(r[0]) if r else None
        if not role:
            return await i.response.send_message("Verification is not configured.", ephemeral=True)
        if role in i.user.roles:
            return await i.response.send_message("You are already verified.", ephemeral=True)
        await i.response.send_modal(CaptchaModal(role, random.randint(1, 9), random.randint(1, 9)))


class AntiRaid(commands.Cog, name="AntiRaid"):
    """Raid protection, minimum account age and captcha verification."""

    def __init__(self, bot):
        self.bot = bot
        self.joins: dict[int, deque] = {}
        self.raid_until: dict[int, float] = {}
        self.cfg: dict[int, dict] = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("""CREATE TABLE IF NOT EXISTS raid (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0,
                joins INTEGER DEFAULT 6, seconds INTEGER DEFAULT 10, action TEXT DEFAULT 'kick', min_age INTEGER DEFAULT 0)""")
            await db.execute("CREATE TABLE IF NOT EXISTS verify (guild_id INTEGER PRIMARY KEY, role_id INTEGER)")
            await db.commit()
            async with db.execute("SELECT guild_id, enabled, joins, seconds, action, min_age FROM raid") as c:
                for g, en, j, s, a, m in await c.fetchall():
                    self.cfg[g] = dict(enabled=en, joins=j, seconds=s, action=a, min_age=m)
        self.bot.add_view(VerifyView())

    async def save(self, gid):
        c = self.cfg[gid]
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO raid VALUES (?, ?, ?, ?, ?, ?)", (gid, c["enabled"], c["joins"], c["seconds"], c["action"], c["min_age"]))
            await db.commit()

    def get(self, gid):
        return self.cfg.setdefault(gid, dict(enabled=0, joins=6, seconds=10, action="kick", min_age=0))

    # ---------- commands ----------
    @commands.group(name="antiraid", invoke_without_command=True)
    @commands.guild_only()
    async def antiraid(self, ctx):
        c = self.get(ctx.guild.id)
        p = ctx.prefix
        await ctx.send(embed=embed("🚨 Anti-Raid", (
            f"**Status:** {'🟢 ON' if c['enabled'] else '🔴 OFF'}\n"
            f"**Trigger:** {c['joins']} joins in {c['seconds']}s → **{c['action']}**\n"
            f"**Min account age:** {c['min_age']} day(s)\n\n"
            f"`{p}antiraid on|off`\n`{p}antiraid set <joins> <seconds>`\n`{p}antiraid action <kick|ban|timeout>`\n`{p}antiraid minage <days>`")))

    async def _guard(self, ctx):
        if not await is_trusted(ctx):
            await ctx.send(embed=err("Only the Server Owner or an Extra Owner can change this."))
            return False
        return True

    @antiraid.command(name="on")
    async def ar_on(self, ctx):
        if not await self._guard(ctx):
            return
        self.get(ctx.guild.id)["enabled"] = 1
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok("Anti-raid **enabled**."))

    @antiraid.command(name="off")
    async def ar_off(self, ctx):
        if not await self._guard(ctx):
            return
        self.get(ctx.guild.id)["enabled"] = 0
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok("Anti-raid **disabled**."))

    @antiraid.command(name="set")
    async def ar_set(self, ctx, joins: int, seconds: int):
        if not await self._guard(ctx):
            return
        c = self.get(ctx.guild.id)
        c["joins"], c["seconds"] = max(2, min(joins, 100)), max(3, min(seconds, 120))
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Trigger: **{c['joins']}** joins in **{c['seconds']}s**."))

    @antiraid.command(name="action")
    async def ar_action(self, ctx, action: str):
        if not await self._guard(ctx):
            return
        if action.lower() not in ("kick", "ban", "timeout"):
            return await ctx.send(embed=err("Use kick, ban or timeout."))
        self.get(ctx.guild.id)["action"] = action.lower()
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Raid action: **{action.lower()}**"))

    @antiraid.command(name="minage")
    async def ar_minage(self, ctx, days: int):
        if not await self._guard(ctx):
            return
        self.get(ctx.guild.id)["min_age"] = max(0, min(days, 365))
        await self.save(ctx.guild.id)
        await ctx.send(embed=ok(f"Accounts younger than **{days}** day(s) will be kicked (0 = off)."))

    @commands.hybrid_command(name="verifysetup", description="Create a captcha verification panel in this channel")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def verifysetup(self, ctx, role: discord.Role):
        if role >= ctx.guild.me.top_role or role.managed:
            return await ctx.send(embed=err("I can't assign that role (it must be below my role)."))
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO verify VALUES (?, ?)", (ctx.guild.id, role.id))
            await db.commit()
        await ctx.channel.send(embed=embed("✅ Verification", f"Press the button below and solve the captcha to get {role.mention} and access the server."), view=VerifyView())
        if ctx.interaction:
            await ctx.send(embed=ok("Panel created."), ephemeral=True)

    # ---------- detection ----------
    async def punish(self, m: discord.Member, action: str, reason: str):
        try:
            if action == "ban":
                await m.ban(reason=reason, delete_message_days=0)
            elif action == "timeout":
                await m.timeout(datetime.timedelta(hours=1), reason=reason)
            else:
                await m.kick(reason=reason)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, m: discord.Member):
        c = self.cfg.get(m.guild.id)
        if not c:
            return
        # account-age gate
        if c["min_age"] and not m.bot:
            age = (discord.utils.utcnow() - m.created_at).days
            if age < c["min_age"]:
                try:
                    await m.send(f"Your account is too new to join **{m.guild.name}** (needs {c['min_age']}+ days).")
                except Exception:
                    pass
                return await self.punish(m, "kick", "ZYRO: account too new")
        if not c["enabled"]:
            return
        now = time.time()
        q = self.joins.setdefault(m.guild.id, deque())
        q.append((now, m))
        while q and now - q[0][0] > c["seconds"]:
            q.popleft()
        in_raid = self.raid_until.get(m.guild.id, 0) > now
        if len(q) >= c["joins"] or in_raid:
            if not in_raid:
                self.raid_until[m.guild.id] = now + 120
                ch = m.guild.system_channel
                if ch:
                    try:
                        await ch.send(embed=embed("🚨 RAID DETECTED", f"**{len(q)}** joins in {c['seconds']}s. Punishing raiders (**{c['action']}**) for the next 2 minutes.", 0xE74C3C))
                    except Exception:
                        pass
                victims = [x[1] for x in q]
            else:
                victims = [m]
            for v in victims:
                if v.id != m.guild.owner_id:
                    await self.punish(v, c["action"], "ZYRO anti-raid")
            q.clear()


async def setup(bot):
    await bot.add_cog(AntiRaid(bot))
