"""ZYRO Premium — grant / activate / per-server bot profile / noprefix. ZYRO DEVELOPMENT"""
import time
import base64
import datetime
import aiohttp
import aiosqlite
import discord
from discord.ext import commands, tasks
from discord.http import Route

import zpremium as zp
from config import PREMIUM_DB, CORE_DB, SUPPORT_LINK
from zutil import embed, ok, err, warn
from cogs.anti_wl import is_trusted
from cogs import z_team

FEATURES = (
    "🛡️ **ZYRO+++ Antinuke** — 2nd unbypassable layer with per-day whitelist limits\n"
    "🤖 **ZYRO+++ AutoMod** — strict rules with per-day allowances\n"
    "🎨 **Custom bot avatar / banner / bio** in your server\n"
    "⚡ **No-Prefix** — use every command without a prefix (everywhere)\n"
    "♻️ **Auto-recovery** of deleted channels / roles"
)
NOPREFIX_FOREVER = "2099-12-31T00:00:00"


def ts(expires: int) -> str:
    return "**Never (Lifetime)**" if expires == 0 else f"<t:{int(expires)}:F> (<t:{int(expires)}:R>)"


class PremiumView(discord.ui.View):
    def __init__(self, cog, author_id):
        super().__init__(timeout=180)
        self.cog, self.author_id = cog, author_id

    async def interaction_check(self, i):
        if i.user.id != self.author_id:
            await i.response.send_message("Run `&premium` yourself to use these buttons.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Activate Here", emoji="✨", style=discord.ButtonStyle.success)
    async def act(self, i: discord.Interaction, b):
        if not i.guild:
            return await i.response.send_message("Use this in a server.", ephemeral=True)
        res = await self.cog.activate(i.guild, i.user)
        await i.response.send_message(embed=res, ephemeral=True)

    @discord.ui.button(label="Deactivate Here", emoji="🛑", style=discord.ButtonStyle.danger)
    async def deact(self, i: discord.Interaction, b):
        if not i.guild:
            return await i.response.send_message("Use this in a server.", ephemeral=True)
        await i.response.send_message(embed=await self.cog.deactivate(i.guild, i.user), ephemeral=True)

    @discord.ui.button(label="My Servers", emoji="📋", style=discord.ButtonStyle.primary)
    async def servers(self, i: discord.Interaction, b):
        await i.response.send_message(embed=await self.cog.servers_embed(i.user.id), ephemeral=True)

    @discord.ui.button(label="Plans", emoji="💎", style=discord.ButtonStyle.secondary)
    async def plans(self, i: discord.Interaction, b):
        await i.response.send_message(embed=self.cog.plans_embed(), ephemeral=True)


class Premium(commands.Cog, name="Premium"):
    """ZYRO+++ premium system."""

    def __init__(self, bot):
        self.bot = bot
        self.expiry_loop.start()

    def cog_unload(self):
        self.expiry_loop.cancel()

    async def cog_load(self):
        await zp.ensure()

    # ---------- embeds ----------
    def plans_embed(self):
        e = embed("💎 ZYRO+++ Plans", "Premium is given by the bot owner. Contact support to get one.\n\n"
                  "`Trial` 1 day • 1 server\n`Weekly` 7 days • 1 server\n`Monthly` 30 days • 1 server\n"
                  "`3 Months` • 2 servers\n`6 Months` • 2 servers\n`Yearly` • 3 servers\n`Lifetime` • 5 servers\n\n" + FEATURES)
        return e

    async def servers_embed(self, uid):
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT guild_id FROM guild_premium WHERE user_id=?", (uid,)) as c:
                rows = await c.fetchall()
        g = await zp.user_grant(uid)
        names = [f"• **{self.bot.get_guild(r[0]).name if self.bot.get_guild(r[0]) else r[0]}** (`{r[0]}`)" for r in rows]
        slots = g["slots"] if g else 0
        return embed("📋 Your premium servers", (f"Slots used: **{len(rows)}/{slots}**\n" + "\n".join(names)) if rows else "No servers activated yet.")

    # ---------- core ops ----------
    async def activate(self, guild: discord.Guild, user) -> discord.Embed:
        g = await zp.user_grant(user.id)
        if not g:
            return err("You don't have premium. Ask the bot owner for access (see `&premium plans`).")
        member = guild.get_member(user.id)
        trusted = user.id == guild.owner_id or (member and member.guild_permissions.administrator)
        if not trusted:
            return err("You need **Administrator** (or be the owner) in this server to activate premium.")
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT user_id FROM guild_premium WHERE guild_id=?", (guild.id,)) as c:
                cur = await c.fetchone()
            if cur:
                return warn("This server already has premium active.")
            async with db.execute("SELECT COUNT(*) FROM guild_premium WHERE user_id=?", (user.id,)) as c:
                used = (await c.fetchone())[0]
            if used >= g["slots"]:
                return err(f"All your server slots are used (**{used}/{g['slots']}**). Use `&premium deactivate` in another server first.")
            await db.execute("INSERT INTO guild_premium VALUES (?, ?, ?)", (guild.id, user.id, int(time.time())))
            await db.commit()
        zp.clear_cache()
        return ok(f"**ZYRO+++ activated** in **{guild.name}** 🎉\nValid until: {ts(g['expires'])}\n\n"
                  f"Next: `&pantinuke enable` • `&pautomod enable` • `&botavatar` • `&botbanner`")

    async def deactivate(self, guild: discord.Guild, user) -> discord.Embed:
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT user_id FROM guild_premium WHERE guild_id=?", (guild.id,)) as c:
                row = await c.fetchone()
            if not row:
                return warn("This server has no premium.")
            if user.id != row[0] and user.id != guild.owner_id and not await self.bot.is_owner(user):
                return err("Only the activator or the server owner can deactivate.")
            await db.execute("DELETE FROM guild_premium WHERE guild_id=?", (guild.id,))
            await db.commit()
        zp.clear_cache()
        await self.reset_profile(guild)
        return ok("Premium deactivated for this server (slot freed).")

    async def reset_profile(self, guild):
        try:
            await self.bot.http.request(Route("PATCH", "/guilds/{guild_id}/members/@me", guild_id=guild.id),
                                        json={"avatar": None, "banner": None, "bio": None})
        except Exception:
            pass

    # ---------- commands ----------
    @commands.group(name="premium", aliases=["prem", "zyro+++"], invoke_without_command=True)
    async def premium(self, ctx):
        g = await zp.user_grant(ctx.author.id)
        gp = await zp.guild_premium(ctx.guild.id) if ctx.guild else False
        e = embed("💎 ZYRO+++ Premium")
        if g:
            e.description = f"✅ **You have premium** — {g['plan']}\nExpires: {ts(g['expires'])}\nServer slots: **{g['slots']}**"
            e.color = 0x2ECC71
        else:
            e.description = "❌ You don't have premium.\n\n" + FEATURES
            e.color = 0xE74C3C
        if ctx.guild:
            e.add_field(name="This server", value="🟢 Premium **active**" if gp else "🔴 Not premium")
        e.add_field(name="Commands", value="`premium activate` • `premium deactivate` • `premium servers` • `premium plans`", inline=False)
        await ctx.send(embed=e, view=PremiumView(self, ctx.author.id))

    @premium.command(name="plans")
    async def p_plans(self, ctx):
        await ctx.send(embed=self.plans_embed())

    @premium.command(name="activate")
    @commands.guild_only()
    async def p_activate(self, ctx):
        await ctx.send(embed=await self.activate(ctx.guild, ctx.author))

    @premium.command(name="deactivate")
    @commands.guild_only()
    async def p_deactivate(self, ctx):
        await ctx.send(embed=await self.deactivate(ctx.guild, ctx.author))

    @premium.command(name="servers")
    async def p_servers(self, ctx):
        await ctx.send(embed=await self.servers_embed(ctx.author.id))

    # ----- bot owner -----
    @premium.command(name="grant", aliases=["give", "add"])
    @commands.check(z_team.can_grant)
    async def p_grant(self, ctx, user: discord.User, *, duration: str):
        days = zp.parse_duration(duration)
        if days is None:
            return await ctx.send(embed=err("Duration examples: `7d` `1month` `3month` `6month` `1year` `lifetime`"))
        plan, slots = zp.plan_info(days)
        lim = await z_team.grant_limit(ctx.author.id)
        if lim is not None:
            await zp.ensure()
            async with aiosqlite.connect(PREMIUM_DB) as db:
                async with db.execute("SELECT COUNT(*) FROM grants WHERE granted_by=?", (ctx.author.id,)) as c:
                    used = (await c.fetchone())[0]
                async with db.execute("SELECT 1 FROM grants WHERE user_id=? AND granted_by=?", (user.id, ctx.author.id)) as c:
                    own = await c.fetchone()
            if used >= lim and not own:
                return await ctx.send(embed=err(f"Your premium quota is full (**{used}/{lim}**)."))
        now = int(time.time())
        await zp.ensure()
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT expires FROM grants WHERE user_id=?", (user.id,)) as c:
                old = await c.fetchone()
            if days == 0:
                exp = 0
            else:
                base = old[0] if old and old[0] and old[0] > now else now      # stack on top of running premium
                exp = base + days * 86400
            await db.execute("INSERT OR REPLACE INTO grants VALUES (?, ?, ?, ?, ?, ?, ?, 0)", (user.id, plan, days, slots, exp, ctx.author.id, now))
            await db.commit()
        # no-prefix for premium users
        nexp = NOPREFIX_FOREVER if exp == 0 else datetime.datetime.utcfromtimestamp(exp).isoformat()
        async with aiosqlite.connect(CORE_DB) as db:
            await db.execute("INSERT OR REPLACE INTO noprefix (user_id, plan, added_by, added_at, expires) VALUES (?, ?, ?, ?, ?)",
                             (user.id, "Premium", ctx.author.id, datetime.datetime.utcnow().isoformat(), nexp))
            await db.commit()
        zp.clear_cache()
        dm = embed("💎 You received ZYRO+++ Premium!", f"**Plan:** {plan}\n**Expires:** {ts(exp)}\n**Server slots:** {slots}\n**Given by:** {ctx.author}\n\n"
                   f"**Included**\n{FEATURES}\n\n**How to start**\n1️⃣ Go to your server\n2️⃣ Type `&premium activate`\n3️⃣ Then `&pantinuke enable`, `&pautomod enable`, `&botavatar`…\n\n"
                   f"No-Prefix is already enabled for you — just type `help`, `play` etc. without a prefix.", 0x9B59B6)
        try:
            await user.send(embed=dm)
            dm_status = "📩 DM sent."
        except Exception:
            dm_status = "⚠️ Couldn't DM (their DMs are closed)."
        await ctx.send(embed=ok(f"Premium **{plan}** given to {user.mention} • expires {ts(exp)} • slots {slots}\n{dm_status}"))

    @premium.command(name="revoke", aliases=["remove"])
    @commands.check(z_team.can_grant)
    async def p_revoke(self, ctx, user: discord.User):
        if await z_team.level(ctx.author.id) < 2:
            async with aiosqlite.connect(PREMIUM_DB) as db:
                async with db.execute("SELECT granted_by FROM grants WHERE user_id=?", (user.id,)) as c:
                    r = await c.fetchone()
            if not r or r[0] != ctx.author.id:
                return await ctx.send(embed=err("You can only revoke premium that you gave yourself."))
        await self._remove_user(user.id)
        await ctx.send(embed=ok(f"Premium removed from {user.mention}."))

    @premium.command(name="list")
    @commands.check(z_team.admin_check)
    async def p_list(self, ctx):
        await zp.ensure()
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT user_id, plan, expires FROM grants ORDER BY expires") as c:
                rows = await c.fetchall()
        if not rows:
            return await ctx.send(embed=err("No premium users."))
        await ctx.send(embed=embed(f"💎 Premium users ({len(rows)})", "\n".join(f"<@{u}> — {p} — {'∞' if x == 0 else f'<t:{x}:R>'}" for u, p, x in rows[:40])))

    @premium.command(name="check")
    @commands.check(z_team.admin_check)
    async def p_check(self, ctx, user: discord.User):
        g = await zp.user_grant(user.id)
        await ctx.send(embed=ok(f"{user.mention}: {g['plan']} • {ts(g['expires'])}") if g else err("No active premium."))

    async def _remove_user(self, uid):
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT guild_id FROM guild_premium WHERE user_id=?", (uid,)) as c:
                gids = [r[0] for r in await c.fetchall()]
            await db.execute("DELETE FROM guild_premium WHERE user_id=?", (uid,))
            await db.execute("DELETE FROM grants WHERE user_id=?", (uid,))
            await db.commit()
        async with aiosqlite.connect(CORE_DB) as db:
            await db.execute("DELETE FROM noprefix WHERE user_id=? AND plan='Premium'", (uid,))
            await db.commit()
        zp.clear_cache()
        for gid in gids:
            g = self.bot.get_guild(gid)
            if g:
                await self.reset_profile(g)

    @tasks.loop(minutes=5)
    async def expiry_loop(self):
        await zp.ensure()
        now = int(time.time())
        async with aiosqlite.connect(PREMIUM_DB) as db:
            async with db.execute("SELECT user_id FROM grants WHERE expires != 0 AND expires <= ?", (now,)) as c:
                expired = [r[0] for r in await c.fetchall()]
            async with db.execute("SELECT user_id, expires FROM grants WHERE expires != 0 AND expires > ? AND expires <= ? AND reminded=0", (now, now + 86400)) as c:
                soon = await c.fetchall()
            for uid, _ in soon:
                await db.execute("UPDATE grants SET reminded=1 WHERE user_id=?", (uid,))
            await db.commit()
        for uid, exp in soon:
            u = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
            try:
                await u.send(embed=warn(f"Your ZYRO+++ premium expires {ts(exp)}. Contact the owner to renew."))
            except Exception:
                pass
        for uid in expired:
            await self._remove_user(uid)
            try:
                u = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await u.send(embed=warn("Your **ZYRO+++ premium has expired.** Premium features were turned off in your servers."))
            except Exception:
                pass

    @expiry_loop.before_loop
    async def _w(self):
        await self.bot.wait_until_ready()

    # ---------- per-server bot profile (premium) ----------
    async def _profile_gate(self, ctx):
        if not ctx.guild:
            await ctx.send(embed=err("Use this in a server."))
            return False
        if not await zp.guild_premium(ctx.guild.id):
            await ctx.send(embed=err("This server doesn't have **ZYRO+++ premium**. Use `&premium activate`."))
            return False
        if not await is_trusted(ctx):
            await ctx.send(embed=err("Only the **Server Owner** or an **Extra Owner** can change my profile here."))
            return False
        return True

    async def _read_image(self, ctx, url):
        url = url or (ctx.message.attachments[0].url if ctx.message.attachments else None)
        if not url:
            await ctx.send(embed=err("Attach an image or give an image URL."))
            return None
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(url, timeout=aiohttp.ClientTimeout(total=15)) as r:
                    data = await r.read()
        except Exception:
            await ctx.send(embed=err("Couldn't download that image."))
            return None
        if len(data) > 8 * 1024 * 1024:
            await ctx.send(embed=err("Image too big (max 8 MB)."))
            return None
        mime = "image/png" if data[:4] == b"\x89PNG" else "image/jpeg" if data[:2] == b"\xff\xd8" else "image/gif" if data[:3] == b"GIF" else "image/webp" if data[8:12] == b"WEBP" else None
        if not mime:
            await ctx.send(embed=err("Unsupported image (use PNG, JPG, GIF or WEBP)."))
            return None
        return f"data:{mime};base64,{base64.b64encode(data).decode()}"

    async def _patch(self, ctx, payload, done_msg):
        try:
            await self.bot.http.request(Route("PATCH", "/guilds/{guild_id}/members/@me", guild_id=ctx.guild.id), json=payload,
                                        reason=f"ZYRO profile by {ctx.author}")
            await ctx.send(embed=ok(done_msg))
        except discord.HTTPException as e:
            await ctx.send(embed=err(f"Discord rejected it: `{e.text[:180]}`"))

    @commands.command(name="botavatar", aliases=["setavatar", "serveravatar"])
    @commands.guild_only()
    async def botavatar(self, ctx, url: str = None):
        if not await self._profile_gate(ctx):
            return
        img = await self._read_image(ctx, url)
        if img:
            await self._patch(ctx, {"avatar": img}, "ZYRO's avatar changed **in this server only**.")

    @commands.command(name="botbanner", aliases=["setbanner", "serverbanner"])
    @commands.guild_only()
    async def botbanner(self, ctx, url: str = None):
        if not await self._profile_gate(ctx):
            return
        img = await self._read_image(ctx, url)
        if img:
            await self._patch(ctx, {"banner": img}, "ZYRO's banner changed **in this server only**.")

    @commands.command(name="botbio", aliases=["setbio"])
    @commands.guild_only()
    async def botbio(self, ctx, *, text: str):
        if not await self._profile_gate(ctx):
            return
        await self._patch(ctx, {"bio": text[:190]}, "ZYRO's bio changed in this server.")

    @commands.command(name="botprofilereset", aliases=["resetprofile"])
    @commands.guild_only()
    async def botprofilereset(self, ctx):
        if not await self._profile_gate(ctx):
            return
        await self._patch(ctx, {"avatar": None, "banner": None, "bio": None}, "Profile reset to default.")


async def setup(bot):
    await bot.add_cog(Premium(bot))
