"""ZYRO info commands: serverinfo / userinfo. ZYRO DEVELOPMENT"""
import discord
from discord.ext import commands
from zutil import embed


class Info(commands.Cog, name="InfoCmds"):
    """Server and user information."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="serverinfo", aliases=["si", "guildinfo", "server"], description="Information about this server")
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        humans = sum(1 for m in g.members if not m.bot)
        e = embed(g.name, g.description or None)
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>")
        e.add_field(name="ID", value=f"`{g.id}`")
        e.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:R>")
        e.add_field(name="Members", value=f"{g.member_count} ({humans} humans, {g.member_count - humans} bots)")
        e.add_field(name="Channels", value=f"{len(g.text_channels)} text • {len(g.voice_channels)} voice • {len(g.categories)} categories")
        e.add_field(name="Roles", value=str(len(g.roles)))
        e.add_field(name="Boosts", value=f"Level {g.premium_tier} • {g.premium_subscription_count or 0} boosts")
        e.add_field(name="Emojis", value=str(len(g.emojis)))
        e.add_field(name="Verification", value=str(g.verification_level).title())
        if g.banner:
            e.set_image(url=g.banner.url)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="userinfo", aliases=["ui", "whois", "profile", "uinfo"], description="Information about a member")
    @commands.guild_only()
    async def userinfo(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = embed(f"{m.display_name}", color=m.color.value or 0x7B2FFF)
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="User", value=f"{m.mention}\n`{m}`")
        e.add_field(name="ID", value=f"`{m.id}`")
        e.add_field(name="Bot", value="Yes" if m.bot else "No")
        e.add_field(name="Created", value=f"<t:{int(m.created_at.timestamp())}:R>")
        if m.joined_at:
            e.add_field(name="Joined", value=f"<t:{int(m.joined_at.timestamp())}:R>")
        if m.premium_since:
            e.add_field(name="Boosting since", value=f"<t:{int(m.premium_since.timestamp())}:R>")
        roles = [r.mention for r in reversed(m.roles) if not r.is_default()]
        e.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:12]) + (" …" if len(roles) > 12 else "") or "None", inline=False)
        e.add_field(name="Top role", value=m.top_role.mention)
        await ctx.send(embed=e, allowed_mentions=discord.AllowedMentions.none())


async def setup(bot):
    await bot.add_cog(Info(bot))
