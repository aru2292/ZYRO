"""ZYRO Tickets. ZYRO DEVELOPMENT"""
import io
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, ok, err, db_path

DB = db_path("tickets.db")


class OpenView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create Ticket", emoji="🎫", style=discord.ButtonStyle.primary, custom_id="zyro_ticket_open")
    async def open(self, interaction: discord.Interaction, button: discord.ui.Button):
        g = interaction.guild
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT category_id, support_role_id FROM tcfg WHERE guild_id=?", (g.id,)) as c:
                cfg = await c.fetchone()
            async with db.execute("SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=? AND open=1", (g.id, interaction.user.id)) as c:
                existing = await c.fetchone()
        if not cfg:
            return await interaction.response.send_message("Tickets not configured.", ephemeral=True)
        if existing and g.get_channel(existing[0]):
            return await interaction.response.send_message(f"You already have a ticket: <#{existing[0]}>", ephemeral=True)
        cat = g.get_channel(cfg[0])
        role = g.get_role(cfg[1]) if cfg[1] else None
        ow = {
            g.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True, read_message_history=True),
            g.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }
        if role:
            ow[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        name = f"ticket-{interaction.user.name}"[:90]
        ch = await g.create_text_channel(name, category=cat, overwrites=ow, topic=f"Ticket of {interaction.user} ({interaction.user.id})")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO tickets VALUES (?, ?, ?, 1)", (ch.id, g.id, interaction.user.id))
            await db.commit()
        await ch.send(
            content=f"{interaction.user.mention}" + (f" {role.mention}" if role else ""),
            embed=embed("🎫 Ticket", "Support will be with you shortly.\nDescribe your issue below."),
            view=CloseView(),
        )
        await interaction.response.send_message(f"Ticket created: {ch.mention}", ephemeral=True)


class CloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="zyro_ticket_close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        ch = interaction.channel
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id FROM tickets WHERE channel_id=?", (ch.id,)) as c:
                row = await c.fetchone()
            async with db.execute("SELECT support_role_id, log_channel_id FROM tcfg WHERE guild_id=?", (interaction.guild.id,)) as c:
                cfg = await c.fetchone()
        if not row:
            return await interaction.response.send_message("Not a ticket.", ephemeral=True)
        role = interaction.guild.get_role(cfg[0]) if cfg and cfg[0] else None
        if interaction.user.id != row[0] and not interaction.user.guild_permissions.manage_channels and not (role and role in interaction.user.roles):
            return await interaction.response.send_message("Only staff or the ticket owner can close this.", ephemeral=True)
        await interaction.response.send_message("🔒 Closing ticket in 5 seconds...")
        lines = []
        async for m in ch.history(limit=1000, oldest_first=True):
            lines.append(f"[{m.created_at:%Y-%m-%d %H:%M}] {m.author}: {m.clean_content}")
        transcript = discord.File(io.BytesIO("\n".join(lines).encode()), filename=f"{ch.name}-transcript.txt")
        log = interaction.guild.get_channel(cfg[1]) if cfg and cfg[1] else None
        if log:
            try:
                await log.send(embed=embed("🎫 Ticket closed", f"{ch.name} closed by {interaction.user.mention}"), file=transcript)
            except Exception:
                pass
        async with aiosqlite.connect(DB) as db:
            await db.execute("UPDATE tickets SET open=0 WHERE channel_id=?", (ch.id,))
            await db.commit()
        import asyncio
        await asyncio.sleep(5)
        try:
            await ch.delete(reason="Ticket closed")
        except Exception:
            pass


class Tickets(commands.Cog, name="Tickets"):
    """Support ticket system with transcripts."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS tcfg (guild_id INTEGER PRIMARY KEY, category_id INTEGER, support_role_id INTEGER, log_channel_id INTEGER)")
            await db.execute("CREATE TABLE IF NOT EXISTS tickets (channel_id INTEGER PRIMARY KEY, guild_id INTEGER, user_id INTEGER, open INTEGER)")
            await db.commit()
        self.bot.add_view(OpenView())
        self.bot.add_view(CloseView())

    @commands.hybrid_command(name="ticketsetup", description="Setup tickets: panel channel, support role, optional log channel")
    @commands.has_permissions(administrator=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.guild_only()
    async def ticketsetup(self, ctx, panel_channel: discord.TextChannel, support_role: discord.Role, log_channel: discord.TextChannel = None):
        cat = await ctx.guild.create_category("🎫 Tickets", overwrites={ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False), ctx.guild.me: discord.PermissionOverwrite(view_channel=True)})
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO tcfg VALUES (?, ?, ?, ?)", (ctx.guild.id, cat.id, support_role.id, log_channel.id if log_channel else None))
            await db.commit()
        await panel_channel.send(embed=embed("🎫 Support Tickets", "Need help? Click the button below to open a private ticket with our staff."), view=OpenView())
        await ctx.send(embed=ok(f"Ticket panel sent to {panel_channel.mention}"))

    @commands.hybrid_command(name="ticketadd", description="Add a member to this ticket")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def ticketadd(self, ctx, member: discord.Member):
        await ctx.channel.set_permissions(member, view_channel=True, send_messages=True, read_message_history=True)
        await ctx.send(embed=ok(f"Added {member.mention}"))

    @commands.hybrid_command(name="ticketremove", description="Remove a member from this ticket")
    @commands.has_permissions(manage_channels=True)
    @commands.guild_only()
    async def ticketremove(self, ctx, member: discord.Member):
        await ctx.channel.set_permissions(member, overwrite=None)
        await ctx.send(embed=ok(f"Removed {member.mention}"))


async def setup(bot):
    await bot.add_cog(Tickets(bot))
