"""ZYRO AI chat (optional). Set ANTHROPIC_API_KEY  or  AI_API_KEY + AI_API_URL (OpenAI-compatible). ZYRO DEVELOPMENT"""
import os
import aiohttp
import aiosqlite
import discord
from discord.ext import commands
from zutil import embed, err, ok, db_path

DB = db_path("ai.db")
SYSTEM = "You are ZYRO, a friendly Discord bot made by ARIAN. Answer briefly (under 1500 characters), no @mentions."


async def ask_ai(question: str) -> str | None:
    key = os.getenv("ANTHROPIC_API_KEY")
    try:
        async with aiohttp.ClientSession() as s:
            if key:
                async with s.post("https://api.anthropic.com/v1/messages",
                                  headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                                  json={"model": os.getenv("AI_MODEL", "claude-haiku-4-5"), "max_tokens": 700, "system": SYSTEM,
                                        "messages": [{"role": "user", "content": question[:3000]}]},
                                  timeout=aiohttp.ClientTimeout(total=40)) as r:
                    d = await r.json()
                    return "".join(b.get("text", "") for b in d.get("content", []))[:1900] or None
            if os.getenv("AI_API_KEY"):
                url = os.getenv("AI_API_URL", "https://api.openai.com/v1/chat/completions")
                async with s.post(url, headers={"Authorization": f"Bearer {os.getenv('AI_API_KEY')}"},
                                  json={"model": os.getenv("AI_MODEL", "gpt-4o-mini"), "max_tokens": 700,
                                        "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": question[:3000]}]},
                                  timeout=aiohttp.ClientTimeout(total=40)) as r:
                    d = await r.json()
                    return d["choices"][0]["message"]["content"][:1900]
    except Exception:
        return None
    return None


class AI(commands.Cog, name="AI"):
    """Ask questions / auto-reply channel."""

    def __init__(self, bot):
        self.bot = bot
        self.channels: dict = {}

    async def cog_load(self):
        async with aiosqlite.connect(DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS ai_ch (guild_id INTEGER PRIMARY KEY, channel_id INTEGER)")
            await db.commit()
            async with db.execute("SELECT guild_id, channel_id FROM ai_ch") as c:
                self.channels = {g: ch for g, ch in await c.fetchall()}

    @commands.hybrid_command(name="ask", aliases=["ai", "chat"], description="Ask ZYRO AI a question")
    @commands.cooldown(1, 8, commands.BucketType.user)
    async def ask(self, ctx, *, question: str):
        if not (os.getenv("ANTHROPIC_API_KEY") or os.getenv("AI_API_KEY")):
            return await ctx.send(embed=err("AI is not configured (owner: set `ANTHROPIC_API_KEY` or `AI_API_KEY` in variables)."))
        await ctx.defer()
        ans = await ask_ai(question)
        await ctx.send(ans or "😵 AI is unavailable right now.", allowed_mentions=discord.AllowedMentions.none())

    @commands.hybrid_command(name="aichannel", description="Set a channel where ZYRO answers every message")
    @commands.has_permissions(manage_guild=True)
    @commands.guild_only()
    async def aichannel(self, ctx, channel: discord.TextChannel = None):
        async with aiosqlite.connect(DB) as db:
            if channel:
                await db.execute("INSERT OR REPLACE INTO ai_ch VALUES (?, ?)", (ctx.guild.id, channel.id))
                self.channels[ctx.guild.id] = channel.id
            else:
                await db.execute("DELETE FROM ai_ch WHERE guild_id=?", (ctx.guild.id,))
                self.channels.pop(ctx.guild.id, None)
            await db.commit()
        await ctx.send(embed=ok(f"AI channel: {channel.mention}" if channel else "AI channel removed."))

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if m.author.bot or not m.guild or self.channels.get(m.guild.id) != m.channel.id or not m.content:
            return
        ctx = await self.bot.get_context(m)
        if ctx.valid:
            return
        async with m.channel.typing():
            ans = await ask_ai(m.content)
        if ans:
            await m.reply(ans, mention_author=False, allowed_mentions=discord.AllowedMentions.none())


async def setup(bot):
    await bot.add_cog(AI(bot))
