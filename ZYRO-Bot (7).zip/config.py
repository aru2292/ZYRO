"""ZYRO central config. Everything secret/ID-like comes from environment variables."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BOT_NAME = "ZYRO"
CREDIT = "ZYRO DEVELOPMENT"
FOOTER = CREDIT
EMBED_COLOR = 0x7B2FFF

TOKEN = os.getenv("TOKEN")

def _ids(raw):
    out = []
    for p in (raw or "").replace(" ", "").split(","):
        if p.isdigit():
            out.append(int(p))
    return out

# OWNER_IDS = comma separated Discord user IDs (set in Railway variables)
BUILTIN_DEVELOPERS = [499671679803457551]
OWNER_IDS = list(dict.fromkeys(_ids(os.getenv("OWNER_IDS") or os.getenv("OWNER_ID")) + BUILTIN_DEVELOPERS))
OWNER_ID = OWNER_IDS[0] if OWNER_IDS else 0
DEV_ID = OWNER_ID
DEVELOPER_IDS = OWNER_IDS

DEFAULT_PREFIX = os.getenv("PREFIX", "&")

# Optional log channels (0 = disabled)
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)

# Data dir (on Railway mount a Volume at /data and set DATA_DIR=/data to keep DBs after redeploy)
_auto = "/data" if (os.path.isdir("/data") and os.access("/data", os.W_OK)) else "db"
DATA_DIR = Path(os.getenv("DATA_DIR") or _auto)      # Railway: mount a Volume at /data and it is used automatically
os.environ["DATA_DIR"] = str(DATA_DIR)               # other modules read this
DATA_DIR.mkdir(parents=True, exist_ok=True)

CORE_DB = DATA_DIR / "core.db"
PREMIUM_DB = DATA_DIR / "premium.db"
TRACKER_DB = DATA_DIR / "tracker.db"

SUPPORT_LINK = os.getenv("SUPPORT_LINK", "https://discord.gg/PeA5ReBEY")
INVITE_LINK = os.getenv("INVITE_LINK", "https://discord.com/oauth2/authorize?client_id=1534633106894749786&permissions=8&scope=bot%20applications.commands")
VOTE_LINK = os.getenv("VOTE_LINK", SUPPORT_LINK)
SUPPORT_SERVER = SUPPORT_LINK
