# ZYRO emoji list (168 names)

1. Upload each emoji (Developer Portal -> your bot -> Emojis) using the *upload name* in column 2.
2. Put `<:name:ID>` (animated: `<a:name:ID>`) in `custom_emojis.json` under the CONSTANT in column 1.
3. Leave a value empty to keep the unicode emoji.

Every unicode emoji in messages, embeds, buttons and menus is replaced automatically.
Same unicode on two rows (e.g. BOOST/ROCKET) = the first one you fill wins, so you can reuse one image.

| CONSTANT | upload name | current | note |
|---|---|---|---|
| CHECK | zyro_check | ✅ |  |
| VERIFIED_CHECK | zyro_verified_check | ☑️ |  |
| CROSS | zyro_cross | ❌ |  |
| CROSS_MARK | zyro_cross_mark | ✖️ |  |
| TICK | zyro_tick | ✔️ |  |
| ZTICK | zyro_ztick | ✔️ |  |
| ERROR_X | zyro_error_x | ⛔ |  |
| LOCK | zyro_lock | 🔒 |  |
| UNLOCK | zyro_unlock | 🔓 |  |
| GHOST | zyro_ghost | 👻 |  |
| UNGHOST | zyro_unghost | 🫥 |  |
| BOOST | zyro_boost | 🚀 |  |
| INFO | zyro_info | ⚠️ |  |
| CART | zyro_cart | 🛒 |  |
| SUPPORT | zyro_support | 🛟 |  |
| DELETE | zyro_delete | 🗑️ |  |
| LOADING | zyro_loading | ⏳ |  |
| STATS | zyro_stats | 📊 |  |
| UPTIME | zyro_uptime | 🕰️ |  |
| DATABASE | zyro_database | 🗄️ |  |
| VERIFIED_DEV | zyro_verified_dev | 🛠️ |  |
| OS_SYSTEM | zyro_os_system | 🖥️ |  |
| CPU | zyro_cpu | ⚙️ |  |
| RAM | zyro_ram | 🧠 |  |
| STORAGE | zyro_storage | 💾 |  |
| CROWN | zyro_crown | 👑 |  |
| GEARS | zyro_gears | ⚙️ |  |
| LINK | zyro_link | 🔗 |  |
| CREDITS | zyro_credits | 💳 |  |
| TIMER | zyro_timer | ⏱️ |  |
| REPLY | zyro_reply | ↳ | symbol (only where code uses it) |
| REPLY_2 | zyro_reply_2 | ╰┈➤ | symbol (only where code uses it) |
| BELL | zyro_bell | 🔔 |  |
| VIP | zyro_vip | 💎 |  |
| FRIEND | zyro_friend | 🤝 |  |
| VERIFIED | zyro_verified | 🛡️ |  |
| ENABLED | zyro_enabled | 🟢 |  |
| DISABLED | zyro_disabled | 🔴 |  |
| DISABLED_OFF | zyro_disabled_off | ⚫ |  |
| STAR | zyro_star | ✦ | symbol (only where code uses it) |
| DIAMOND | zyro_diamond | ❖ | symbol (only where code uses it) |
| ARROW | zyro_arrow | ➤ | symbol (only where code uses it) |
| SPARK | zyro_spark | ✧ | symbol (only where code uses it) |
| FLOWER | zyro_flower | ❀ | symbol (only where code uses it) |
| DOT | zyro_dot | • | symbol (only where code uses it) |
| MUSIC | zyro_music | 🎵 |  |
| NOTE | zyro_note | ♪ | symbol (only where code uses it) |
| PLAY | zyro_play | ▶️ |  |
| PAUSE | zyro_pause | ⏸️ |  |
| STOP | zyro_stop | ⏹️ |  |
| SKIP | zyro_skip | ⏭️ |  |
| SHUFFLE | zyro_shuffle | 🔀 |  |
| LOOP | zyro_loop | 🔁 |  |
| VOLUME | zyro_volume | 🔊 |  |
| COIN | zyro_coin | 🪙 |  |
| GEM | zyro_gem | 💠 |  |
| FIRE | zyro_fire | 🔥 |  |
| SHIELD | zyro_shield | 🛡️ |  |
| SWORD | zyro_sword | ⚔️ |  |
| BAN | zyro_ban | 🔨 |  |
| PARTY | zyro_party | 🎉 |  |
| HEART | zyro_heart | 💜 |  |
| SPARKLES | zyro_sparkles | ✨ |  |
| ROCKET | zyro_rocket | 🚀 |  |
| BOLT | zyro_bolt | ⚡ |  |
| TARGET | zyro_target | 🎯 |  |
| TICKET | zyro_ticket | 🎫 |  |
| GIFT | zyro_gift | 🎁 |  |
| MAIL | zyro_mail | 📩 |  |
| PIN | zyro_pin | 📌 |  |
| ROBOT | zyro_robot | 🤖 |  |
| STAR_YELLOW | zyro_star_yellow | ⭐ |  |
| SIREN | zyro_siren | 🚨 |  |
| MEMBERS | zyro_members | 👥 |  |
| ROLE_TAG | zyro_role_tag | 🏷️ |  |
| BIRTHDAY | zyro_birthday | 🎂 |  |
| MODMAIL | zyro_modmail | 📨 |  |
| NOTE_PAD | zyro_note_pad | 📝 |  |
| SEARCH | zyro_search | 🔎 |  |
| GOLD | zyro_gold | 🥇 |  |
| SILVER | zyro_silver | 🥈 |  |
| BRONZE | zyro_bronze | 🥉 |  |
| FOLDER | zyro_folder | 📁 |  |
| OPEN_FOLDER | zyro_open_folder | 📂 |  |
| MIC | zyro_mic | 🎙️ |  |
| HEADPHONES | zyro_headphones | 🎧 |  |
| GAMEPAD | zyro_gamepad | 🎮 |  |
| BULB | zyro_bulb | 💡 |  |
| THUMBS_UP | zyro_thumbs_up | 👍 |  |
| THUMBS_DOWN | zyro_thumbs_down | 👎 |  |
| PLUS | zyro_plus | ➕ |  |
| MINUS | zyro_minus | ➖ |  |
| RECYCLE | zyro_recycle | ♻️ |  |
| USER | zyro_user | 👤 |  |
| TOOLBOX | zyro_toolbox | 🧰 |  |
| CHAT | zyro_chat | 💬 |  |
| SMILE | zyro_smile | 😀 |  |
| CLIPBOARD | zyro_clipboard | 📋 |  |
| WRENCH | zyro_wrench | 🔧 |  |
| REFRESH | zyro_refresh | 🔄 |  |
| RADIO_KNOB | zyro_radio_knob | 🔘 |  |
| NUMBERS | zyro_numbers | 🔢 |  |
| SHUSH | zyro_shush | 🤫 |  |
| MAGNIFIER | zyro_magnifier | 🔍 |  |
| SLOT_CHERRY | zyro_slot_cherry | 🍒 |  |
| SLOT_LEMON | zyro_slot_lemon | 🍋 |  |
| SLOT_GRAPE | zyro_slot_grape | 🍇 |  |
| SLOT_MACHINE | zyro_slot_machine | 🎰 |  |
| MONEY_BAG | zyro_money_bag | 💰 |  |
| DIZZY | zyro_dizzy | 😵 |  |
| HAND_UP | zyro_hand_up | 🙋 |  |
| MASKS | zyro_masks | 🎭 |  |
| PENCIL | zyro_pencil | ✏️ |  |
| INBOX | zyro_inbox | 📥 |  |
| OUTBOX | zyro_outbox | 📤 |  |
| INFINITY | zyro_infinity | ♾️ |  |
| INFO_I | zyro_info_i | ℹ️ |  |
| LOCK_KEY | zyro_lock_key | 🔐 |  |
| CHART_UP | zyro_chart_up | 📈 |  |
| CONSTRUCTION | zyro_construction | 🏗️ |  |
| RECEIPT | zyro_receipt | 🧾 |  |
| PICTURE | zyro_picture | 🖼️ |  |
| WAVE | zyro_wave | 👋 |  |
| THOUGHT | zyro_thought | 💭 |  |
| PREV | zyro_prev | ◀️ |  |
| HOME | zyro_home | 🏠 |  |
| BOOK | zyro_book | 📖 |  |
| TROPHY | zyro_trophy | 🏆 |  |
| BOOT | zyro_boot | 👢 |  |
| BOOM | zyro_boom | 💥 |  |
| EIGHT_BALL | zyro_eight_ball | 🎱 |  |
| DICE | zyro_dice | 🎲 |  |
| ROCK | zyro_rock | 🪨 |  |
| PAPER | zyro_paper | 📄 |  |
| SCISSORS | zyro_scissors | ✂️ |  |
| COOL | zyro_cool | 😎 |  |
| THINKING | zyro_thinking | 🤔 |  |
| LOVE | zyro_love | 💞 |  |
| LAUGH | zyro_laugh | 😂 |  |
| MONOCLE | zyro_monocle | 🧐 |  |
| DEVIL | zyro_devil | 😈 |  |
| SHRUG | zyro_shrug | 🤷 |  |
| OPTION_A | zyro_option_a | 🅰️ |  |
| OPTION_B | zyro_option_b | 🅱️ |  |
| PALETTE | zyro_palette | 🎨 |  |
| STOP_SIGN | zyro_stop_sign | 🛑 |  |
| ABACUS | zyro_abacus | 🧮 |  |
| CLOCK | zyro_clock | 🕒 |  |
| WEATHER | zyro_weather | 🌤️ |  |
| QR_CODE | zyro_qr_code | 🔳 |  |
| YELLOW_DOT | zyro_yellow_dot | 🟡 |  |
| ORANGE_DOT | zyro_orange_dot | 🟠 |  |
| NAME_BADGE | zyro_name_badge | 📛 |  |
| EMPTY_MAILBOX | zyro_empty_mailbox | 📭 |  |
| QUESTION | zyro_question | ❓ |  |
| NUM_1 | zyro_num_1 | 1️⃣ |  |
| NUM_2 | zyro_num_2 | 2️⃣ |  |
| NUM_3 | zyro_num_3 | 3️⃣ |  |
| NUM_4 | zyro_num_4 | 4️⃣ |  |
| NUM_5 | zyro_num_5 | 5️⃣ |  |
| NUM_6 | zyro_num_6 | 6️⃣ |  |
| NUM_7 | zyro_num_7 | 7️⃣ |  |
| NUM_8 | zyro_num_8 | 8️⃣ |  |
| NUM_9 | zyro_num_9 | 9️⃣ |  |
| NUM_10 | zyro_num_10 | 🔟 |  |
| ARROW_RIGHT | zyro_arrow_right | → | symbol (only where code uses it) |
| ARROW_LONG | zyro_arrow_long | ➜ | symbol (only where code uses it) |
| BAR | zyro_bar | ▬ | symbol (only where code uses it) |
