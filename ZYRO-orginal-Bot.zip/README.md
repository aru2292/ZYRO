# ✦ ZYRO — All-in-one Discord Bot
**Development by ARIAN**

Antinuke • Automod • Music • VoiceMaster • Voice tools • Moderation+ • Tickets • Logs • Economy • Leveling • Fun • Welcome • Giveaways • Autorole • Starboard • and more.

## Deploy on Railway (Docker)
1. Upload this folder's files to a GitHub repo (the `Dockerfile` must be in the repo root).
2. Railway → New Project → Deploy from GitHub repo.
3. Variables tab:
   - `TOKEN` = bot token
   - `OWNER_IDS` = your Discord user ID (comma separated for more)
   - `DATA_DIR` = `/data`  (and add a **Volume** mounted at `/data`, so settings survive redeploys)
4. Discord Developer Portal → Bot → turn ON **Server Members Intent**, **Message Content Intent** (and Presence is not needed).
5. Invite with Administrator permission. Done — type `+help`.

## Music notes
YouTube often blocks datacenter IPs. If songs fail: export YouTube `cookies.txt` (from a throwaway account) and paste its whole content into the `YT_COOKIES` variable. ZYRO also falls back to SoundCloud search automatically.

## Local run
```
pip install -r requirements.txt
cp .env.example .env   # fill it
python main.py
```
Never commit your real `.env` / token.
