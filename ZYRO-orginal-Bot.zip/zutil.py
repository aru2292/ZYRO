"""Shared helpers for ZYRO cogs. Development by ARIAN"""
import os
import discord
from config import DATA_DIR, EMBED_COLOR, FOOTER


def db_path(name: str) -> str:
    return str(DATA_DIR / name)


def embed(title: str = None, desc: str = None, color: int = EMBED_COLOR, footer: bool = True) -> discord.Embed:
    e = discord.Embed(title=title, description=desc, color=color)
    if footer:
        e.set_footer(text=FOOTER)
    return e


def ok(text: str) -> discord.Embed:
    return embed(None, f"✅ {text}", 0x2ECC71)


def err(text: str) -> discord.Embed:
    return embed(None, f"❌ {text}", 0xE74C3C)


def warn(text: str) -> discord.Embed:
    return embed(None, f"⚠️ {text}", 0xF1C40F)


def fmt_dur(seconds) -> str:
    try:
        seconds = int(seconds or 0)
    except Exception:
        return "LIVE"
    if seconds <= 0:
        return "LIVE"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def progress_bar(pos: int, total: int, size: int = 14) -> str:
    if not total:
        return "▬" * size
    i = min(size - 1, int(size * pos / total))
    return "▬" * i + "🔘" + "▬" * (size - i - 1)


def can_act(ctx, target: discord.Member) -> str | None:
    """Return an error string if ctx.author / bot can't act on target (role hierarchy)."""
    if target.id == ctx.author.id:
        return "You can't do that to yourself."
    if target.id == ctx.guild.owner_id:
        return "You can't do that to the server owner."
    if ctx.author.id != ctx.guild.owner_id and target.top_role >= ctx.author.top_role:
        return "That member's top role is higher or equal to yours."
    if target.top_role >= ctx.guild.me.top_role:
        return "That member's top role is higher or equal to mine."
    return None
