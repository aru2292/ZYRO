"""
ZYRO — All-in-one Discord bot (Antinuke • Music • VoiceMaster • Moderation • Fun • Economy ...)
Development by ARIAN
"""
import os
import sys
import shutil
import asyncio
import logging
import traceback
from pathlib import Path

import discord
from discord.ext import commands
import aiosqlite

from config import (
    TOKEN, OWNER_ID, OWNER_IDS, DEV_ID, DEVELOPER_IDS, DEFAULT_PREFIX,
    DATA_DIR, CORE_DB, PREMIUM_DB, TRACKER_DB,
    SUPPORT_LINK, INVITE_LINK, VOTE_LINK, SUPPORT_SERVER, BOT_NAME, CREDIT,
)
import emojis
from emojis import EMOJIES, CHECK, CROSS, INFO

if not TOKEN:
    raise RuntimeError("TOKEN missing! Set TOKEN in Railway Variables (or a local .env file).")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

COGS_DIR = Path("cogs")
EVENTS_DIR = Path("events")
AUTOMOD_DIR = Path("automod")
ANTINUKE_DIR = Path("antinuke")
BOOSTS_REQUIRED = 0      # everything is free in ZYRO
LOCKED_COGS = ()         # no premium lock

# =========================
# BOT SETUP
# =========================
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.voice_states = True
intents.members = True
intents.reactions = True
intents.moderation = True
intents.invites = True
intents.webhooks = True
intents.emojis_and_stickers = True
intents.presences = False


async def get_prefix(bot, message):
    base = [DEFAULT_PREFIX]
    if not message or not message.guild:
        return commands.when_mentioned_or(*base)(bot, message)
    try:
        async with aiosqlite.connect(CORE_DB) as db:
            async with db.execute("SELECT prefix FROM prefixes WHERE guild_id = ?", (message.guild.id,)) as cur:
                row = await cur.fetchone()
        if row:
            base = [row[0]]
    except Exception:
        pass
    return commands.when_mentioned_or(*base)(bot, message)


bot = commands.Bot(
    command_prefix=get_prefix,
    owner_ids=set(OWNER_IDS) or None,
    intents=intents,
    help_command=None,
    case_insensitive=True,
    strip_after_prefix=True,
)
bot.support_link = SUPPORT_LINK
bot.invite_link = INVITE_LINK
bot.vote_link = VOTE_LINK
bot.credit = CREDIT


# =========================
# DB INITIALIZER
# =========================
def seed_databases():
    """Copy empty template DBs (./db/*.db) into DATA_DIR on first run (needed when DATA_DIR is a Railway volume)."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tpl = Path("db")
    if tpl.exists() and tpl.resolve() != DATA_DIR.resolve():
        for f in tpl.glob("*.db"):
            dst = DATA_DIR / f.name
            if not dst.exists():
                shutil.copy(f, dst)


async def init_databases():
    seed_databases()
    async with aiosqlite.connect(CORE_DB) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS prefixes (guild_id INTEGER PRIMARY KEY, prefix TEXT)")
        await db.execute("CREATE TABLE IF NOT EXISTS devreact (user_id INTEGER, role TEXT, PRIMARY KEY (user_id, role))")
        await db.execute("CREATE TABLE IF NOT EXISTS noprefix (user_id INTEGER PRIMARY KEY, plan TEXT, added_by INTEGER, added_at TEXT, expires TEXT)")
        await db.commit()
    async with aiosqlite.connect(PREMIUM_DB) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS premium_users (user_id INTEGER PRIMARY KEY, plan TEXT, expires INTEGER, boosts INTEGER)")
        await db.execute("CREATE TABLE IF NOT EXISTS user_boosts (user_id INTEGER, guild_id INTEGER, amount INTEGER, PRIMARY KEY (user_id, guild_id))")
        await db.execute("CREATE TABLE IF NOT EXISTS guild_boosts (guild_id INTEGER PRIMARY KEY, total_boosts INTEGER)")
        await db.commit()
    async with aiosqlite.connect(TRACKER_DB) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS messages (guild_id INTEGER, user_id INTEGER, message_count INTEGER DEFAULT 0, daily_count INTEGER DEFAULT 0, PRIMARY KEY (guild_id, user_id))")
        await db.execute("CREATE TABLE IF NOT EXISTS blacklisted_channels (guild_id INTEGER, channel_id INTEGER, PRIMARY KEY (guild_id, channel_id))")
        await db.commit()


# =========================
# STATUS LOOP
# =========================
async def update_status():
    await bot.wait_until_ready()
    i = 0
    while not bot.is_closed():
        g = len(bot.guilds)
        users = sum(x.member_count or 0 for x in bot.guilds)
        texts = [
            f"✦ {g} servers | {DEFAULT_PREFIX}help",
            f"✦ {users} users protected",
            f"✦ {CREDIT}",
            f"✦ {DEFAULT_PREFIX}play • {DEFAULT_PREFIX}antinuke",
        ]
        try:
            await bot.change_presence(
                status=discord.Status.idle,
                activity=discord.CustomActivity(name=texts[i % len(texts)]),
            )
        except Exception:
            pass
        i += 1
        await asyncio.sleep(120)


_status_task = None


@bot.event
async def on_ready():
    global _status_task
    if not OWNER_IDS:
        try:
            info = await bot.application_info()
            ids = [m.id for m in info.team.members] if info.team else [info.owner.id]
            OWNER_IDS.extend(ids)                       # same list object everywhere -> auto owner
            bot.owner_ids = set(ids)
            print(f"  Owner(s) auto-detected: {ids}")
        except Exception as e:
            print(f"  Could not detect owner automatically: {e}")
    if not bot.invite_link:
        bot.invite_link = f"https://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot%20applications.commands"
    print("=" * 55)
    print(f"  {BOT_NAME} online as: {bot.user} ({bot.user.id})")
    print(f"  Commands: {len(bot.commands)} | Cogs: {len(bot.cogs)} | Servers: {len(bot.guilds)}")
    print(f"  {CREDIT}")
    print("=" * 55)
    if _status_task is None or _status_task.done():
        _status_task = asyncio.create_task(update_status())


# =========================
# GLOBAL ERROR HANDLER
# =========================
@bot.event
async def on_command_error(ctx: commands.Context, error):
    error = getattr(error, "original", error)
    if hasattr(ctx.command, "on_error") or isinstance(error, commands.CommandNotFound):
        return
    msg = None
    if isinstance(error, commands.MissingPermissions):
        msg = f"{CROSS} You need **{', '.join(p.replace('_', ' ').title() for p in error.missing_permissions)}** permission."
    elif isinstance(error, commands.BotMissingPermissions):
        msg = f"{CROSS} I need **{', '.join(p.replace('_', ' ').title() for p in error.missing_permissions)}** permission."
    elif isinstance(error, commands.NotOwner):
        msg = f"{CROSS} Owner only command."
    elif isinstance(error, commands.MissingRequiredArgument):
        msg = f"{INFO} Missing argument: `{error.param.name}`. Use `{ctx.prefix}help` for usage."
    elif isinstance(error, (commands.BadArgument, commands.BadUnionArgument)):
        msg = f"{INFO} Invalid argument. Use `{ctx.prefix}help` for usage."
    elif isinstance(error, commands.CommandOnCooldown):
        msg = f"⏳ Slow down! Try again in **{error.retry_after:.1f}s**."
    elif isinstance(error, commands.NoPrivateMessage):
        msg = f"{CROSS} This command only works in servers."
    elif isinstance(error, commands.CheckFailure):
        return
    else:
        logging.error("Command error in %s", getattr(ctx.command, "qualified_name", "?"), exc_info=error)
        msg = f"{CROSS} Something went wrong. Try again later."
    try:
        await ctx.send(msg, delete_after=12)
    except Exception:
        pass


# =========================
# PREFIX COMMANDS
# =========================
@bot.command()
@commands.has_permissions(administrator=True)
@commands.guild_only()
async def setprefix(ctx, prefix: str):
    if not prefix or len(prefix) > 10:
        return await ctx.send(f"{CROSS} Prefix must be 1–10 characters")
    async with aiosqlite.connect(CORE_DB) as db:
        await db.execute("INSERT OR REPLACE INTO prefixes (guild_id, prefix) VALUES (?, ?)", (ctx.guild.id, prefix))
        await db.commit()
    await ctx.send(f"{CHECK} Prefix set to `{prefix}`")


@bot.command()
@commands.has_permissions(administrator=True)
@commands.guild_only()
async def resetprefix(ctx):
    async with aiosqlite.connect(CORE_DB) as db:
        await db.execute("DELETE FROM prefixes WHERE guild_id = ?", (ctx.guild.id,))
        await db.commit()
    await ctx.send(f"{CHECK} Prefix reset to `{DEFAULT_PREFIX}`")


# =========================
# LOADERS
# =========================
async def load_folder(folder: Path, label: str):
    folder.mkdir(exist_ok=True)
    ok = fail = 0
    for file in sorted(folder.glob("*.py")):
        if file.name.startswith("_"):
            continue
        ext = f"{folder.name}.{file.stem}"
        try:
            await bot.load_extension(ext)
            print(f"  [OK]   {label}: {ext}")
            ok += 1
        except Exception as e:
            print(f"  [FAIL] {label}: {ext} -> {type(e).__name__}: {e}")
            fail += 1
    print(f"== {label}: {ok} loaded, {fail} failed ==\n")


async def load_jishaku_ext():
    if os.getenv("ENABLE_JISHAKU", "1") != "1" or not OWNER_IDS:
        return
    try:
        await bot.load_extension("jishaku")
        print("  [OK]   jishaku (owner only)\n")
    except Exception as e:
        print(f"  [SKIP] jishaku: {e}\n")


@bot.listen("on_ready")
async def _sync_once():
    if getattr(bot, "_synced", False):
        return
    bot._synced = True
    if os.getenv("SYNC_SLASH", "1") == "1":
        try:
            # Discord allows max 100 global slash commands: keep the important ones, the rest still work with the prefix
            low = ("Fun", "Economy", "Tools", "Leveling", "Extras", "Server")
            cmds = bot.tree.get_commands()
            if len(cmds) > 100:
                for c in list(cmds):
                    if len(bot.tree.get_commands()) <= 100:
                        break
                    cog = getattr(getattr(c, "binding", None), "qualified_name", "")
                    if cog in low:
                        bot.tree.remove_command(c.name)
                while len(bot.tree.get_commands()) > 100:
                    bot.tree.remove_command(bot.tree.get_commands()[-1].name)
            n = await bot.tree.sync()
            print(f"  Slash commands synced: {len(n)}")
        except Exception as e:
            print(f"  Slash sync failed: {e}")


async def main():
    emojis.install()          # custom emoji mode (no-op if custom_emojis.json is empty)
    await init_databases()
    async with bot:
        await load_folder(COGS_DIR, "Cogs")
        await load_folder(EVENTS_DIR, "Events")
        await load_folder(AUTOMOD_DIR, "Automod")
        await load_folder(ANTINUKE_DIR, "AntiNuke")
        await load_jishaku_ext()
        await bot.start(TOKEN)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
