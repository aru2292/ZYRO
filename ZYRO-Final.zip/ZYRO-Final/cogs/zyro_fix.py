"""
ZYRO Fix Pack v2 - Full
Development by ARIAN

- Premium lock removed
- Broken help replaced
- Many important commands available as Slash
- Whitelist access improved
"""

import discord
from discord.ext import commands
from discord import app_commands
import aiosqlite
from emojis import CHECK, CROSS, INFO, SHIELD, MUSIC, STAR, FIRE, ZYRO, SPARKLE, VOICE

class ZyroFix(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._help_removed = False

    async def cog_load(self):
        # Remove premium global lock
        to_remove = [c for c in self.bot._checks if getattr(c, "__name__", "") == "premium_global_lock"]
        for c in to_remove:
            self.bot.remove_check(c)
        print("[ZYRO FIX] Premium lock removed")

        try:
            self.bot.remove_command("help")
            self._help_removed = True
        except Exception:
            pass

        self.bot.loop.create_task(self._sync_slash())

    async def _sync_slash(self):
        await self.bot.wait_until_ready()
        try:
            synced = await self.bot.tree.sync()
            print(f"[ZYRO FIX] Synced {len(synced)} slash commands")
        except Exception as e:
            print(f"[ZYRO FIX] Slash sync error: {e}")

    # ==================== CLEAN HELP ====================
    @commands.hybrid_command(name="help", aliases=["h", "commands"], description="Show ZYRO help menu")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def new_help(self, ctx: commands.Context, category: str = None):
        prefix = ctx.prefix if ctx.prefix else "+"
        cats = {
            "mod": ("Moderation", f"`{prefix}ban` `{prefix}kick` `{prefix}mute` `{prefix}unmute` `{prefix}lock` `{prefix}unlock` `{prefix}purge` `{prefix}snipe` `{prefix}warn`"),
            "antinuke": ("Anti-Nuke", f"`{prefix}antinuke` `{prefix}antinuke enable` `{prefix}antinuke disable` `{prefix}whitelist` `{prefix}wl` `{prefix}extraowner`"),
            "automod": ("AutoMod", f"`{prefix}automod enable` `{prefix}automod disable` `{prefix}automod config`"),
            "voice": ("VoiceMaster", f"`{prefix}voicemaster setup`  | Join interface channel to create temp VC"),
            "music": ("Music", f"`{prefix}play <song>` `{prefix}skip` `{prefix}queue` `{prefix}np` `{prefix}volume` `{prefix}join` `{prefix}leave`"),
            "utility": ("Utility", f"`{prefix}ping` `{prefix}stats` `{prefix}avatar` `{prefix}userinfo` `{prefix}serverinfo` `{prefix}steal` `{prefix}afk` `{prefix}setprefix`"),
        }

        if category and category.lower() in cats:
            title, desc = cats[category.lower()]
            embed = discord.Embed(title=f"{ZYRO} {title}", description=desc, color=0x5865F2)
            embed.set_footer(text="Development by ARIAN")
            return await ctx.send(embed=embed)

        embed = discord.Embed(
            title=f"{ZYRO} ZYRO Help",
            description=(
                f"**Prefix:** `{prefix}`  |  **Also works with Slash /**\n"
                f"**Development by ARIAN**\n\n"
                f"{STAR} Categories:\n"
                f"`{prefix}help mod`\n`{prefix}help antinuke`\n`{prefix}help automod`\n"
                f"`{prefix}help voice`\n`{prefix}help music`\n`{prefix}help utility`\n\n"
                f"{FIRE} Premium lock removed — everything is free"
            ),
            color=0x5865F2
        )
        embed.set_footer(text="ZYRO • No broken images")
        await ctx.send(embed=embed)

    # ==================== IMPORTANT SLASH COMMANDS ====================
    @app_commands.command(name="ping", description="Check bot latency")
    async def slash_ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"{CHECK} Pong! `{round(self.bot.latency*1000)}ms`")

    @app_commands.command(name="stats", description="Bot statistics")
    async def slash_stats(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title=f"{ZYRO} Stats",
            description=f"**Servers:** {len(self.bot.guilds)}\n**Users:** {len(self.bot.users)}\n**Ping:** {round(self.bot.latency*1000)}ms\n\nDevelopment by ARIAN",
            color=0x5865F2
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ban", description="Ban a member")
    @app_commands.describe(member="Member to ban", reason="Reason")
    @app_commands.default_permissions(ban_members=True)
    async def slash_ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        if not interaction.user.guild_permissions.ban_members:
            return await interaction.response.send_message(f"{CROSS} No permission", ephemeral=True)
        try:
            await member.ban(reason=reason)
            await interaction.response.send_message(f"{CHECK} Banned {member.mention}")
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)

    @app_commands.command(name="kick", description="Kick a member")
    @app_commands.describe(member="Member to kick", reason="Reason")
    @app_commands.default_permissions(kick_members=True)
    async def slash_kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason"):
        if not interaction.user.guild_permissions.kick_members:
            return await interaction.response.send_message(f"{CROSS} No permission", ephemeral=True)
        try:
            await member.kick(reason=reason)
            await interaction.response.send_message(f"{CHECK} Kicked {member.mention}")
        except Exception as e:
            await interaction.response.send_message(f"{CROSS} Failed: {e}", ephemeral=True)

    @app_commands.command(name="purge", description="Delete messages")
    @app_commands.describe(amount="Number of messages (1-100)")
    @app_commands.default_permissions(manage_messages=True)
    async def slash_purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
        if not interaction.user.guild_permissions.manage_messages:
            return await interaction.response.send_message(f"{CROSS} No permission", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"{CHECK} Deleted {len(deleted)} messages", ephemeral=True)

    @app_commands.command(name="lock", description="Lock current channel")
    @app_commands.default_permissions(manage_channels=True)
    async def slash_lock(self, interaction: discord.Interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = False
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.response.send_message(f"{CHECK} Channel locked")

    @app_commands.command(name="unlock", description="Unlock current channel")
    @app_commands.default_permissions(manage_channels=True)
    async def slash_unlock(self, interaction: discord.Interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = None
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.response.send_message(f"{CHECK} Channel unlocked")

    @app_commands.command(name="avatar", description="Get user avatar")
    async def slash_avatar(self, interaction: discord.Interaction, user: discord.User = None):
        user = user or interaction.user
        embed = discord.Embed(title=f"{user}'s Avatar", color=0x5865F2)
        embed.set_image(url=user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="userinfo", description="Get user info")
    async def slash_userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        user = user or interaction.user
        embed = discord.Embed(title=f"User Info — {user}", color=0x5865F2)
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.add_field(name="ID", value=user.id)
        embed.add_field(name="Joined", value=user.joined_at.strftime("%Y-%m-%d") if user.joined_at else "N/A")
        embed.add_field(name="Created", value=user.created_at.strftime("%Y-%m-%d"))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="serverinfo", description="Server information")
    async def slash_serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        embed = discord.Embed(title=g.name, color=0x5865F2)
        if g.icon:
            embed.set_thumbnail(url=g.icon.url)
        embed.add_field(name="Members", value=g.member_count)
        embed.add_field(name="Owner", value=g.owner.mention if g.owner else "N/A")
        embed.add_field(name="Created", value=g.created_at.strftime("%Y-%m-%d"))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="afk", description="Set AFK status")
    async def slash_afk(self, interaction: discord.Interaction, reason: str = "AFK"):
        # Simple AFK using nick (basic)
        try:
            if not interaction.user.display_name.startswith("[AFK]"):
                await interaction.user.edit(nick=f"[AFK] {interaction.user.display_name[:24]}")
        except Exception:
            pass
        await interaction.response.send_message(f"{CHECK} You are now AFK: **{reason}**")

    # ==================== OWNER / FIX ====================
    @commands.command(name="fixstatus")
    @commands.is_owner()
    async def fixstatus(self, ctx: commands.Context):
        has_prem = any(getattr(c, "__name__", "") == "premium_global_lock" for c in self.bot._checks)
        await ctx.send(
            f"{CHECK} **ZYRO Fix Pack v2 Active**\n"
            f"Premium Lock: `{'ON' if has_prem else 'REMOVED'}`\n"
            f"New Help: Loaded\n"
            f"Slash Commands: Synced\n"
            f"**Development by ARIAN**"
        )

    @commands.command(name="makefree")
    @commands.is_owner()
    async def makefree(self, ctx: commands.Context):
        to_remove = [c for c in self.bot._checks if getattr(c, "__name__", "") == "premium_global_lock"]
        for c in to_remove:
            self.bot.remove_check(c)
        await ctx.send(f"{CHECK} Premium lock removed again.")

async def setup(bot: commands.Bot):
    await bot.add_cog(ZyroFix(bot))
    print("[ZYRO FIX] v2 loaded")
