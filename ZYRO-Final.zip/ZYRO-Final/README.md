# ⚡ ZYRO — All-in-One Discord Bot

**Development by ARIAN**

## Features
- Anti-Nuke (full)
- AutoMod
- VoiceMaster (VC Setup)
- Music System (`+play`, queue, skip, volume...)
- Welcome, Giveaway, AFK, Moderation, Utility
- Slash Commands (help, play, ping, stats, skip...)
- Premium lock removed
- Pure Unicode emojis
- Fixed Help menu (no broken images)

## Deploy (Railway)

### Easy way (2 files only)
1. Upload these 2 files to a new GitHub repo:
   - `ZYRO-Final.zip`
   - `Dockerfile`
2. Railway → New Project → select the repo
3. Add Variables:
   ```
   TOKEN=your_bot_token
   OWNER_ID=your_discord_user_id
   ```
4. Deploy

Railway will auto-unzip and start the bot.

## Commands
- Prefix: `+`
- Music: `+play <song>`, `+skip`, `+queue`, `+np`, `+volume`
- Help: `+help` or `/help`
- Fix check: `+fixstatus` (owner)

**Development by ARIAN**
