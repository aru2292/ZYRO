# emojis.py
# ZYRO Bot - Pure Unicode + Stylish Symbols (No Custom Emojis)
# Development by ARIAN

# --- Main Emojis ---
CHECK = "✅"
VERIFIED_CHECK = "☑️"
CROSS = "❌"
CROSS_MARK = "❎"
TICK = "✅"
ZTICK = "✅"
ERROR_X = "❌"
LOCK = "🔒"
UNLOCK = "🔓"
GHOST = "👻"
UNGHOST = "👁️"
BOOST = "🚀"
INFO = "ℹ️"
CART = "🛒"
SUPPORT = "🛟"
DELETE = "🗑️"
LOADING = "⏳"

# --- Stats Emojis ---
STATS = "📊"
UPTIME = "⏱️"
DATABASE = "🗄️"
VERIFIED_DEV = "👨‍💻"
OS_SYSTEM = "🖥️"
CPU = "⚙️"
RAM = "🧠"
STORAGE = "💾"
CROWN = "👑"
GEARS = "⚙️"
LINK = "🔗"
CREDITS = "💳"

# --- Utility Emojis ---
TIMER = "⏲️"
REPLY = "↪️"
REPLY_2 = "↩️"
BELL = "🔔"

# --- Role / Status Emojis ---
VIP = "💎"
FRIEND = "🤝"
VERIFIED = "✔️"
ENABLED = "🟢"
DISABLED = "🔴"
DISABLED_OFF = "⚫"

# --- Extra Stylish / Rare Symbols for ZYRO ---
STAR = "✦"
STAR2 = "✧"
DIAMOND = "💠"
SPARKLE = "✨"
FIRE = "🔥"
SHIELD = "🛡️"
MUSIC = "🎵"
VOICE = "🔊"
MOD = "⚖️"
NUKE = "💣"
WELCOME = "👋"
GIVEAWAY = "🎉"
AFK = "💤"
PING = "📡"
SUCCESS = "🟢"
WARN = "⚠️"
ERROR = "🔴"
ARROW = "➤"
DOT = "•"
LINE = "─"
HEART = "❤️"
ROCKET = "🚀"
CROWN2 = "♛"
SWORD = "⚔️"
KEY = "🔑"
GLOBE = "🌐"
BOT = "🤖"
ZYRO = "⚡"

# --- Compatibility Mappings ---
EMOJIES = {
    "lock": LOCK,
    "unlock": UNLOCK,
    "ghost": GHOST,
    "unghost": UNGHOST,
    "boost": BOOST,
    "info": INFO,
    "cross": CROSS,
    "cart": CART,
    "check": CHECK,
    "success": SUCCESS,
    "error": ERROR,
    "warn": WARN,
    "loading": LOADING,
    "music": MUSIC,
    "shield": SHIELD,
    "star": STAR,
    "fire": FIRE,
}

ROLE_EMOJIS = {
    "Developer": VERIFIED_DEV,
    "Vip": VIP,
    "Friend": FRIEND,
    "Owner": CROWN,
    "Verified": VERIFIED,
}
