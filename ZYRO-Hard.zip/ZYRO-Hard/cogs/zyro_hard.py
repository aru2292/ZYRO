"""
ZYRO HARDCORE CORE
Development by ARIAN

2-Step AntiNuke + Premium + Rate Limited Whitelist + NoPrefix + Mention Reply + Clean Help
"""

import discord
from discord.ext import commands
from discord import app_commands, ui
import aiosqlite
import time
import re
import asyncio
from pathlib import Path
from datetime import datetime

try:
    from emojis import CHECK, CROSS, INFO, STAR, FIRE, ZYRO, CROWN, SHIELD, LOCK
except Exception:
    CHECK, CROSS, INFO, STAR, FIRE, ZYRO, CROWN, SHIELD, LOCK = "✅","❌","ℹ️","✦","🔥","⚡","👑","🛡️","🔒"

DB = Path("db/zyro_hard.db")

def parse_duration(text: str):
    text = text.lower().strip().replace(" ", "")
    m = re.match(r"^(\d+)(s|m|h|d|w|month|months)$", text)
    if not m: return None
    val, unit = int(m.group(1)), m.group(2)
    mult = {"s":1,"m":60,"h":3600,"d":86400,"w":604800,"month":2592000,"months":2592000}
    return val * mult.get(unit, 0) or None


class HelpView(ui.View):
    def __init__(self, prefix: str):
        super().__init__(timeout=120)
        self.prefix = prefix
        options = [
            discord.SelectOption(label="Moderation", value="mod", emoji="⚖️"),
            discord.SelectOption(label="AntiNuke (2-Step)", value="antinuke", emoji="🛡️"),
            discord.SelectOption(label="Music", value="music", emoji="🎵"),
            discord.SelectOption(label="VoiceMaster", value="voice", emoji="🔊"),
            discord.SelectOption(label="Utility", value="utility", emoji="🔧"),
            discord.SelectOption(label="Premium", value="premium", emoji="👑"),
            discord.SelectOption(label="Owner", value="owner", emoji="🔑"),
        ]
        select = ui.Select(placeholder="Choose a category...", options=options)
        select.callback = self.select_callback
        self.add_item(select)

    async def select_callback(self, interaction: discord.Interaction):
        p = self.prefix
        data = {
            "mod": f"`{p}ban` `{p}kick` `{p}mute` `{p}unmute` `{p}purge` `{p}lock` `{p}unlock` `{p}snipe`",
            "antinuke": (
                f"**Layer 1 (Normal)**\n"
                f"`{p}antinuke enable` → Role: **ZYRO ./unbypassable**\n"
                f"`{p}whitelist` / `{p}wl`\n\n"
                f"**Layer 2 (Premium)**\n"
                f"`{p}antinuke2 enable` → Role: **ZYRO+++ ./unbypassable**\n"
                f"`{p}wl2` + daily limits (ban/everyone/prune)\n"
                f"`{p}wl2limit ban 3` (example)"
            ),
            "music": f"`{p}play <song>` `{p}skip` `{p}queue` `{p}np` `{p}volume` `{p}join` `{p}leave`",
            "voice": f"`{p}voicemaster setup`\nCreates: **YourName's Channel**",
            "utility": f"`{p}ping` `{p}stats` `{p}avatar` `{p}userinfo` `{p}steal` `{p}afk` `{p}setprefix`",
            "premium": f"`{p}premium activate` `{p}premium status`\nOwner: `{p}premium grant @user 3month`",
            "owner": f"`{p}premium grant` `{p}dmaccess` `{p}dm` `{p}wl2limit`",
        }
        val = interaction.data["values"][0]
        embed = discord.Embed(title=f"⚡ {val.title()}", description=data.get(val, "N/A"), color=0x5865F2)
        embed.set_footer(text="Development by ARIAN")
        await interaction.response.edit_message(embed=embed, view=self)


class ZyroHard(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.loop.create_task(self._boot())

    async def _boot(self):
        Path("db").mkdir(exist_ok=True)
        async with aiosqlite.connect(DB) as db:
            await db.execute("""CREATE TABLE IF NOT EXISTS premium_users (
                user_id INTEGER PRIMARY KEY, expires REAL, plan TEXT)""")
            await db.execute("""CREATE TABLE IF NOT EXISTS premium_guilds (
                guild_id INTEGER PRIMARY KEY, activated_by INTEGER, activated_at REAL)""")
            await db.execute("""CREATE TABLE IF NOT EXISTS dm_access (
                user_id INTEGER PRIMARY KEY, expires REAL)""")
            await db.execute("""CREATE TABLE IF NOT EXISTS antinuke2 (
                guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0)""")
            await db.execute("""CREATE TABLE IF NOT EXISTS wl2 (
                guild_id INTEGER, user_id INTEGER,
                PRIMARY KEY (guild_id, user_id))""")
            await db.execute("""CREATE TABLE IF NOT EXISTS wl2_limits (
                guild_id INTEGER, action TEXT, max_per_day INTEGER,
                PRIMARY KEY (guild_id, action))""")
            await db.execute("""CREATE TABLE IF NOT EXISTS wl2_usage (
                guild_id INTEGER, user_id INTEGER, action TEXT, day TEXT, count INTEGER,
                PRIMARY KEY (guild_id, user_id, action, day))""")
            await db.commit()

        for c in list(self.bot._checks):
            if getattr(c, "__name__", "") == "premium_global_lock":
                self.bot.remove_check(c)

        for name in ("help", "h", "commands"):
            try: self.bot.remove_command(name)
            except: pass

        await self.bot.wait_until_ready()
        try: await self.bot.tree.sync()
        except: pass
        print("[ZYRO HARD] 2-Step AntiNuke + Premium Core loaded ✓")

    # ===================== HELPERS =====================
    async def is_premium_user(self, uid: int) -> bool:
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT expires FROM premium_users WHERE user_id=?", (uid,)) as cur:
                row = await cur.fetchone()
        return bool(row and row[0] > time.time())

    async def is_premium_guild(self, gid: int) -> bool:
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT 1 FROM premium_guilds WHERE guild_id=?", (gid,)) as cur:
                return bool(await cur.fetchone())

    async def is_extra_or_owner(self, ctx) -> bool:
        if ctx.author.id == ctx.guild.owner_id:
            return True
        if ctx.author.guild_permissions.administrator:
            return True
        # try extraowner table from original anti.db
        try:
            async with aiosqlite.connect("db/anti.db") as db:
                async with db.execute("SELECT 1 FROM extraowners WHERE guild_id=? AND owner_id=?",
                                      (ctx.guild.id, ctx.author.id)) as cur:
                    return bool(await cur.fetchone())
        except:
            return False

    # ===================== PREMIUM =====================
    @commands.group(name="premium", invoke_without_command=True)
    async def premium(self, ctx):
        embed = discord.Embed(title=f"{CROWN} ZYRO Premium", color=0xF1C40F,
            description=(
                f"**User:**\n`{ctx.prefix}premium activate`\n`{ctx.prefix}premium status`\n\n"
                f"**Bot Owner:**\n`{ctx.prefix}premium grant @user 3month`\n"
                f"`{ctx.prefix}premium grant @user 30d`\n"
                f"`{ctx.prefix}premium remove @user`\n`{ctx.prefix}premium list`"
            ))
        embed.set_footer(text="Development by ARIAN")
        await ctx.send(embed=embed)

    @premium.command(name="grant")
    @commands.is_owner()
    async def premium_grant(self, ctx, user: discord.User, duration: str):
        sec = parse_duration(duration)
        if not sec:
            return await ctx.send(f"{CROSS} Example: `3month` `30d` `7d` `24h`")
        exp = time.time() + sec
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO premium_users VALUES (?,?,?)", (user.id, exp, duration))
            await db.commit()
        try:
            e = discord.Embed(title=f"{CROWN} Premium Received!", color=0xF1C40F,
                description=f"Duration: **{duration}**\n• No-Prefix unlocked\n• Use `+premium activate` in servers\n• Access to AntiNuke Layer 2\n\n**Development by ARIAN**")
            await user.send(embed=e)
        except: pass
        await ctx.send(f"{CHECK} Premium granted to {user.mention} → **{duration}**")

    @premium.command(name="remove")
    @commands.is_owner()
    async def premium_remove(self, ctx, user: discord.User):
        async with aiosqlite.connect(DB) as db:
            await db.execute("DELETE FROM premium_users WHERE user_id=?", (user.id,))
            await db.commit()
        await ctx.send(f"{CHECK} Removed from {user.mention}")

    @premium.command(name="list")
    @commands.is_owner()
    async def premium_list(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT user_id, expires, plan FROM premium_users") as cur:
                rows = await cur.fetchall()
        lines = []
        for uid, exp, plan in rows:
            left = exp - time.time()
            if left > 0:
                lines.append(f"<@{uid}> — `{plan}` ({int(left//86400)}d left)")
        await ctx.send("**Premium Users:**\n" + ("\n".join(lines[:25]) if lines else "None"))

    @premium.command(name="activate")
    async def premium_activate(self, ctx):
        if not await self.is_premium_user(ctx.author.id):
            return await ctx.send(f"{CROSS} You need Premium first.")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO premium_guilds VALUES (?,?,?)",
                             (ctx.guild.id, ctx.author.id, time.time()))
            await db.commit()
        await ctx.send(f"{CHECK} **Premium activated** on this server!\nLayer 2 AntiNuke + extra features unlocked.")

    @premium.command(name="status")
    async def premium_status(self, ctx):
        u = await self.is_premium_user(ctx.author.id)
        g = await self.is_premium_guild(ctx.guild.id)
        await ctx.send(f"Your Premium: {'✅' if u else '❌'}\nThis Server: {'✅ Activated' if g else '❌ Not activated'}")

    # ===================== ANTINUKE LAYER 2 =====================
    @commands.group(name="antinuke2", aliases=["an2"], invoke_without_command=True)
    async def antinuke2(self, ctx):
        async with aiosqlite.connect(DB) as db:
            async with db.execute("SELECT enabled FROM antinuke2 WHERE guild_id=?", (ctx.guild.id,)) as cur:
                row = await cur.fetchone()
        status = "ON ✅" if row and row[0] else "OFF ❌"
        embed = discord.Embed(title=f"{SHIELD} AntiNuke Layer 2 (Premium)", color=0xE74C3C,
            description=(
                f"**Status:** {status}\n"
                f"**Role:** `ZYRO+++ ./unbypassable`\n\n"
                f"`{ctx.prefix}antinuke2 enable`\n"
                f"`{ctx.prefix}antinuke2 disable`\n"
                f"`{ctx.prefix}wl2 @user` — whitelist for Layer 2\n"
                f"`{ctx.prefix}wl2limit ban 2` — set daily limit\n"
                f"`{ctx.prefix}wl2limit everyone 1`\n"
                f"`{ctx.prefix}wl2limit prune 1`\n\n"
                f"Only **Premium activated** servers can use this."
            ))
        await ctx.send(embed=embed)

    @antinuke2.command(name="enable")
    async def an2_enable(self, ctx):
        if not await self.is_premium_guild(ctx.guild.id):
            return await ctx.send(f"{CROSS} This server needs Premium activated first.\n`+premium activate`")
        if not await self.is_extra_or_owner(ctx):
            return await ctx.send(f"{CROSS} Only Server Owner / Extra Owner / Admin")
        # Create role
        role = discord.utils.get(ctx.guild.roles, name="ZYRO+++ ./unbypassable")
        if not role:
            try:
                role = await ctx.guild.create_role(name="ZYRO+++ ./unbypassable",
                    permissions=discord.Permissions(administrator=True),
                    reason="ZYRO Layer 2 AntiNuke")
                # try move high
                await role.edit(position=max(1, ctx.guild.me.top_role.position - 1))
            except Exception as e:
                return await ctx.send(f"{CROSS} Could not create role: {e}")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO antinuke2 (guild_id, enabled) VALUES (?,1)", (ctx.guild.id,))
            await db.commit()
        await ctx.send(f"{CHECK} **AntiNuke Layer 2 Enabled**\nRole: **ZYRO+++ ./unbypassable**")

    @antinuke2.command(name="disable")
    async def an2_disable(self, ctx):
        if not await self.is_extra_or_owner(ctx):
            return await ctx.send(f"{CROSS} No permission")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO antinuke2 (guild_id, enabled) VALUES (?,0)", (ctx.guild.id,))
            await db.commit()
        await ctx.send(f"{CHECK} Layer 2 Disabled")

    @commands.command(name="wl2")
    async def wl2(self, ctx, user: discord.Member = None):
        if not await self.is_premium_guild(ctx.guild.id):
            return await ctx.send(f"{CROSS} Premium server required")
        if not await self.is_extra_or_owner(ctx):
            return await ctx.send(f"{CROSS} Owner / Extra Owner / Admin only")
        if not user:
            return await ctx.send(f"{INFO} Usage: `{ctx.prefix}wl2 @user`")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR IGNORE INTO wl2 (guild_id, user_id) VALUES (?,?)", (ctx.guild.id, user.id))
            await db.commit()
        await ctx.send(f"{CHECK} {user.mention} added to **Layer 2 Whitelist** (rate limited)")

    @commands.command(name="wl2limit")
    async def wl2limit(self, ctx, action: str = None, limit: int = None):
        if not await self.is_extra_or_owner(ctx):
            return await ctx.send(f"{CROSS} No permission")
        if not action or limit is None:
            return await ctx.send(f"{INFO} Example:\n`{ctx.prefix}wl2limit ban 3`\n`{ctx.prefix}wl2limit everyone 1`\n`{ctx.prefix}wl2limit prune 2`")
        action = action.lower()
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO wl2_limits (guild_id, action, max_per_day) VALUES (?,?,?)",
                             (ctx.guild.id, action, limit))
            await db.commit()
        await ctx.send(f"{CHECK} Layer 2 limit set: **{action}** → max `{limit}` per day")

    # ===================== NO PREFIX + MENTION =====================
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        # Mention reply
        if self.bot.user in message.mentions and not message.mention_everyone:
            content = message.content.replace(f"<@{self.bot.user.id}>", "").replace(f"<@!{self.bot.user.id}>", "").strip()
            if not content or content.startswith(("+", ".", "!", "?")):
                return
            embed = discord.Embed(color=0x5865F2,
                description=f"Hey {message.author.mention}!\nPrefix: `+`\nType `+help` for commands.\n**Development by ARIAN**")
            try: await message.reply(embed=embed, mention_author=False)
            except: pass
            return

        # No-prefix for premium users
        if await self.is_premium_user(message.author.id):
            content = message.content.strip()
            if content and not any(content.startswith(p) for p in ("+", ".", "!", "?", "-", "/")):
                message.content = f"+{content}"
                await self.bot.process_commands(message)

    # ===================== DM ACCESS =====================
    @commands.command(name="dmaccess")
    @commands.is_owner()
    async def dmaccess(self, ctx, user: discord.Member, duration: str):
        sec = parse_duration(duration)
        if not sec: return await ctx.send(f"{CROSS} Use `10m` `1h` `1d`")
        async with aiosqlite.connect(DB) as db:
            await db.execute("INSERT OR REPLACE INTO dm_access VALUES (?,?)", (user.id, time.time()+sec))
            await db.commit()
        await ctx.send(f"{CHECK} DM Access → {user.mention} ({duration})")

    @commands.command(name="dm")
    async def dm(self, ctx, user: discord.Member, *, msg: str):
        ok = await self.bot.is_owner(ctx.author)
        if not ok:
            async with aiosqlite.connect(DB) as db:
                async with db.execute("SELECT expires FROM dm_access WHERE user_id=?", (ctx.author.id,)) as cur:
                    row = await cur.fetchone()
            ok = row and row[0] > time.time()
        if not ok: return await ctx.send(f"{CROSS} No DM Access")
        try:
            await user.send(f"**{ctx.author} via ZYRO:**\n{msg}")
            await ctx.send(f"{CHECK} Sent")
        except: await ctx.send(f"{CROSS} Cannot DM")

    # ===================== HELP WITH BUTTONS =====================
    @commands.command(name="help", aliases=["h"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def help_cmd(self, ctx):
        embed = discord.Embed(
            title=f"{ZYRO} ZYRO Hardcore Help",
            description=(
                f"**Prefix:** `{ctx.prefix}`\n"
                f"**Development by ARIAN**\n\n"
                f"Select a category below ⬇️\n\n"
                f"{SHIELD} **2-Step AntiNuke**\n"
                f"• Layer 1: `ZYRO ./unbypassable`\n"
                f"• Layer 2: `ZYRO+++ ./unbypassable` (Premium + rate limits)"
            ),
            color=0x5865F2
        )
        embed.set_footer(text="ZYRO Hardcore • Development by ARIAN")
        await ctx.send(embed=embed, view=HelpView(ctx.prefix))

    @commands.command(name="zyro")
    async def zyro(self, ctx):
        await ctx.send(f"{CHECK} **ZYRO Hardcore Online**\n2-Step AntiNuke + Premium ready\nDevelopment by ARIAN")


async def setup(bot):
    await bot.add_cog(ZyroHard(bot))
