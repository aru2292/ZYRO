# ⚡ ZYRO Hardcore
Development by ARIAN

## 2-Step AntiNuke
- Layer 1: `+antinuke enable` → Role **ZYRO ./unbypassable**
- Layer 2: `+antinuke2 enable` → Role **ZYRO+++ ./unbypassable** (Premium + daily limits)

## Premium
`+premium grant @user 3month` (owner)
`+premium activate` (in server)

## Deploy
Upload ZYRO-Hard.zip + Dockerfile → Railway → TOKEN + OWNER_ID
